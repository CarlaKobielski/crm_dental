import Stripe from "stripe"

// Inicializar o cliente Stripe apenas se a chave estiver disponível
export const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2023-10-16",
    })
  : undefined

// Tipos para ciclos de cobrança
export type CicloCobranca = "mensal" | "trimestral" | "anual"

// Interface para planos
export interface PlanInfo {
  name: string
  id: string
  price: number
  features: string[]
  limits: {
    patients: number
    users: number
  }
  priceIds: {
    mensal: string
    trimestral: string
    anual: string
  }
}

// Definir os planos disponíveis com IDs de preço para diferentes ciclos
export const STRIPE_PLANS: Record<string, PlanInfo> = {
  TRIAL: {
    name: "Trial",
    id: "trial",
    price: 0,
    features: ["Acesso por 14 dias", "Até 10 pacientes", "Funcionalidades básicas"],
    limits: {
      patients: 10,
      users: 2,
    },
    priceIds: {
      mensal: "price_trial",
      trimestral: "price_trial",
      anual: "price_trial",
    },
  },
  BASIC: {
    name: "Básico",
    id: "basic",
    price: 99.9,
    features: [
      "Até 100 pacientes",
      "Até 3 usuários",
      "Agendamento básico",
      "Prontuário eletrônico",
      "Suporte por e-mail",
    ],
    limits: {
      patients: 100,
      users: 3,
    },
    priceIds: {
      mensal: "price_basic_monthly", // Substituir pelo ID real do preço no Stripe
      trimestral: "price_basic_quarterly", // Substituir pelo ID real do preço no Stripe
      anual: "price_basic_yearly", // Substituir pelo ID real do preço no Stripe
    },
  },
  PROFESSIONAL: {
    name: "Profissional",
    id: "professional",
    price: 199.9,
    features: [
      "Até 500 pacientes",
      "Até 10 usuários",
      "Agendamento avançado",
      "Prontuário eletrônico completo",
      "Financeiro e faturamento",
      "Suporte prioritário",
    ],
    limits: {
      patients: 500,
      users: 10,
    },
    priceIds: {
      mensal: "price_professional_monthly", // Substituir pelo ID real do preço no Stripe
      trimestral: "price_professional_quarterly", // Substituir pelo ID real do preço no Stripe
      anual: "price_professional_yearly", // Substituir pelo ID real do preço no Stripe
    },
  },
  ENTERPRISE: {
    name: "Empresarial",
    id: "enterprise",
    price: 399.9,
    features: [
      "Pacientes ilimitados",
      "Usuários ilimitados",
      "Todas as funcionalidades",
      "Relatórios avançados",
      "API para integrações",
      "Suporte VIP",
    ],
    limits: {
      patients: Number.POSITIVE_INFINITY,
      users: Number.POSITIVE_INFINITY,
    },
    priceIds: {
      mensal: "price_enterprise_monthly", // Substituir pelo ID real do preço no Stripe
      trimestral: "price_enterprise_quarterly", // Substituir pelo ID real do preço no Stripe
      anual: "price_enterprise_yearly", // Substituir pelo ID real do preço no Stripe
    },
  },
}

// Descontos por ciclo de cobrança
export const CICLO_DESCONTOS = {
  mensal: 0,
  trimestral: 10, // 10% de desconto
  anual: 20, // 20% de desconto
}

// Mapeamento de ciclos para intervalos do Stripe
export const CICLO_TO_STRIPE_INTERVAL: Record<CicloCobranca, { interval: string; interval_count: number }> = {
  mensal: { interval: "month", interval_count: 1 },
  trimestral: { interval: "month", interval_count: 3 },
  anual: { interval: "year", interval_count: 1 },
}

// Função para calcular o preço com desconto
export function calcularPrecoComDesconto(precoBase: number, ciclo: CicloCobranca): number {
  const desconto = CICLO_DESCONTOS[ciclo] || 0
  return precoBase * (1 - desconto / 100)
}

// Criar um checkout do Stripe com suporte a diferentes ciclos
export async function createCheckoutSession(
  customerId: string,
  planId: string,
  ciclo: CicloCobranca,
  successUrl: string,
  cancelUrl: string,
) {
  // Encontrar o plano
  const planoKey = Object.keys(STRIPE_PLANS).find((key) => STRIPE_PLANS[key].id.toLowerCase() === planId.toLowerCase())

  if (!planoKey) {
    throw new Error(`Plano não encontrado: ${planId}`)
  }

  const plano = STRIPE_PLANS[planoKey]
  const priceId = plano.priceIds[ciclo]

  if (!priceId) {
    throw new Error(`ID de preço não encontrado para o plano ${planId} e ciclo ${ciclo}`)
  }

  const session = await stripe?.checkout.sessions.create({
    customer: customerId,
    payment_method_types: ["card"],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    mode: "subscription",
    subscription_data: {
      trial_period_days: 14, // Período de teste de 14 dias
    },
    metadata: {
      plano: planId,
      ciclo: ciclo,
    },
    success_url: successUrl,
    cancel_url: cancelUrl,
  })

  return session
}

// Criar um portal de gerenciamento de assinatura
export async function createBillingPortalSession(customerId: string, returnUrl: string) {
  const session = await stripe?.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  })

  return session
}

// Criar um cliente no Stripe
export async function createCustomer(email: string, name: string) {
  const customer = await stripe?.customers.create({
    email,
    name,
  })

  return customer
}

// Atualizar uma assinatura (upgrade/downgrade)
export async function updateSubscription(
  subscriptionId: string,
  newPlanId: string,
  ciclo: CicloCobranca,
  effectiveDate: "now" | "next_billing_cycle" = "now",
) {
  // Encontrar o plano
  const planoKey = Object.keys(STRIPE_PLANS).find(
    (key) => STRIPE_PLANS[key].id.toLowerCase() === newPlanId.toLowerCase(),
  )

  if (!planoKey) {
    throw new Error(`Plano não encontrado: ${newPlanId}`)
  }

  const plano = STRIPE_PLANS[planoKey]
  const priceId = plano.priceIds[ciclo]

  if (!priceId) {
    throw new Error(`ID de preço não encontrado para o plano ${newPlanId} e ciclo ${ciclo}`)
  }

  // Obter a assinatura atual
  const subscription = await stripe?.subscriptions.retrieve(subscriptionId)

  if (!subscription) {
    throw new Error(`Assinatura não encontrada: ${subscriptionId}`)
  }

  // Configurar a atualização
  const updateParams: Stripe.SubscriptionUpdateParams = {
    items: [
      {
        id: subscription.items.data[0].id,
        price: priceId,
      },
    ],
    metadata: {
      plano: newPlanId,
      ciclo: ciclo,
    },
  }

  // Se a mudança deve ocorrer no próximo ciclo de cobrança
  if (effectiveDate === "next_billing_cycle") {
    updateParams.proration_behavior = "none"
    updateParams.trial_end = subscription.current_period_end
  }

  // Atualizar a assinatura
  const updatedSubscription = await stripe?.subscriptions.update(subscriptionId, updateParams)

  return updatedSubscription
}

// Cancelar uma assinatura com período de carência
export async function cancelSubscription(subscriptionId: string, cancelAtPeriodEnd = true, gracePeriodDays = 0) {
  if (gracePeriodDays > 0) {
    // Calcular a data de término do período de carência
    const gracePeriodEnd = Math.floor(Date.now() / 1000) + gracePeriodDays * 24 * 60 * 60

    // Atualizar a assinatura para cancelar no final do período de carência
    const subscription = await stripe?.subscriptions.update(subscriptionId, {
      cancel_at: gracePeriodEnd,
      metadata: {
        em_carencia: "true",
        data_fim_carencia: new Date(gracePeriodEnd * 1000).toISOString(),
      },
    })

    return subscription
  } else {
    // Cancelar no final do período atual ou imediatamente
    const subscription = await stripe?.subscriptions.update(subscriptionId, {
      cancel_at_period_end: cancelAtPeriodEnd,
    })

    return subscription
  }
}

// Reativar uma assinatura que está em período de carência
export async function reactivateSubscription(subscriptionId: string) {
  const subscription = await stripe?.subscriptions.update(subscriptionId, {
    cancel_at_period_end: false,
    cancel_at: undefined,
    metadata: {
      em_carencia: "false",
      data_fim_carencia: "",
    },
  })

  return subscription
}

// Verificar o status de uma assinatura
export async function getSubscriptionStatus(subscriptionId: string) {
  const subscription = await stripe?.subscriptions.retrieve(subscriptionId)
  return subscription?.status
}

// Obter detalhes completos de uma assinatura
export async function getSubscriptionDetails(subscriptionId: string) {
  const subscription = await stripe?.subscriptions.retrieve(subscriptionId, {
    expand: ["latest_invoice", "customer"],
  })

  return subscription
}

