import { supabase } from "./supabase"
import { v4 as uuidv4 } from "uuid"

// Definir os buckets que usaremos
export const STORAGE_BUCKETS = {
  DOCUMENTOS: "documentos",
  IMAGENS: "imagens",
  PRONTUARIOS: "prontuarios",
  RADIOGRAFIAS: "radiografias",
}

// Inicializar buckets
export async function initializeBuckets() {
  // Verificar se os buckets existem primeiro
  try {
    const { data: buckets, error: listError } = await supabase.storage.listBuckets()

    if (listError) {
      console.error("Erro ao listar buckets:", listError)
      return false
    }

    const existingBuckets = new Set(buckets?.map((b) => b.name) || [])

    // Tentar criar apenas os buckets que não existem
    for (const bucket of Object.values(STORAGE_BUCKETS)) {
      if (!existingBuckets.has(bucket)) {
        try {
          console.log(`Tentando criar bucket ${bucket}...`)
          const { error: createError } = await supabase.storage.createBucket(bucket, {
            public: true, // Alterado para público para evitar problemas de RLS
            fileSizeLimit: 10485760, // 10MB
          })

          if (createError) {
            // Se houver erro de RLS, apenas registre e continue
            if (createError.message.includes("violates row-level security policy")) {
              console.warn(`Erro de RLS ao criar bucket ${bucket}. O bucket pode precisar ser criado manualmente.`)
            } else {
              console.error(`Erro ao criar bucket ${bucket}:`, createError)
            }
          } else {
            console.log(`Bucket ${bucket} criado com sucesso`)
          }
        } catch (error) {
          console.error(`Erro ao criar bucket ${bucket}:`, error)
        }
      } else {
        console.log(`Bucket ${bucket} já existe`)
      }
    }

    return true
  } catch (error) {
    console.error("Erro ao inicializar buckets:", error)
    return false
  }
}

// Upload de arquivo
export async function uploadFile(bucket: string, file: File, path = ""): Promise<{ url: string; path: string } | null> {
  try {
    console.log(`Iniciando upload para bucket ${bucket}:`, file.name, file.type, file.size)

    // Gerar um nome único para o arquivo
    const fileExt = file.name.split(".").pop()
    const fileName = `${uuidv4()}.${fileExt}`
    const filePath = path ? `${path}/${fileName}` : fileName

    console.log(`Caminho do arquivo: ${filePath}`)

    // Fazer upload do arquivo
    const { error, data } = await supabase.storage.from(bucket).upload(filePath, file, {
      cacheControl: "3600",
      upsert: false,
    })

    if (error) {
      console.error("Erro no upload:", error)
      throw error
    }

    console.log("Upload bem-sucedido:", data)

    // Obter a URL pública do arquivo
    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(filePath)

    console.log("URL pública:", urlData.publicUrl)

    return {
      url: urlData.publicUrl,
      path: filePath,
    }
  } catch (error) {
    console.error("Erro ao fazer upload do arquivo:", error)
    return null
  }
}

// Excluir arquivo
export async function deleteFile(bucket: string, filePath: string): Promise<boolean> {
  try {
    console.log(`Excluindo arquivo do bucket ${bucket}:`, filePath)

    const { error } = await supabase.storage.from(bucket).remove([filePath])

    if (error) {
      console.error("Erro ao excluir arquivo:", error)
      throw error
    }

    console.log("Arquivo excluído com sucesso")
    return true
  } catch (error) {
    console.error("Erro ao excluir arquivo:", error)
    return false
  }
}

// Listar arquivos
export async function listFiles(bucket: string, path = ""): Promise<any[]> {
  try {
    console.log(`Listando arquivos do bucket ${bucket}, path: ${path}`)

    const { data, error } = await supabase.storage.from(bucket).list(path, {
      limit: 100,
      offset: 0,
      sortBy: { column: "name", order: "asc" },
    })

    if (error) {
      console.error("Erro ao listar arquivos:", error)
      throw error
    }

    console.log(`${data?.length || 0} arquivos encontrados`)
    return data || []
  } catch (error) {
    console.error("Erro ao listar arquivos:", error)
    return []
  }
}

// Obter URL pública
export function getPublicUrl(bucket: string, filePath: string): string {
  const { data } = supabase.storage.from(bucket).getPublicUrl(filePath)
  return data.publicUrl
}

