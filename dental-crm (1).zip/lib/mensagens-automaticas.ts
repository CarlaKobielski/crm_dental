import { createServerClient } from "./supabase"
import { sendEmail, sendSMS, sendWhatsApp } from "./notifications"
import { format, addDays, isSameDay } from "date-fns"
import { ptBR } from "date-fns/locale"

// Função para processar mensagens de aniversário
export async function processarMensagensAniversario(): Promise<void> {
  const supabase = createServerClient()

  try {
    // Buscar todas as clínicas ativas
    const { data: clinicas, error: clinicasError } = await supabase
      .from("clinicas")
      .select("id, nome")
      .eq("status", "ativo")

    if (clinicasError) {
      console.error("Erro ao buscar clínicas:", clinicasError)
      return
    }

    const hoje = new Date()
    const diaHoje = hoje.getDate()
    const mesHoje = hoje.getMonth() + 1

    // Processar cada clínica
    for (const clinica of clinicas) {
      // Verificar se a clínica tem configuração de mensagens automáticas
      const { data: config, error: configError } = await supabase
        .from("config_mensagens_automaticas")
        .select("aniversario_ativo, aniversario_modelo_id")
        .eq("clinica_id", clinica.id)
        .single()

      if (configError || !config || !config.aniversario_ativo || !config.aniversario_modelo_id) {
        continue // Pular esta clínica
      }

      // Buscar o modelo de mensagem
      const { data: modelo, error: modeloError } = await supabase
        .from("modelos_mensagens")
        .select("*")
        .eq("id", config.aniversario_modelo_id)
        .single()

      if (modeloError || !modelo) {
        console.error(`Erro ao buscar modelo de mensagem para clínica ${clinica.id}:`, modeloError)
        continue
      }

      // Buscar pacientes que fazem aniversário hoje
      const { data: pacientes, error: pacientesError } = await supabase
        .from("pacientes")
        .select("id, nome, email, telefone, data_nascimento")
        .eq("clinica_id", clinica.id)
        .not("data_nascimento", "is", null)

      if (pacientesError) {
        console.error(`Erro ao buscar pacientes da clínica ${clinica.id}:`, pacientesError)
        continue
      }

      // Filtrar pacientes que fazem aniversário hoje
      const aniversariantes = pacientes.filter((paciente) => {
        if (!paciente.data_nascimento) return false

        const dataNascimento = new Date(paciente.data_nascimento)
        const diaNascimento = dataNascimento.getDate()
        const mesNascimento = dataNascimento.getMonth() + 1

        return diaNascimento === diaHoje && mesNascimento === mesHoje
      })

      // Enviar mensagens para os aniversariantes
      for (const paciente of aniversariantes) {
        // Verificar se já enviamos mensagem hoje
        const { data: jaEnviado, error: checkError } = await supabase
          .from("notificacoes")
          .select("id")
          .eq("clinica_id", clinica.id)
          .eq("paciente_id", paciente.id)
          .eq("tipo", modelo.canal)
          .like("mensagem", "%aniversário%")
          .gte("created_at", format(hoje, "yyyy-MM-dd"))
          .lt("created_at", format(addDays(hoje, 1), "yyyy-MM-dd"))
          .limit(1)

        if (!checkError && jaEnviado && jaEnviado.length > 0) {
          continue // Já enviamos mensagem hoje para este paciente
        }

        // Preparar a mensagem
        const mensagem = modelo.conteudo
          .replace(/{paciente}/g, paciente.nome)
          .replace(/{clinica}/g, clinica.nome)
          .replace(/{data}/g, format(hoje, "dd/MM/yyyy"))

        // Enviar a mensagem de acordo com o canal
        let success = false

        if (modelo.canal === "email" && paciente.email) {
          success = await sendEmail(paciente.email, modelo.assunto || `Feliz Aniversário, ${paciente.nome}!`, mensagem)
        } else if (modelo.canal === "sms" && paciente.telefone) {
          success = await sendSMS(paciente.telefone, mensagem)
        } else if (modelo.canal === "whatsapp" && paciente.telefone) {
          success = await sendWhatsApp(paciente.telefone, mensagem, clinica.id)
        }

        // Registrar a notificação
        if (success) {
          await sendWhatsApp(paciente.telefone, mensagem, clinica.id)
        }

        // Registrar a notificação
        if (success) {
          await supabase.from("notificacoes").insert({
            clinica_id: clinica.id,
            paciente_id: paciente.id,
            destinatario: modelo.canal === "email" ? paciente.email : paciente.telefone,
            tipo: modelo.canal,
            assunto: modelo.assunto || `Feliz Aniversário, ${paciente.nome}!`,
            mensagem: mensagem,
            status: "enviado",
            data_envio: new Date().toISOString(),
            data_processamento: new Date().toISOString(),
          })
        }
      }
    }
  } catch (error) {
    console.error("Erro ao processar mensagens de aniversário:", error)
  }
}

// Função para processar mensagens de datas comemorativas
export async function processarMensagensDatasComemoraticas(): Promise<void> {
  const supabase = createServerClient()

  try {
    // Buscar todas as clínicas ativas
    const { data: clinicas, error: clinicasError } = await supabase
      .from("clinicas")
      .select("id, nome")
      .eq("status", "ativo")

    if (clinicasError) {
      console.error("Erro ao buscar clínicas:", clinicasError)
      return
    }

    const hoje = new Date()

    // Processar cada clínica
    for (const clinica of clinicas) {
      // Buscar datas comemorativas ativas para hoje ou próximos dias
      const { data: datasComemoraticas, error: datasError } = await supabase
        .from("datas_comemorativas")
        .select("*, modelos_mensagens(*)")
        .eq("clinica_id", clinica.id)
        .eq("ativo", true)
        .not("modelo_mensagem_id", "is", null)

      if (datasError) {
        console.error(`Erro ao buscar datas comemorativas da clínica ${clinica.id}:`, datasError)
        continue
      }

      // Filtrar datas que são hoje ou nos próximos dias (considerando antecedência)
      const datasRelevantes = datasComemoraticas.filter((data) => {
        const dataComemoracaoAtual = new Date(data.data)
        dataComemoracaoAtual.setFullYear(hoje.getFullYear()) // Ajustar para o ano atual

        // Se a data já passou este ano, considerar para o próximo ano
        if (dataComemoracaoAtual < hoje && !isSameDay(dataComemoracaoAtual, hoje)) {
          dataComemoracaoAtual.setFullYear(hoje.getFullYear() + 1)
        }

        // Calcular a data de envio considerando a antecedência
        const dataEnvio = addDays(dataComemoracaoAtual, -data.dias_antecedencia)

        // Verificar se é para enviar hoje
        return isSameDay(dataEnvio, hoje)
      })

      // Processar cada data comemorativa
      for (const dataComem of datasRelevantes) {
        if (!dataComem.modelos_mensagens) continue

        const modelo = dataComem.modelos_mensagens

        // Buscar pacientes da clínica
        const { data: pacientes, error: pacientesError } = await supabase
          .from("pacientes")
          .select("id, nome, email, telefone")
          .eq("clinica_id", clinica.id)

        if (pacientesError) {
          console.error(`Erro ao buscar pacientes da clínica ${clinica.id}:`, pacientesError)
          continue
        }

        // Formatar a data comemorativa
        const dataComemoracaoAtual = new Date(dataComem.data)
        dataComemoracaoAtual.setFullYear(hoje.getFullYear())
        if (dataComemoracaoAtual < hoje && !isSameDay(dataComemoracaoAtual, hoje)) {
          dataComemoracaoAtual.setFullYear(hoje.getFullYear() + 1)
        }

        const dataFormatada = format(dataComemoracaoAtual, "dd 'de' MMMM", { locale: ptBR })

        // Enviar mensagens para os pacientes
        for (const paciente of pacientes) {
          // Verificar se já enviamos mensagem hoje para esta data comemorativa
          const { data: jaEnviado, error: checkError } = await supabase
            .from("notificacoes")
            .select("id")
            .eq("clinica_id", clinica.id)
            .eq("paciente_id", paciente.id)
            .eq("tipo", modelo.canal)
            .like("mensagem", `%${dataComem.nome}%`)
            .gte("created_at", format(hoje, "yyyy-MM-dd"))
            .lt("created_at", format(addDays(hoje, 1), "yyyy-MM-dd"))
            .limit(1)

          if (!checkError && jaEnviado && jaEnviado.length > 0) {
            continue // Já enviamos mensagem hoje para este paciente
          }

          // Preparar a mensagem
          const mensagem = modelo.conteudo
            .replace(/{paciente}/g, paciente.nome)
            .replace(/{clinica}/g, clinica.nome)
            .replace(/{data_comemorativa}/g, dataComem.nome)
            .replace(/{data}/g, dataFormatada)

          // Enviar a mensagem de acordo com o canal
          let success = false

          if (modelo.canal === "email" && paciente.email) {
            success = await sendEmail(paciente.email, modelo.assunto || `${dataComem.nome} - ${clinica.nome}`, mensagem)
          } else if (modelo.canal === "sms" && paciente.telefone) {
            success = await sendSMS(paciente.telefone, mensagem)
          } else if (modelo.canal === "whatsapp" && paciente.telefone) {
            success = await sendWhatsApp(paciente.telefone, mensagem, clinica.id)
          }

          // Registrar a notificação
          if (success) {
            await supabase.from("notificacoes").insert({
              clinica_id: clinica.id,
              paciente_id: paciente.id,
              destinatario: modelo.canal === "email" ? paciente.email : paciente.telefone,
              tipo: modelo.canal,
              assunto: modelo.assunto || `${dataComem.nome} - ${clinica.nome}`,
              mensagem: mensagem,
              status: "enviado",
              data_envio: new Date().toISOString(),
              data_processamento: new Date().toISOString(),
            })
          }
        }
      }
    }
  } catch (error) {
    console.error("Erro ao processar mensagens de datas comemorativas:", error)
  }
}

// Função para processar lembretes de retorno
export async function processarLembretesRetorno(): Promise<void> {
  const supabase = createServerClient()

  try {
    // Buscar todas as clínicas ativas
    const { data: clinicas, error: clinicasError } = await supabase
      .from("clinicas")
      .select("id, nome")
      .eq("status", "ativo")

    if (clinicasError) {
      console.error("Erro ao buscar clínicas:", clinicasError)
      return
    }

    const hoje = new Date()

    // Processar cada clínica
    for (const clinica of clinicas) {
      // Verificar se a clínica tem configuração de mensagens automáticas
      const { data: config, error: configError } = await supabase
        .from("config_mensagens_automaticas")
        .select("retorno_ativo, retorno_modelo_id, retorno_dias_apos")
        .eq("clinica_id", clinica.id)
        .single()

      if (configError || !config || !config.retorno_ativo || !config.retorno_modelo_id) {
        continue // Pular esta clínica
      }

      // Buscar o modelo de mensagem
      const { data: modelo, error: modeloError } = await supabase
        .from("modelos_mensagens")
        .select("*")
        .eq("id", config.retorno_modelo_id)
        .single()

      if (modeloError || !modelo) {
        console.error(`Erro ao buscar modelo de mensagem para clínica ${clinica.id}:`, modeloError)
        continue
      }

      // Calcular a data para verificar os tratamentos concluídos
      const dataRetorno = addDays(hoje, -config.retorno_dias_apos)
      const dataRetornoStr = format(dataRetorno, "yyyy-MM-dd")

      // Buscar tratamentos concluídos na data de retorno
      const { data: tratamentos, error: tratamentosError } = await supabase
        .from("tratamentos")
        .select(`
          id, 
          nome, 
          status, 
          data_fim,
          paciente_id,
          pacientes (
            id, 
            nome, 
            email, 
            telefone
          )
        `)
        .eq("clinica_id", clinica.id)
        .eq("status", "concluido")
        .eq("data_fim", dataRetornoStr)

      if (tratamentosError) {
        console.error(`Erro ao buscar tratamentos da clínica ${clinica.id}:`, tratamentosError)
        continue
      }

      // Enviar mensagens para os pacientes com tratamentos concluídos
      for (const tratamento of tratamentos) {
        if (!tratamento.pacientes) continue

        const paciente = tratamento.pacientes

        // Verificar se já enviamos mensagem hoje para este tratamento
        const { data: jaEnviado, error: checkError } = await supabase
          .from("notificacoes")
          .select("id")
          .eq("clinica_id", clinica.id)
          .eq("paciente_id", paciente.id)
          .eq("tipo", modelo.canal)
          .like("mensagem", `%retorno%${tratamento.nome}%`)
          .gte("created_at", format(hoje, "yyyy-MM-dd"))
          .lt("created_at", format(addDays(hoje, 1), "yyyy-MM-dd"))
          .limit(1)

        if (!checkError && jaEnviado && jaEnviado.length > 0) {
          continue // Já enviamos mensagem hoje para este paciente
        }

        // Preparar a mensagem
        const mensagem = modelo.conteudo
          .replace(/{paciente}/g, paciente.nome)
          .replace(/{clinica}/g, clinica.nome)
          .replace(/{tratamento}/g, tratamento.nome)
          .replace(/{data_conclusao}/g, format(new Date(tratamento.data_fim), "dd/MM/yyyy"))

        // Enviar a mensagem de acordo com o canal
        let success = false

        if (modelo.canal === "email" && paciente.email) {
          success = await sendEmail(paciente.email, modelo.assunto || `Lembrete de Retorno - ${clinica.nome}`, mensagem)
        } else if (modelo.canal === "sms" && paciente.telefone) {
          success = await sendSMS(paciente.telefone, mensagem)
        } else if (modelo.canal === "whatsapp" && paciente.telefone) {
          success = await sendWhatsApp(paciente.telefone, mensagem, clinica.id)
        }

        // Registrar a notificação
        if (success) {
          await supabase.from("notificacoes").insert({
            clinica_id: clinica.id,
            paciente_id: paciente.id,
            destinatario: modelo.canal === "email" ? paciente.email : paciente.telefone,
            tipo: modelo.canal,
            assunto: modelo.assunto || `Lembrete de Retorno - ${clinica.nome}`,
            mensagem: mensagem,
            status: "enviado",
            data_envio: new Date().toISOString(),
            data_processamento: new Date().toISOString(),
          })
        }
      }
    }
  } catch (error) {
    console.error("Erro ao processar lembretes de retorno:", error)
  }
}

