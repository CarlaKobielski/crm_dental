import { createServerClient } from "./supabase"

export async function exportTableData(tableName: string) {
  const supabase = createServerClient()

  const { data, error } = await supabase.from(tableName).select("*")

  if (error) throw new Error(error.message)

  // Converter para JSON
  const jsonData = JSON.stringify(data, null, 2)

  return jsonData
}

export async function restoreTableData(tableName: string, data: any[]) {
  const supabase = createServerClient()

  // Primeiro limpa a tabela (cuidado!)
  const { error: deleteError } = await supabase.from(tableName).delete().neq("id", 0) // Condição para evitar exclusão acidental

  if (deleteError) throw new Error(`Erro ao limpar tabela ${tableName}: ${deleteError.message}`)

  // Insere os dados de backup
  const { error: insertError } = await supabase.from(tableName).insert(data)

  if (insertError) throw new Error(`Erro ao restaurar dados para ${tableName}: ${insertError.message}`)

  return { success: true, count: data.length }
}

