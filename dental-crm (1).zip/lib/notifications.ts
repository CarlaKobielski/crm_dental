import { createServerClient } from "./supabase"
import nodemailer from "nodemailer"
import { encrypt, decrypt } from "./encryption"
import axios from "axios"

// Configuração do serviço de e-mail
const emailTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.example.com",
  port: Number.parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_SECURE === "true",
  auth: {
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASSWORD || "",
  },
})

// Interface para dados de notificação
export interface NotificationData {
  to: string
  subject?: string
  message: string
  type: "email" | "sms" | "whatsapp"
  scheduledFor?: Date
}

// Função para enviar e-mail
export async function sendEmail(to: string, subject: string, message: string): Promise<boolean> {
  try {
    // Verificar configurações de e-mail
    if (!process.env.SMTP_USER || !process.env.SMTP_PASSWORD) {
      console.warn("Configurações de SMTP não encontradas. E-mail não enviado.")
      return false
    }

    const info = await emailTransporter.sendMail({
      from: process.env.SMTP_FROM || "noreply@dentalcrm.com",
      to,
      subject,
      html: message,
    })

    console.log("E-mail enviado:", info.messageId)
    return true
  } catch (error) {
    console.error("Erro ao enviar e-mail:", error)
    return false
  }
}

// Função para enviar SMS (simulada)
export async function sendSMS(to: string, message: string): Promise<boolean> {
  try {
    // Simulação de envio de SMS
    console.log(`SMS enviado para ${to}: ${message}`)

    // Aqui você integraria com um serviço real de SMS
    // Exemplo com Twilio (comentado):
    /*
    const client = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    await client.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to
    });
    */

    return true
  } catch (error) {
    console.error("Erro ao enviar SMS:", error)
    return false
  }
}

// Função para enviar mensagem pelo WhatsApp usando as credenciais da clínica
export async function sendWhatsApp(to: string, message: string, clinicaId: string): Promise<boolean> {
  try {
    // Buscar configurações de WhatsApp da clínica
    const supabase = createServerClient()
    const { data: configData, error: configError } = await supabase
      .from("configuracoes_notificacoes")
      .select("whatsapp_api_key, whatsapp_phone_number_id, whatsapp_provider")
      .eq("clinica_id", clinicaId)
      .single()

    if (configError || !configData) {
      console.warn("Configurações de WhatsApp não encontradas para a clínica:", clinicaId)
      return false
    }

    // Descriptografar a chave da API (assumindo que está criptografada)
    const apiKey = configData.whatsapp_api_key ? decrypt(configData.whatsapp_api_key) : null
    const phoneNumberId = configData.whatsapp_phone_number_id
    const provider = configData.whatsapp_provider || "meta"

    if (!apiKey || !phoneNumberId) {
      console.warn("Credenciais de WhatsApp incompletas para a clínica:", clinicaId)
      return false
    }

    // Formatar o número de telefone (remover caracteres não numéricos)
    const formattedNumber = to.replace(/\D/g, "")

    // Enviar mensagem de acordo com o provedor configurado
    if (provider === "meta") {
      // Usando a API oficial do WhatsApp Business Cloud
      const response = await axios({
        method: "POST",
        url: `https://graph.facebook.com/v17.0/${phoneNumberId}/messages`,
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        data: {
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: formattedNumber,
          type: "text",
          text: {
            body: message,
          },
        },
      })

      console.log("WhatsApp enviado via Meta API:", response.data)
      return true
    } else if (provider === "twilio") {
      // Usando Twilio para WhatsApp
      const twilioAccountSid = phoneNumberId.split(":")[0]
      const twilioAuthToken = apiKey
      const twilioWhatsAppNumber = phoneNumberId.split(":")[1]

      const twilio = require("twilio")(twilioAccountSid, twilioAuthToken)
      await twilio.messages.create({
        body: message,
        from: `whatsapp:${twilioWhatsAppNumber}`,
        to: `whatsapp:${formattedNumber}`,
      })

      console.log("WhatsApp enviado via Twilio")
      return true
    } else {
      console.warn("Provedor de WhatsApp não suportado:", provider)
      return false
    }
  } catch (error) {
    console.error("Erro ao enviar WhatsApp:", error)
    return false
  }
}

// Função para criar uma notificação no banco de dados
export async function createNotification(
  clinicaId: string,
  pacienteId: number,
  consultaId: number | null,
  data: NotificationData,
): Promise<number | null> {
  const supabase = createServerClient()

  try {
    // Criptografar dados sensíveis se necessário
    const encryptedMessage = encrypt(data.message)

    const { data: notification, error } = await supabase
      .from("notificacoes")
      .insert({
        clinica_id: clinicaId,
        paciente_id: pacienteId,
        consulta_id: consultaId,
        destinatario: data.to,
        tipo: data.type,
        assunto: data.subject || "",
        mensagem: encryptedMessage,
        status: "agendado",
        data_envio: data.scheduledFor ? data.scheduledFor.toISOString() : new Date().toISOString(),
      })
      .select()
      .single()

    if (error) throw error

    return notification.id
  } catch (error) {
    console.error("Erro ao criar notificação:", error)
    return null
  }
}

// Função para enviar notificação imediatamente
export async function sendNotification(data: NotificationData, clinicaId: string): Promise<boolean> {
  try {
    if (data.type === "email") {
      return await sendEmail(data.to, data.subject || "Lembrete de Consulta", data.message)
    } else if (data.type === "sms") {
      return await sendSMS(data.to, data.message)
    } else if (data.type === "whatsapp") {
      return await sendWhatsApp(data.to, data.message, clinicaId)
    }
    return false
  } catch (error) {
    console.error("Erro ao enviar notificação:", error)
    return false
  }
}

// Função para processar notificações agendadas
export async function processScheduledNotifications(): Promise<void> {
  const supabase = createServerClient()

  try {
    // Buscar notificações agendadas para envio
    const { data: notifications, error } = await supabase
      .from("notificacoes")
      .select("*, clinica_id")
      .eq("status", "agendado")
      .lte("data_envio", new Date().toISOString())

    if (error) throw error

    if (!notifications || notifications.length === 0) {
      return
    }

    console.log(`Processando ${notifications.length} notificações agendadas`)

    // Processar cada notificação
    for (const notification of notifications) {
      try {
        let success = false

        if (notification.tipo === "email") {
          success = await sendEmail(notification.destinatario, notification.assunto, decrypt(notification.mensagem))
        } else if (notification.tipo === "sms") {
          success = await sendSMS(notification.destinatario, decrypt(notification.mensagem))
        } else if (notification.tipo === "whatsapp") {
          success = await sendWhatsApp(
            notification.destinatario,
            decrypt(notification.mensagem),
            notification.clinica_id,
          )
        }

        // Atualizar status da notificação
        await supabase
          .from("notificacoes")
          .update({
            status: success ? "enviado" : "falha",
            data_processamento: new Date().toISOString(),
          })
          .eq("id", notification.id)
      } catch (error) {
        console.error(`Erro ao processar notificação ${notification.id}:`, error)

        // Marcar como falha
        await supabase
          .from("notificacoes")
          .update({
            status: "falha",
            data_processamento: new Date().toISOString(),
          })
          .eq("id", notification.id)
      }
    }
  } catch (error) {
    console.error("Erro ao processar notificações agendadas:", error)
  }
}

// Função para criar lembretes automáticos para consultas
export async function createAppointmentReminders(
  consultaId: number,
  pacienteId: number,
  pacienteNome: string,
  pacienteEmail: string,
  pacienteTelefone: string,
  dataConsulta: string,
  horaConsulta: string,
  clinicaId: string,
  clinicaNome: string,
): Promise<void> {
  try {
    // Buscar configurações de notificação da clínica
    const supabase = createServerClient()
    const { data: configData, error: configError } = await supabase
      .from("configuracoes_notificacoes")
      .select("*")
      .eq("clinica_id", clinicaId)
      .single()

    if (configError) {
      console.error("Erro ao buscar configurações de notificação:", configError)
      return
    }

    // Se não houver configurações, usar padrões
    const config = configData || {
      notificacoes_email_ativo: false,
      notificacoes_sms_ativo: false,
      notificacoes_whatsapp_ativo: true,
      template_email_consulta: "",
      template_sms_consulta: "",
      template_whatsapp_consulta:
        "Olá {paciente}, este é um lembrete para sua consulta agendada para {data} às {hora} na {clinica}. Caso precise remarcar, entre em contato conosco.",
      antecedencia_lembrete_horas: 24,
    }

    // Converter data e hora da consulta para objeto Date
    const consultaDate = new Date(`${dataConsulta}T${horaConsulta}`)

    // Criar lembrete para X horas antes (conforme configuração)
    const reminderDate = new Date(consultaDate)
    reminderDate.setHours(reminderDate.getHours() - config.antecedencia_lembrete_horas)

    // Formatar data e hora para exibição
    const dataFormatada = new Date(dataConsulta).toLocaleDateString("pt-BR")
    const horaFormatada = horaConsulta.substring(0, 5)

    // Template de WhatsApp
    if (config.notificacoes_whatsapp_ativo && pacienteTelefone && config.template_whatsapp_consulta) {
      const whatsappMessage = config.template_whatsapp_consulta
        .replace(/{paciente}/g, pacienteNome)
        .replace(/{data}/g, dataFormatada)
        .replace(/{hora}/g, horaFormatada)
        .replace(/{clinica}/g, clinicaNome)

      await createNotification(clinicaId, pacienteId, consultaId, {
        to: pacienteTelefone,
        message: whatsappMessage,
        type: "whatsapp",
        scheduledFor: reminderDate,
      })
    }

    // Manter código para e-mail e SMS (opcional)
    if (config.notificacoes_email_ativo && pacienteEmail && config.template_email_consulta) {
      const emailTemplate = config.template_email_consulta
        .replace(/{paciente}/g, pacienteNome)
        .replace(/{data}/g, dataFormatada)
        .replace(/{hora}/g, horaFormatada)
        .replace(/{clinica}/g, clinicaNome)

      await createNotification(clinicaId, pacienteId, consultaId, {
        to: pacienteEmail,
        subject: `Lembrete de Consulta - ${clinicaNome}`,
        message: emailTemplate,
        type: "email",
        scheduledFor: reminderDate,
      })
    }

    if (config.notificacoes_sms_ativo && pacienteTelefone && config.template_sms_consulta) {
      const smsTemplate = config.template_sms_consulta
        .replace(/{paciente}/g, pacienteNome)
        .replace(/{data}/g, dataFormatada)
        .replace(/{hora}/g, horaFormatada)
        .replace(/{clinica}/g, clinicaNome)

      await createNotification(clinicaId, pacienteId, consultaId, {
        to: pacienteTelefone,
        message: smsTemplate,
        type: "sms",
        scheduledFor: reminderDate,
      })
    }
  } catch (error) {
    console.error("Erro ao criar lembretes para consulta:", error)
  }
}

