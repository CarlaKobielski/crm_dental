import { supabase } from "./supabase"

export async function checkStorageAvailability(): Promise<boolean> {
  try {
    // Tentar listar os buckets para verificar se o Storage está disponível
    const { data, error } = await supabase.storage.listBuckets()

    if (error) {
      console.error("Erro ao verificar disponibilidade do Storage:", error)

      // Verificar se o erro é relacionado a RLS ou permissões
      if (error.message.includes("violates row-level security policy") || error.message.includes("permission denied")) {
        console.warn("Erro de permissão ao acessar Storage. Verifique as políticas RLS.")
      }

      return false
    }

    return true
  } catch (error) {
    console.error("Erro ao verificar disponibilidade do Storage:", error)
    return false
  }
}

