import { createServerClient } from "./supabase"
import { redirect } from "next/navigation"
import type { Session } from "@supabase/supabase-js"

// Verificar se o usuário está autenticado no servidor
export async function getSession(): Promise<Session | null> {
  const supabase = createServerClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()
  return session
}

// Verificar se o usuário está autenticado e redirecionar se não estiver
export async function requireAuth() {
  const session = await getSession()
  if (!session) {
    redirect("/login")
  }
  return session
}

// Verificar se o usuário tem uma função específica
export async function requireRole(role: string) {
  const session = await requireAuth()

  const supabase = createServerClient()
  const { data, error } = await supabase.from("perfis_usuario").select("funcao").eq("id", session.user.id).single()

  if (error || !data || data.funcao !== role) {
    redirect("/acesso-negado")
  }

  return session
}

// Obter o perfil do usuário atual
export async function getCurrentUserProfile() {
  const session = await getSession()
  if (!session) return null

  const supabase = createServerClient()
  const { data, error } = await supabase.from("perfis_usuario").select("*").eq("id", session.user.id).single()

  if (error) {
    console.error("Erro ao buscar perfil do usuário:", error)
    return null
  }

  return data
}

// Obter a clínica do usuário atual
export async function getCurrentUserClinic() {
  const profile = await getCurrentUserProfile()
  if (!profile || !profile.clinica_id) return null

  const supabase = createServerClient()
  const { data, error } = await supabase.from("clinicas").select("*").eq("id", profile.clinica_id).single()

  if (error) {
    console.error("Erro ao buscar clínica do usuário:", error)
    return null
  }

  return data
}

