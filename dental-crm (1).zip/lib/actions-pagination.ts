"use server"

import { createServerClient } from "./supabase"

export async function getPacientesPaginados(page = 1, limit = 10) {
  const supabase = createServerClient()
  const from = (page - 1) * limit
  const to = from + limit - 1

  const { data, error, count } = await supabase
    .from("pacientes")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, to)

  if (error) throw new Error(error.message)
  return { data, count }
}

export async function getConsultasPaginadas(page = 1, limit = 10) {
  const supabase = createServerClient()
  const from = (page - 1) * limit
  const to = from + limit - 1

  const { data, error, count } = await supabase
    .from("consultas")
    .select(
      `
      *,
      pacientes (
        id,
        nome
      )
    `,
      { count: "exact" },
    )
    .order("data", { ascending: true })
    .order("hora", { ascending: true })
    .range(from, to)

  if (error) throw new Error(error.message)
  return { data, count }
}

export async function getTratamentosPaginados(page = 1, limit = 10) {
  const supabase = createServerClient()
  const from = (page - 1) * limit
  const to = from + limit - 1

  const { data, error, count } = await supabase
    .from("tratamentos")
    .select(
      `
      *,
      pacientes (
        id,
        nome
      )
    `,
      { count: "exact" },
    )
    .order("created_at", { ascending: false })
    .range(from, to)

  if (error) throw new Error(error.message)
  return { data, count }
}

