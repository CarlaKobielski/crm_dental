import axios from "axios"
import { createServerClient } from "./supabase"
import { decrypt } from "./encryption"

// Interface para dados da NFS-e
interface NFSeData {
  clinicaId: string
  pacienteId: number
  valorTotal: number
  descricaoServico: string
  dataEmissao: string
  itensServico?: Array<{
    descricao: string
    quantidade: number
    valorUnitario: number
  }>
}

// Interface para configurações da API de NFS-e
interface NFSeConfig {
  provider: string
  apiKey: string
  apiSecret?: string
  inscricaoMunicipal: string
  cnpj: string
  ambiente: "producao" | "homologacao"
  codigoMunicipio: string
  codigoServico: string
}

// Classe para emissão de NFS-e
export class NFSeService {
  private config: NFSeConfig | null = null
  private clinicaId: string

  constructor(clinicaId: string) {
    this.clinicaId = clinicaId
  }

  // Carrega as configurações da clínica
  async loadConfig(): Promise<boolean> {
    try {
      const supabase = createServerClient()
      const { data, error } = await supabase.from("config_nfse").select("*").eq("clinica_id", this.clinicaId).single()

      if (error || !data) {
        console.error("Erro ao carregar configurações de NFS-e:", error)
        return false
      }

      // Descriptografar dados sensíveis
      this.config = {
        provider: data.provider,
        apiKey: decrypt(data.api_key),
        apiSecret: data.api_secret ? decrypt(data.api_secret) : undefined,
        inscricaoMunicipal: data.inscricao_municipal,
        cnpj: data.cnpj,
        ambiente: data.ambiente,
        codigoMunicipio: data.codigo_municipio,
        codigoServico: data.codigo_servico,
      }

      return true
    } catch (error) {
      console.error("Erro ao carregar configurações de NFS-e:", error)
      return false
    }
  }

  // Emite uma NFS-e
  async emitirNFSe(data: NFSeData): Promise<{ success: boolean; nfseId?: number; numero?: string; mensagem?: string }> {
    try {
      if (!this.config) {
        const configLoaded = await this.loadConfig()
        if (!configLoaded) {
          return { success: false, mensagem: "Configurações de NFS-e não encontradas" }
        }
      }

      // Buscar dados do paciente
      const supabase = createServerClient()
      const { data: paciente, error: pacienteError } = await supabase
        .from("pacientes")
        .select("nome, cpf, email, endereco")
        .eq("id", data.pacienteId)
        .single()

      if (pacienteError || !paciente) {
        return { success: false, mensagem: "Paciente não encontrado" }
      }

      // Buscar dados da clínica
      const { data: clinica, error: clinicaError } = await supabase
        .from("clinicas")
        .select("nome, endereco, telefone, email")
        .eq("id", this.clinicaId)
        .single()

      if (clinicaError || !clinica) {
        return { success: false, mensagem: "Clínica não encontrada" }
      }

      // Preparar dados para a API de acordo com o provedor
      let apiResponse

      switch (this.config.provider) {
        case "prefeitura_direta":
          // Integração direta com API da prefeitura
          apiResponse = await this.emitirNFSePrefeitura(data, paciente, clinica)
          break

        case "nfse_facil":
          // Integração com NFSe Fácil
          apiResponse = await this.emitirNFSeIntegrador(data, paciente, clinica)
          break

        default:
          return { success: false, mensagem: "Provedor de NFS-e não suportado" }
      }

      if (!apiResponse.success) {
        return apiResponse
      }

      // Salvar a NFS-e no banco de dados
      const { data: nfseData, error: nfseError } = await supabase
        .from("notas_fiscais")
        .insert({
          clinica_id: this.clinicaId,
          paciente_id: data.pacienteId,
          numero: apiResponse.numero,
          valor: data.valorTotal,
          data_emissao: data.dataEmissao,
          status: "emitida",
          url_pdf: apiResponse.urlPdf,
          xml: apiResponse.xml,
          codigo_verificacao: apiResponse.codigoVerificacao,
          observacoes: data.descricaoServico,
        })
        .select()
        .single()

      if (nfseError) {
        console.error("Erro ao salvar NFS-e no banco de dados:", nfseError)
        return {
          success: true,
          nfseId: 0,
          numero: apiResponse.numero,
          mensagem: "NFS-e emitida, mas houve erro ao salvar no banco de dados",
        }
      }

      return {
        success: true,
        nfseId: nfseData.id,
        numero: apiResponse.numero,
        mensagem: "NFS-e emitida com sucesso",
      }
    } catch (error) {
      console.error("Erro ao emitir NFS-e:", error)
      return {
        success: false,
        mensagem: "Erro ao emitir NFS-e: " + (error instanceof Error ? error.message : String(error)),
      }
    }
  }

  // Método para emissão via API da prefeitura
  private async emitirNFSePrefeitura(data: NFSeData, paciente: any, clinica: any): Promise<any> {
    try {
      // Exemplo de integração com API da prefeitura (varia de acordo com cada município)
      const response = await axios({
        method: "POST",
        url: `https://nfse.${this.config?.codigoMunicipio}.gov.br/api/v1/nfse`,
        headers: {
          Authorization: `Bearer ${this.config?.apiKey}`,
          "Content-Type": "application/json",
        },
        data: {
          prestador: {
            cnpj: this.config?.cnpj,
            inscricaoMunicipal: this.config?.inscricaoMunicipal,
          },
          tomador: {
            cpfCnpj: paciente.cpf,
            nome: paciente.nome,
            email: paciente.email,
            endereco: paciente.endereco,
          },
          servico: {
            codigo: this.config?.codigoServico,
            descricao: data.descricaoServico,
            valorServicos: data.valorTotal,
          },
          dataEmissao: data.dataEmissao,
        },
      })

      return {
        success: true,
        numero: response.data.numero,
        urlPdf: response.data.urlPdf,
        xml: response.data.xml,
        codigoVerificacao: response.data.codigoVerificacao,
      }
    } catch (error) {
      console.error("Erro na emissão via API da prefeitura:", error)
      return { success: false, mensagem: "Erro na emissão via API da prefeitura" }
    }
  }

  // Método para emissão via integrador
  private async emitirNFSeIntegrador(data: NFSeData, paciente: any, clinica: any): Promise<any> {
    try {
      // Exemplo de integração com serviço integrador de NFS-e
      const response = await axios({
        method: "POST",
        url: "https://api.nfsefacil.com.br/v1/nfse",
        headers: {
          "X-API-KEY": this.config?.apiKey,
          "Content-Type": "application/json",
        },
        data: {
          ambiente: this.config?.ambiente,
          municipio: this.config?.codigoMunicipio,
          prestador: {
            cnpj: this.config?.cnpj,
            inscricaoMunicipal: this.config?.inscricaoMunicipal,
            razaoSocial: clinica.nome,
            endereco: clinica.endereco,
          },
          tomador: {
            cpf: paciente.cpf,
            nome: paciente.nome,
            email: paciente.email,
            endereco: paciente.endereco,
          },
          servico: {
            codigo: this.config?.codigoServico,
            descricao: data.descricaoServico,
            valor: data.valorTotal,
          },
          itens: data.itensServico || [],
        },
      })

      return {
        success: true,
        numero: response.data.numero,
        urlPdf: response.data.urlPdf,
        xml: response.data.xml,
        codigoVerificacao: response.data.codigoVerificacao,
      }
    } catch (error) {
      console.error("Erro na emissão via integrador:", error)
      return { success: false, mensagem: "Erro na emissão via integrador" }
    }
  }

  // Método para cancelar uma NFS-e
  async cancelarNFSe(nfseId: number, motivo: string): Promise<{ success: boolean; mensagem: string }> {
    try {
      if (!this.config) {
        const configLoaded = await this.loadConfig()
        if (!configLoaded) {
          return { success: false, mensagem: "Configurações de NFS-e não encontradas" }
        }
      }

      // Buscar dados da NFS-e
      const supabase = createServerClient()
      const { data: nfse, error: nfseError } = await supabase
        .from("notas_fiscais")
        .select("*")
        .eq("id", nfseId)
        .eq("clinica_id", this.clinicaId)
        .single()

      if (nfseError || !nfse) {
        return { success: false, mensagem: "NFS-e não encontrada" }
      }

      if (nfse.status === "cancelada") {
        return { success: false, mensagem: "NFS-e já está cancelada" }
      }

      // Cancelar NFS-e na API de acordo com o provedor
      let apiResponse

      switch (this.config.provider) {
        case "prefeitura_direta":
          apiResponse = await axios({
            method: "POST",
            url: `https://nfse.${this.config.codigoMunicipio}.gov.br/api/v1/nfse/${nfse.numero}/cancelamento`,
            headers: {
              Authorization: `Bearer ${this.config.apiKey}`,
              "Content-Type": "application/json",
            },
            data: {
              motivo: motivo,
            },
          })
          break

        case "nfse_facil":
          apiResponse = await axios({
            method: "POST",
            url: "https://api.nfsefacil.com.br/v1/nfse/cancelar",
            headers: {
              "X-API-KEY": this.config.apiKey,
              "Content-Type": "application/json",
            },
            data: {
              numero: nfse.numero,
              codigoVerificacao: nfse.codigo_verificacao,
              motivo: motivo,
            },
          })
          break

        default:
          return { success: false, mensagem: "Provedor de NFS-e não suportado" }
      }

      // Atualizar status da NFS-e no banco de dados
      const { error: updateError } = await supabase
        .from("notas_fiscais")
        .update({
          status: "cancelada",
          observacoes: `${nfse.observacoes} | Cancelada em ${new Date().toISOString()} - Motivo: ${motivo}`,
        })
        .eq("id", nfseId)

      if (updateError) {
        console.error("Erro ao atualizar status da NFS-e:", updateError)
        return { success: true, mensagem: "NFS-e cancelada, mas houve erro ao atualizar o banco de dados" }
      }

      return { success: true, mensagem: "NFS-e cancelada com sucesso" }
    } catch (error) {
      console.error("Erro ao cancelar NFS-e:", error)
      return {
        success: false,
        mensagem: "Erro ao cancelar NFS-e: " + (error instanceof Error ? error.message : String(error)),
      }
    }
  }
}

