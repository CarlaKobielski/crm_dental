import { createServerClient } from "./supabase"
import { PDFDocument, rgb, StandardFonts } from "pdf-lib"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

// Interface para dados do recibo
interface ReciboData {
  clinicaId: string
  pacienteId: number
  contaReceberId?: number
  valor: number
  descricao: string
  dataEmissao: string
}

// Classe para geração de recibos
export class ReciboService {
  private clinicaId: string

  constructor(clinicaId: string) {
    this.clinicaId = clinicaId
  }

  // Gera um recibo e salva no banco de dados
  async gerarRecibo(
    data: ReciboData,
  ): Promise<{ success: boolean; reciboId?: number; url?: string; mensagem?: string }> {
    try {
      // Buscar dados do paciente
      const supabase = createServerClient()
      const { data: paciente, error: pacienteError } = await supabase
        .from("pacientes")
        .select("nome, cpf")
        .eq("id", data.pacienteId)
        .single()

      if (pacienteError || !paciente) {
        return { success: false, mensagem: "Paciente não encontrado" }
      }

      // Buscar dados da clínica
      const { data: clinica, error: clinicaError } = await supabase
        .from("clinicas")
        .select("nome, endereco, telefone, email, cnpj")
        .eq("id", this.clinicaId)
        .single()

      if (clinicaError || !clinica) {
        return { success: false, mensagem: "Clínica não encontrada" }
      }

      // Gerar número sequencial para o recibo
      const { data: ultimoRecibo, error: reciboError } = await supabase
        .from("recibos")
        .select("numero")
        .eq("clinica_id", this.clinicaId)
        .order("id", { ascending: false })
        .limit(1)
        .single()

      let numeroRecibo = "00001"
      if (!reciboError && ultimoRecibo) {
        const ultimoNumero = Number.parseInt(ultimoRecibo.numero)
        numeroRecibo = (ultimoNumero + 1).toString().padStart(5, "0")
      }

      // Gerar PDF do recibo
      const pdfBytes = await this.gerarPdfRecibo({
        numeroRecibo,
        dataEmissao: data.dataEmissao,
        valor: data.valor,
        descricao: data.descricao,
        paciente: {
          nome: paciente.nome,
          cpf: paciente.cpf,
        },
        clinica: {
          nome: clinica.nome,
          endereco: clinica.endereco,
          telefone: clinica.telefone,
          email: clinica.email,
          cnpj: clinica.cnpj,
        },
      })

      // Salvar PDF no storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("recibos")
        .upload(`${this.clinicaId}/${numeroRecibo}_${format(new Date(data.dataEmissao), "yyyyMMdd")}.pdf`, pdfBytes, {
          contentType: "application/pdf",
          upsert: false,
        })

      if (uploadError) {
        console.error("Erro ao fazer upload do recibo:", uploadError)
        return { success: false, mensagem: "Erro ao salvar o PDF do recibo" }
      }

      // Obter URL pública do arquivo
      const { data: urlData } = supabase.storage.from("recibos").getPublicUrl(uploadData.path)

      // Salvar recibo no banco de dados
      const { data: reciboData, error: saveError } = await supabase
        .from("recibos")
        .insert({
          clinica_id: this.clinicaId,
          paciente_id: data.pacienteId,
          conta_receber_id: data.contaReceberId,
          numero: numeroRecibo,
          valor: data.valor,
          data_emissao: data.dataEmissao,
          descricao: data.descricao,
          url_pdf: urlData.publicUrl,
        })
        .select()
        .single()

      if (saveError) {
        console.error("Erro ao salvar recibo no banco de dados:", saveError)
        return { success: false, mensagem: "Erro ao salvar o recibo no banco de dados" }
      }

      // Se houver uma conta a receber associada, atualizar seu status
      if (data.contaReceberId) {
        await supabase
          .from("contas_receber")
          .update({
            status: "pago",
            data_pagamento: data.dataEmissao,
          })
          .eq("id", data.contaReceberId)
      }

      return {
        success: true,
        reciboId: reciboData.id,
        url: urlData.publicUrl,
        mensagem: "Recibo gerado com sucesso",
      }
    } catch (error) {
      console.error("Erro ao gerar recibo:", error)
      return {
        success: false,
        mensagem: "Erro ao gerar recibo: " + (error instanceof Error ? error.message : String(error)),
      }
    }
  }

  // Gera o PDF do recibo
  private async gerarPdfRecibo(dados: any): Promise<Uint8Array> {
    // Criar um novo documento PDF
    const pdfDoc = await PDFDocument.create()
    const page = pdfDoc.addPage([595.28, 841.89]) // A4
    const { width, height } = page.getSize()

    // Carregar fontes
    const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica)
    const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold)

    // Configurações de texto
    const fontSize = 12
    const lineHeight = fontSize * 1.5

    // Título
    page.drawText("RECIBO", {
      x: width / 2 - fontBold.widthOfTextAtSize("RECIBO", 24) / 2,
      y: height - 50,
      size: 24,
      font: fontBold,
      color: rgb(0, 0, 0),
    })

    // Número do recibo
    page.drawText(`Nº ${dados.numeroRecibo}`, {
      x: width / 2 - fontRegular.widthOfTextAtSize(`Nº ${dados.numeroRecibo}`, 14) / 2,
      y: height - 80,
      size: 14,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    // Valor
    const valorFormatado = `R$ ${dados.valor.toFixed(2).replace(".", ",")}`
    page.drawText(`Valor: ${valorFormatado}`, {
      x: width - 200,
      y: height - 120,
      size: 14,
      font: fontBold,
      color: rgb(0, 0, 0),
    })

    // Data
    const dataFormatada = format(new Date(dados.dataEmissao), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
    page.drawText(`Data: ${dataFormatada}`, {
      x: 50,
      y: height - 120,
      size: 12,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    // Linha separadora
    page.drawLine({
      start: { x: 50, y: height - 140 },
      end: { x: width - 50, y: height - 140 },
      thickness: 1,
      color: rgb(0, 0, 0),
    })

    // Dados da clínica
    page.drawText(`${dados.clinica.nome}`, {
      x: 50,
      y: height - 170,
      size: 14,
      font: fontBold,
      color: rgb(0, 0, 0),
    })

    page.drawText(`CNPJ: ${dados.clinica.cnpj}`, {
      x: 50,
      y: height - 170 - lineHeight,
      size: fontSize,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    page.drawText(`${dados.clinica.endereco}`, {
      x: 50,
      y: height - 170 - lineHeight * 2,
      size: fontSize,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    page.drawText(`Tel: ${dados.clinica.telefone} | Email: ${dados.clinica.email}`, {
      x: 50,
      y: height - 170 - lineHeight * 3,
      size: fontSize,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    // Linha separadora
    page.drawLine({
      start: { x: 50, y: height - 170 - lineHeight * 4 },
      end: { x: width - 50, y: height - 170 - lineHeight * 4 },
      thickness: 1,
      color: rgb(0, 0, 0),
    })

    // Texto do recibo
    const textoRecibo = `Recebi(emos) de ${dados.paciente.nome}, CPF ${dados.paciente.cpf}, a importância de ${valorPorExtenso(dados.valor)} (${valorFormatado}) referente a ${dados.descricao}.`

    // Quebrar o texto em linhas
    const palavras = textoRecibo.split(" ")
    let linhaAtual = ""
    const linhas = []
    const maxWidth = width - 100

    for (const palavra of palavras) {
      const testeLinha = linhaAtual ? `${linhaAtual} ${palavra}` : palavra
      if (fontRegular.widthOfTextAtSize(testeLinha, fontSize) <= maxWidth) {
        linhaAtual = testeLinha
      } else {
        linhas.push(linhaAtual)
        linhaAtual = palavra
      }
    }
    if (linhaAtual) {
      linhas.push(linhaAtual)
    }

    // Desenhar as linhas do texto
    let yPos = height - 170 - lineHeight * 5
    for (const linha of linhas) {
      page.drawText(linha, {
        x: 50,
        y: yPos,
        size: fontSize,
        font: fontRegular,
        color: rgb(0, 0, 0),
      })
      yPos -= lineHeight
    }

    // Assinatura
    yPos = height - 500
    page.drawLine({
      start: { x: width / 2 - 100, y: yPos },
      end: { x: width / 2 + 100, y: yPos },
      thickness: 1,
      color: rgb(0, 0, 0),
    })

    page.drawText(dados.clinica.nome, {
      x: width / 2 - fontRegular.widthOfTextAtSize(dados.clinica.nome, fontSize) / 2,
      y: yPos - lineHeight,
      size: fontSize,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    // Rodapé
    page.drawText(`Documento emitido eletronicamente - ${dados.clinica.nome}`, {
      x: width / 2 - fontRegular.widthOfTextAtSize(`Documento emitido eletronicamente - ${dados.clinica.nome}`, 10) / 2,
      y: 50,
      size: 10,
      font: fontRegular,
      color: rgb(0, 0, 0),
    })

    // Serializar o documento para bytes
    return await pdfDoc.save()
  }
}

// Função auxiliar para converter valor numérico em texto por extenso
function valorPorExtenso(valor: number): string {
  // Implementação simplificada - em produção, usar uma biblioteca específica
  const unidades = ["", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
  const dezenas = ["", "dez", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
  const dezenasEspeciais = [
    "dez",
    "onze",
    "doze",
    "treze",
    "quatorze",
    "quinze",
    "dezesseis",
    "dezessete",
    "dezoito",
    "dezenove",
  ]

  // Simplificação para valores até 999,99
  const reais = Math.floor(valor)
  const centavos = Math.round((valor - reais) * 100)

  let extenso = ""

  if (reais === 0 && centavos === 0) {
    return "zero reais"
  }

  if (reais > 0) {
    if (reais === 1) {
      extenso = "um real"
    } else {
      const centena = Math.floor(reais / 100)
      const dezena = Math.floor((reais % 100) / 10)
      const unidade = reais % 10

      if (centena > 0) {
        if (centena === 1) {
          if (dezena === 0 && unidade === 0) {
            extenso += "cem"
          } else {
            extenso += "cento e "
          }
        } else {
          // Simplificação - implementação completa usaria array de centenas
          extenso += unidades[centena] + "centos"
          if (dezena > 0 || unidade > 0) extenso += " e "
        }
      }

      if (dezena > 0) {
        if (dezena === 1) {
          extenso += dezenasEspeciais[unidade]
        } else {
          extenso += dezenas[dezena]
          if (unidade > 0) extenso += " e " + unidades[unidade]
        }
      } else if (unidade > 0) {
        extenso += unidades[unidade]
      }

      extenso += " reais"
    }
  }

  if (centavos > 0) {
    if (reais > 0) extenso += " e "

    if (centavos === 1) {
      extenso += "um centavo"
    } else {
      const dezena = Math.floor(centavos / 10)
      const unidade = centavos % 10

      if (dezena > 0) {
        if (dezena === 1) {
          extenso += dezenasEspeciais[unidade]
        } else {
          extenso += dezenas[dezena]
          if (unidade > 0) extenso += " e " + unidades[unidade]
        }
      } else {
        extenso += unidades[unidade]
      }

      extenso += " centavos"
    }
  }

  return extenso
}

