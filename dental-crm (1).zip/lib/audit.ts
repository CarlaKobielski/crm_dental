import { createServerClient } from "./supabase"

export async function logAuditEvent(
  userId: string,
  action: string,
  resource: string,
  resourceId: string,
  details: any,
) {
  const supabase = createServerClient()

  const { error } = await supabase.from("audit_logs").insert([
    {
      user_id: userId,
      action,
      resource,
      resource_id: resourceId,
      details,
      ip_address: "0.0.0.0", // Em produção, obtenha o IP real
      timestamp: new Date().toISOString(),
    },
  ])

  if (error) console.error("Erro ao registrar log de auditoria:", error)
}

