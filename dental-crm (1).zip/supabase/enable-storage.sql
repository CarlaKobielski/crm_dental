-- Habilitar a extensão de armazenamento se ainda não estiver habilitada
CREATE EXTENSION IF NOT EXISTS "pg_net";
CREATE EXTENSION IF NOT EXISTS "pgsodium";

-- Verificar se o esquema storage existe
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'storage') THEN
    -- Criar o esquema storage se não existir
    CREATE SCHEMA storage;
    
    -- Criar a tabela de buckets
    CREATE TABLE storage.buckets (
      id text NOT NULL,
      name text NOT NULL,
      owner uuid,
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now(),
      public boolean DEFAULT false,
      avif_autodetection boolean DEFAULT false,
      file_size_limit bigint,
      allowed_mime_types text[],
      PRIMARY KEY (id)
    );
    
    -- Criar a tabela de objetos
    CREATE TABLE storage.objects (
      id uuid NOT NULL DEFAULT gen_random_uuid(),
      bucket_id text,
      name text,
      owner uuid,
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now(),
      last_accessed_at timestamptz DEFAULT now(),
      metadata jsonb,
      path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/')) STORED,
      PRIMARY KEY (id),
      CONSTRAINT objects_bucketid_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id)
    );
    
    -- Habilitar RLS nas tabelas
    ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

