-- Tabela de categorias de produtos
CREATE TABLE IF NOT EXISTS categorias_produtos (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  descricao TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de produtos
CREATE TABLE IF NOT EXISTS produtos (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  categoria_id INTEGER REFERENCES categorias_produtos(id) ON DELETE SET NULL,
  codigo TEXT,
  nome TEXT NOT NULL,
  descricao TEXT,
  unidade TEXT NOT NULL,
  quantidade_minima INTEGER DEFAULT 0,
  quantidade_atual INTEGER DEFAULT 0,
  valor_custo DECIMAL(10, 2),
  valor_venda DECIMAL(10, 2),
  localizacao TEXT,
  imagem_url TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de movimentações de estoque
CREATE TABLE IF NOT EXISTS movimentacoes_estoque (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  produto_id INTEGER REFERENCES produtos(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL CHECK (tipo IN ('entrada', 'saida', 'ajuste')),
  quantidade INTEGER NOT NULL,
  motivo TEXT NOT NULL,
  valor_unitario DECIMAL(10, 2),
  fornecedor_id INTEGER REFERENCES fornecedores(id) ON DELETE SET NULL,
  paciente_id INTEGER REFERENCES pacientes(id) ON DELETE SET NULL,
  consulta_id INTEGER REFERENCES consultas(id) ON DELETE SET NULL,
  usuario_id UUID REFERENCES perfis_usuario(id) ON DELETE SET NULL,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de pedidos a fornecedores
CREATE TABLE IF NOT EXISTS pedidos_fornecedores (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  fornecedor_id INTEGER REFERENCES fornecedores(id) ON DELETE SET NULL,
  numero_pedido TEXT,
  data_pedido DATE NOT NULL,
  data_entrega_prevista DATE,
  data_entrega_real DATE,
  status TEXT NOT NULL CHECK (status IN ('pendente', 'parcial', 'entregue', 'cancelado')),
  valor_total DECIMAL(10, 2),
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de itens de pedido
CREATE TABLE IF NOT EXISTS itens_pedido (
  id SERIAL PRIMARY KEY,
  pedido_id INTEGER REFERENCES pedidos_fornecedores(id) ON DELETE CASCADE,
  produto_id INTEGER REFERENCES produtos(id) ON DELETE CASCADE,
  quantidade_pedida INTEGER NOT NULL,
  quantidade_recebida INTEGER DEFAULT 0,
  valor_unitario DECIMAL(10, 2) NOT NULL,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_categorias_produtos_clinica_id ON categorias_produtos(clinica_id);
CREATE INDEX IF NOT EXISTS idx_produtos_clinica_id ON produtos(clinica_id);
CREATE INDEX IF NOT EXISTS idx_produtos_categoria_id ON produtos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_movimentacoes_estoque_clinica_id ON movimentacoes_estoque(clinica_id);
CREATE INDEX IF NOT EXISTS idx_movimentacoes_estoque_produto_id ON movimentacoes_estoque(produto_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_fornecedores_clinica_id ON pedidos_fornecedores(clinica_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_fornecedores_fornecedor_id ON pedidos_fornecedores(fornecedor_id);
CREATE INDEX IF NOT EXISTS idx_itens_pedido_pedido_id ON itens_pedido(pedido_id);
CREATE INDEX IF NOT EXISTS idx_itens_pedido_produto_id ON itens_pedido(produto_id);

-- Habilitar RLS
ALTER TABLE categorias_produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE movimentacoes_estoque ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos_fornecedores ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_pedido ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Usuários só podem ver categorias de produtos da sua clínica" ON categorias_produtos
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = categorias_produtos.clinica_id));

CREATE POLICY "Usuários só podem modificar categorias de produtos da sua clínica" ON categorias_produtos
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = categorias_produtos.clinica_id));

CREATE POLICY "Usuários só podem ver produtos da sua clínica" ON produtos
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = produtos.clinica_id));

CREATE POLICY "Usuários só podem modificar produtos da sua clínica" ON produtos
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = produtos.clinica_id));

CREATE POLICY "Usuários só podem ver movimentações de estoque da sua clínica" ON movimentacoes_estoque
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = movimentacoes_estoque.clinica_id));

CREATE POLICY "Usuários só podem modificar movimentações de estoque da sua clínica" ON movimentacoes_estoque
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = movimentacoes_estoque.clinica_id));

CREATE POLICY "Usuários só podem ver pedidos a fornecedores da sua clínica" ON pedidos_fornecedores
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = pedidos_fornecedores.clinica_id));

CREATE POLICY "Usuários só podem modificar pedidos a fornecedores da sua clínica" ON pedidos_fornecedores
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = pedidos_fornecedores.clinica_id));

-- Para itens_pedido, usamos o pedido_id para verificar a clínica
CREATE POLICY "Usuários só podem ver itens de pedido da sua clínica" ON itens_pedido
FOR SELECT USING (
  auth.uid() IN (
    SELECT pu.id FROM perfis_usuario pu
    JOIN pedidos_fornecedores pf ON pu.clinica_id = pf.clinica_id
    WHERE pf.id = itens_pedido.pedido_id
  )
);

CREATE POLICY "Usuários só podem modificar itens de pedido da sua clínica" ON itens_pedido
FOR ALL USING (
  auth.uid() IN (
    SELECT pu.id FROM perfis_usuario pu
    JOIN pedidos_fornecedores pf ON pu.clinica_id = pf.clinica_id
    WHERE pf.id = itens_pedido.pedido_id
  )
);

