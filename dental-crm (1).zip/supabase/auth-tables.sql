-- Tabela de clínicas (tenants)
CREATE TABLE IF NOT EXISTS clinicas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome TEXT NOT NULL,
  endereco TEXT,
  telefone TEXT,
  email TEXT,
  site TEXT,
  logo_url TEXT,
  plano TEXT NOT NULL DEFAULT 'trial',
  status TEXT NOT NULL DEFAULT 'ativo',
  data_expiracao TIMESTAMP WITH TIME ZONE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  criado_por UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de perfis de usuário
CREATE TABLE IF NOT EXISTS perfis_usuario (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  email TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  clinica_id UUID REFERENCES clinicas(id),
  funcao TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativo',
  ultimo_acesso TIMESTAMP WITH TIME ZONE,
  onboarding_completo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Habilitar RLS para as tabelas
ALTER TABLE clinicas ENABLE ROW LEVEL SECURITY;
ALTER TABLE perfis_usuario ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para clínicas
CREATE POLICY IF NOT EXISTS "Usuários podem ver sua própria clínica" ON clinicas
FOR SELECT
USING (auth.uid() IN (
  SELECT id FROM perfis_usuario WHERE clinica_id = clinicas.id
));

CREATE POLICY IF NOT EXISTS "Usuários podem inserir clínicas" ON clinicas
FOR INSERT
WITH CHECK (auth.uid() = criado_por);

CREATE POLICY IF NOT EXISTS "Apenas administradores podem editar clínicas" ON clinicas
FOR UPDATE
USING (auth.uid() IN (
  SELECT id FROM perfis_usuario WHERE clinica_id = clinicas.id AND funcao = 'admin'
));

-- Políticas RLS para perfis de usuário
CREATE POLICY IF NOT EXISTS "Usuários podem ver perfis da mesma clínica" ON perfis_usuario
FOR SELECT
USING (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = perfis_usuario.clinica_id
  ) OR auth.uid() = perfis_usuario.id
);

CREATE POLICY IF NOT EXISTS "Usuários podem inserir seu próprio perfil" ON perfis_usuario
FOR INSERT
WITH CHECK (auth.uid() = id);

CREATE POLICY IF NOT EXISTS "Usuários podem atualizar seu próprio perfil" ON perfis_usuario
FOR UPDATE
USING (auth.uid() = id);

CREATE POLICY IF NOT EXISTS "Apenas administradores podem gerenciar outros usuários" ON perfis_usuario
FOR ALL
USING (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = perfis_usuario.clinica_id AND funcao = 'admin'
  ) OR auth.uid() = perfis_usuario.id
);

