-- Tabela de clínicas (tenants)
CREATE TABLE IF NOT EXISTS clinicas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome TEXT NOT NULL,
  endereco TEXT,
  telefone TEXT,
  email TEXT,
  site TEXT,
  logo_url TEXT,
  plano TEXT NOT NULL DEFAULT 'trial',
  status TEXT NOT NULL DEFAULT 'ativo',
  data_expiracao TIMESTAMP WITH TIME ZONE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  criado_por UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de perfis de usuário
CREATE TABLE IF NOT EXISTS perfis_usuario (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  email TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  clinica_id UUID REFERENCES clinicas(id),
  funcao TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativo',
  ultimo_acesso TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Modificar tabelas existentes para incluir clinica_id
ALTER TABLE pacientes ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE consultas ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE tratamentos ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE financeiro ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE prontuarios ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE documentos ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE lembretes ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);
ALTER TABLE configuracoes_sistema ADD COLUMN IF NOT EXISTS clinica_id UUID REFERENCES clinicas(id);

-- Políticas RLS para isolamento de dados entre clínicas
-- Clínicas
ALTER TABLE clinicas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários podem ver sua própria clínica" ON clinicas
  FOR SELECT
  USING (auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = clinicas.id
  ));

CREATE POLICY "Apenas administradores podem editar clínicas" ON clinicas
  FOR UPDATE
  USING (auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = clinicas.id AND funcao = 'admin'
  ));

-- Perfis de usuário
ALTER TABLE perfis_usuario ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários podem ver perfis da mesma clínica" ON perfis_usuario
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = perfis_usuario.clinica_id
    )
  );

CREATE POLICY "Apenas administradores podem gerenciar usuários" ON perfis_usuario
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = perfis_usuario.clinica_id AND funcao = 'admin'
    )
  );

-- Pacientes
ALTER TABLE pacientes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários só podem ver pacientes da sua clínica" ON pacientes
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = pacientes.clinica_id
    )
  );

CREATE POLICY "Usuários só podem modificar pacientes da sua clínica" ON pacientes
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = pacientes.clinica_id
    )
  );

-- Aplicar políticas semelhantes para as outras tabelas
-- Consultas
ALTER TABLE consultas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários só podem ver consultas da sua clínica" ON consultas
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = consultas.clinica_id
    )
  );

CREATE POLICY "Usuários só podem modificar consultas da sua clínica" ON consultas
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = consultas.clinica_id
    )
  );

-- Tratamentos
ALTER TABLE tratamentos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Usuários só podem ver tratamentos da sua clínica" ON tratamentos
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = tratamentos.clinica_id
    )
  );

CREATE POLICY "Usuários só podem modificar tratamentos da sua clínica" ON tratamentos
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = tratamentos.clinica_id
    )
  );

