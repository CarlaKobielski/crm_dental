-- Habilitar o armazenamento RLS
ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Política para permitir leitura de buckets para todos os usuários
CREATE POLICY "Permitir leitura de buckets para todos" ON storage.buckets
FOR SELECT
USING (true);

-- Política para permitir criação de buckets para usuários autenticados
CREATE POLICY "Permitir criação de buckets para usuários autenticados" ON storage.buckets
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Política para permitir leitura de arquivos para todos
CREATE POLICY "Permitir leitura de arquivos para todos" ON storage.objects
FOR SELECT
USING (true);

-- Política para permitir upload de arquivos para usuários autenticados
CREATE POLICY "Permitir upload para usuários autenticados" ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Política para permitir atualização de arquivos para usuários autenticados
CREATE POLICY "Permitir atualização para usuários autenticados" ON storage.objects
FOR UPDATE
TO authenticated
USING (true);

-- Política para permitir exclusão de arquivos para usuários autenticados
CREATE POLICY "Permitir exclusão para usuários autenticados" ON storage.objects
FOR DELETE
TO authenticated
USING (true);

