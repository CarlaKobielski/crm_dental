-- Tabela de contas a receber
CREATE TABLE IF NOT EXISTS contas_receber (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
  tratamento_id INTEGER REFERENCES tratamentos(id) ON DELETE SET NULL,
  descricao TEXT NOT NULL,
  valor DECIMAL(10, 2) NOT NULL,
  data_vencimento DATE NOT NULL,
  data_pagamento DATE,
  status TEXT NOT NULL CHECK (status IN ('pendente', 'pago', 'atrasado', 'cancelado')),
  forma_pagamento TEXT,
  parcela INTEGER,
  total_parcelas INTEGER,
  observacoes TEXT,
  nfs_id INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de contas a pagar
CREATE TABLE IF NOT EXISTS contas_pagar (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  fornecedor_id INTEGER REFERENCES fornecedores(id) ON DELETE SET NULL,
  categoria TEXT NOT NULL,
  descricao TEXT NOT NULL,
  valor DECIMAL(10, 2) NOT NULL,
  data_vencimento DATE NOT NULL,
  data_pagamento DATE,
  status TEXT NOT NULL CHECK (status IN ('pendente', 'pago', 'atrasado', 'cancelado')),
  forma_pagamento TEXT,
  comprovante_url TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de fornecedores
CREATE TABLE IF NOT EXISTS fornecedores (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL,
  cnpj TEXT,
  endereco TEXT,
  telefone TEXT,
  email TEXT,
  contato TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de notas fiscais
CREATE TABLE IF NOT EXISTS notas_fiscais (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
  numero TEXT NOT NULL,
  serie TEXT,
  valor DECIMAL(10, 2) NOT NULL,
  data_emissao DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('emitida', 'cancelada')),
  url_pdf TEXT,
  xml TEXT,
  codigo_verificacao TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de recibos
CREATE TABLE IF NOT EXISTS recibos (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
  conta_receber_id INTEGER REFERENCES contas_receber(id) ON DELETE SET NULL,
  numero TEXT NOT NULL,
  valor DECIMAL(10, 2) NOT NULL,
  data_emissao DATE NOT NULL,
  descricao TEXT NOT NULL,
  url_pdf TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_contas_receber_clinica_id ON contas_receber(clinica_id);
CREATE INDEX IF NOT EXISTS idx_contas_receber_paciente_id ON contas_receber(paciente_id);
CREATE INDEX IF NOT EXISTS idx_contas_receber_status ON contas_receber(status);
CREATE INDEX IF NOT EXISTS idx_contas_receber_data_vencimento ON contas_receber(data_vencimento);

CREATE INDEX IF NOT EXISTS idx_contas_pagar_clinica_id ON contas_pagar(clinica_id);
CREATE INDEX IF NOT EXISTS idx_contas_pagar_fornecedor_id ON contas_pagar(fornecedor_id);
CREATE INDEX IF NOT EXISTS idx_contas_pagar_status ON contas_pagar(status);
CREATE INDEX IF NOT EXISTS idx_contas_pagar_data_vencimento ON contas_pagar(data_vencimento);

CREATE INDEX IF NOT EXISTS idx_fornecedores_clinica_id ON fornecedores(clinica_id);
CREATE INDEX IF NOT EXISTS idx_notas_fiscais_clinica_id ON notas_fiscais(clinica_id);
CREATE INDEX IF NOT EXISTS idx_notas_fiscais_paciente_id ON notas_fiscais(paciente_id);
CREATE INDEX IF NOT EXISTS idx_recibos_clinica_id ON recibos(clinica_id);
CREATE INDEX IF NOT EXISTS idx_recibos_paciente_id ON recibos(paciente_id);

-- Habilitar RLS
ALTER TABLE contas_receber ENABLE ROW LEVEL SECURITY;
ALTER TABLE contas_pagar ENABLE ROW LEVEL SECURITY;
ALTER TABLE fornecedores ENABLE ROW LEVEL SECURITY;
ALTER TABLE notas_fiscais ENABLE ROW LEVEL SECURITY;
ALTER TABLE recibos ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Usuários só podem ver contas a receber da sua clínica" ON contas_receber
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = contas_receber.clinica_id));

CREATE POLICY "Usuários só podem modificar contas a receber da sua clínica" ON contas_receber
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = contas_receber.clinica_id));

CREATE POLICY "Usuários só podem ver contas a pagar da sua clínica" ON contas_pagar
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = contas_pagar.clinica_id));

CREATE POLICY "Usuários só podem modificar contas a pagar da sua clínica" ON contas_pagar
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = contas_pagar.clinica_id));

CREATE POLICY "Usuários só podem ver fornecedores da sua clínica" ON fornecedores
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = fornecedores.clinica_id));

CREATE POLICY "Usuários só podem modificar fornecedores da sua clínica" ON fornecedores
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = fornecedores.clinica_id));

CREATE POLICY "Usuários só podem ver notas fiscais da sua clínica" ON notas_fiscais
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = notas_fiscais.clinica_id));

CREATE POLICY "Usuários só podem modificar notas fiscais da sua clínica" ON notas_fiscais
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = notas_fiscais.clinica_id));

CREATE POLICY "Usuários só podem ver recibos da sua clínica" ON recibos
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = recibos.clinica_id));

CREATE POLICY "Usuários só podem modificar recibos da sua clínica" ON recibos
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = recibos.clinica_id));

