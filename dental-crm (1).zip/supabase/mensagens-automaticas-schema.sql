-- Tabela de modelos de mensagens
CREATE TABLE IF NOT EXISTS modelos_mensagens (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('aniversario', 'retorno', 'data_comemorativa', 'promocao', 'outro')),
  canal TEXT NOT NULL CHECK (canal IN ('email', 'sms', 'whatsapp')),
  assunto TEXT,
  conteudo TEXT NOT NULL,
  ativo BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de datas comemorativas
CREATE TABLE IF NOT EXISTS datas_comemorativas (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  data DATE NOT NULL,
  modelo_mensagem_id INTEGER REFERENCES modelos_mensagens(id) ON DELETE SET NULL,
  dias_antecedencia INTEGER DEFAULT 0,
  ativo BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de configurações de mensagens automáticas
CREATE TABLE IF NOT EXISTS config_mensagens_automaticas (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  aniversario_ativo BOOLEAN DEFAULT TRUE,
  aniversario_modelo_id INTEGER REFERENCES modelos_mensagens(id) ON DELETE SET NULL,
  retorno_ativo BOOLEAN DEFAULT TRUE,
  retorno_modelo_id INTEGER REFERENCES modelos_mensagens(id) ON DELETE SET NULL,
  retorno_dias_apos INTEGER DEFAULT 180,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_modelos_mensagens_clinica_id ON modelos_mensagens(clinica_id);
CREATE INDEX IF NOT EXISTS idx_datas_comemorativas_clinica_id ON datas_comemorativas(clinica_id);
CREATE INDEX IF NOT EXISTS idx_datas_comemorativas_data ON datas_comemorativas(data);
CREATE INDEX IF NOT EXISTS idx_config_mensagens_automaticas_clinica_id ON config_mensagens_automaticas(clinica_id);

-- Habilitar RLS
ALTER TABLE modelos_mensagens ENABLE ROW LEVEL SECURITY;
ALTER TABLE datas_comemorativas ENABLE ROW LEVEL SECURITY;
ALTER TABLE config_mensagens_automaticas ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Usuários só podem ver modelos de mensagens da sua clínica" ON modelos_mensagens
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = modelos_mensagens.clinica_id));

CREATE POLICY "Usuários só podem modificar modelos de mensagens da sua clínica" ON modelos_mensagens
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = modelos_mensagens.clinica_id));

CREATE POLICY "Usuários só podem ver datas comemorativas da sua clínica" ON datas_comemorativas
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = datas_comemorativas.clinica_id));

CREATE POLICY "Usuários só podem modificar datas comemorativas da sua clínica" ON datas_comemorativas
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = datas_comemorativas.clinica_id));

CREATE POLICY "Usuários só podem ver configurações de mensagens automáticas da sua clínica" ON config_mensagens_automaticas
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = config_mensagens_automaticas.clinica_id));

CREATE POLICY "Usuários só podem modificar configurações de mensagens automáticas da sua clínica" ON config_mensagens_automaticas
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = config_mensagens_automaticas.clinica_id));

