-- Adicionar colunas para gerenciamento de assinaturas na tabela clinicas
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS ciclo_cobranca VARCHAR(20) DEFAULT 'mensal';
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS data_proximo_ciclo TIMESTAMP WITH TIME ZONE;
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS periodo_carencia BOOLEAN DEFAULT FALSE;
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS data_fim_carencia TIMESTAMP WITH TIME ZONE;
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS plano_anterior VARCHAR(50);
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS upgrade_agendado BOOLEAN DEFAULT FALSE;
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS plano_agendado VARCHAR(50);
ALTER TABLE clinicas ADD COLUMN IF NOT EXISTS data_mudanca_plano TIMESTAMP WITH TIME ZONE;

-- Tabela para histórico de assinaturas
CREATE TABLE IF NOT EXISTS historico_assinaturas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    clinica_id UUID NOT NULL REFERENCES clinicas(id) ON DELETE CASCADE,
    plano VARCHAR(50) NOT NULL,
    ciclo_cobranca VARCHAR(20) NOT NULL,
    valor_pago DECIMAL(10, 2) NOT NULL,
    data_inicio TIMESTAMP WITH TIME ZONE NOT NULL,
    data_fim TIMESTAMP WITH TIME ZONE,
    status VARCHAR(20) NOT NULL,
    metodo_pagamento VARCHAR(50),
    stripe_invoice_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_clinica FOREIGN KEY (clinica_id) REFERENCES clinicas(id) ON DELETE CASCADE
);

-- Tabela para descontos por ciclo de cobrança
CREATE TABLE IF NOT EXISTS descontos_ciclos (
    id SERIAL PRIMARY KEY,
    ciclo VARCHAR(20) NOT NULL UNIQUE,
    percentual_desconto DECIMAL(5, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir valores padrão para descontos
INSERT INTO descontos_ciclos (ciclo, percentual_desconto)
VALUES 
    ('mensal', 0),
    ('trimestral', 10),
    ('anual', 20)
ON CONFLICT (ciclo) DO NOTHING;

-- Função para atualizar o timestamp de updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar o timestamp
CREATE TRIGGER update_descontos_ciclos_updated_at
BEFORE UPDATE ON descontos_ciclos
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

