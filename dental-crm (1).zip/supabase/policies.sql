-- Exemplo de política RLS para tabela de pacientes
CREATE POLICY "Usuários só podem ver pacientes da sua clínica"
ON "public"."pacientes"
FOR SELECT
USING (auth.uid() IN (
  SELECT user_id FROM membros_clinica WHERE clinica_id = pacientes.clinica_id
));

CREATE POLICY "Apenas administradores podem editar pacientes"
ON "public"."pacientes"
FOR UPDATE
USING (
  auth.uid() IN (
    SELECT user_id FROM membros_clinica 
    WHERE clinica_id = pacientes.clinica_id AND role = 'admin'
  )
);

-- Políticas para consultas
CREATE POLICY "Usuários só podem ver consultas da sua clínica"
ON "public"."consultas"
FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM membros_clinica 
    WHERE clinica_id = (
      SELECT clinica_id FROM pacientes WHERE id = consultas.paciente_id
    )
  )
);

-- Políticas para tratamentos
CREATE POLICY "Usuários só podem ver tratamentos da sua clínica"
ON "public"."tratamentos"
FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM membros_clinica 
    WHERE clinica_id = (
      SELECT clinica_id FROM pacientes WHERE id = tratamentos.paciente_id
    )
  )
);

-- Políticas para financeiro
CREATE POLICY "Usuários só podem ver financeiro da sua clínica"
ON "public"."financeiro"
FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM membros_clinica 
    WHERE clinica_id = (
      SELECT clinica_id FROM pacientes WHERE id = financeiro.paciente_id
    )
  )
);

-- Políticas para prontuários
CREATE POLICY "Usuários só podem ver prontuários da sua clínica"
ON "public"."prontuarios"
FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM membros_clinica 
    WHERE clinica_id = (
      SELECT clinica_id FROM pacientes WHERE id = prontuarios.paciente_id
    )
  )
);

