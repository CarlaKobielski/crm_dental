-- Tabela de medicamentos
CREATE TABLE IF NOT EXISTS medicamentos (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  principio_ativo TEXT,
  laboratorio TEXT,
  forma TEXT,
  concentracao TEXT,
  classe TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de prescrições
CREATE TABLE IF NOT EXISTS prescricoes (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
  dentista_id INTEGER REFERENCES dentistas(id) ON DELETE SET NULL,
  consulta_id INTEGER REFERENCES consultas(id) ON DELETE SET NULL,
  data_prescricao DATE NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('medicamento', 'exame', 'atestado', 'encaminhamento', 'outro')),
  status TEXT NOT NULL CHECK (status IN ('rascunho', 'emitida', 'enviada', 'cancelada')),
  observacoes TEXT,
  url_pdf TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de itens de prescrição (medicamentos)
CREATE TABLE IF NOT EXISTS itens_prescricao (
  id SERIAL PRIMARY KEY,
  prescricao_id INTEGER REFERENCES prescricoes(id) ON DELETE CASCADE,
  medicamento_id INTEGER REFERENCES medicamentos(id) ON DELETE SET NULL,
  medicamento_nome TEXT NOT NULL,
  posologia TEXT NOT NULL,
  duracao TEXT,
  quantidade TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de modelos de prescrição
CREATE TABLE IF NOT EXISTS modelos_prescricao (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  dentista_id INTEGER REFERENCES dentistas(id) ON DELETE SET NULL,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('medicamento', 'exame', 'atestado', 'encaminhamento', 'outro')),
  conteudo TEXT NOT NULL,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_medicamentos_clinica_id ON medicamentos(clinica_id);
CREATE INDEX IF NOT EXISTS idx_prescricoes_clinica_id ON prescricoes(clinica_id);
CREATE INDEX IF NOT EXISTS idx_prescricoes_paciente_id ON prescricoes(paciente_id);
CREATE INDEX IF NOT EXISTS idx_prescricoes_dentista_id ON prescricoes(dentista_id);
CREATE INDEX IF NOT EXISTS idx_itens_prescricao_prescricao_id ON itens_prescricao(prescricao_id);
CREATE INDEX IF NOT EXISTS idx_modelos_prescricao_clinica_id ON modelos_prescricao(clinica_id);
CREATE INDEX IF NOT EXISTS idx_modelos_prescricao_dentista_id ON modelos_prescricao(dentista_id);

-- Habilitar RLS
ALTER TABLE medicamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescricoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_prescricao ENABLE ROW LEVEL SECURITY;
ALTER TABLE modelos_prescricao ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Usuários só podem ver medicamentos da sua clínica" ON medicamentos
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = medicamentos.clinica_id));

CREATE POLICY "Usuários só podem modificar medicamentos da sua clínica" ON medicamentos
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = medicamentos.clinica_id));

CREATE POLICY "Usuários só podem ver prescrições da sua clínica" ON prescricoes
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = prescricoes.clinica_id));

CREATE POLICY "Usuários só podem modificar prescrições da sua clínica" ON prescricoes
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = prescricoes.clinica_id));

CREATE POLICY "Usuários só podem ver itens de prescrição da sua clínica" ON itens_prescricao
FOR SELECT USING (
  auth.uid() IN (
    SELECT pu.id FROM perfis_usuario pu
    JOIN prescricoes p ON pu.clinica_id = p.clinica_id
    WHERE p.id = itens_prescricao.prescricao_id
  )
);

CREATE POLICY "Usuários só podem modificar itens de prescrição da sua clínica" ON itens_prescricao
FOR ALL USING (
  auth.uid() IN (
    SELECT pu.id FROM perfis_usuario pu
    JOIN prescricoes p ON pu.clinica_id = p.clinica_id
    WHERE p.id = itens_prescricao.prescricao_id
  )
);

CREATE POLICY "Usuários só podem ver modelos de prescrição da sua clínica" ON modelos_prescricao
FOR SELECT USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = modelos_prescricao.clinica_id));

CREATE POLICY "Usuários só podem modificar modelos de prescrição da sua clínica" ON modelos_prescricao
FOR ALL USING (auth.uid() IN (SELECT id FROM perfis_usuario WHERE clinica_id = modelos_prescricao.clinica_id));

