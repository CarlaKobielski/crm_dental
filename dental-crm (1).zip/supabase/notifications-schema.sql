-- Tabela de notificações
CREATE TABLE IF NOT EXISTS notificacoes (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
  consulta_id INTEGER REFERENCES consultas(id) ON DELETE SET NULL,
  destinatario TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('email', 'sms')),
  assunto TEXT,
  mensagem TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('agendado', 'enviado', 'falha', 'cancelado')),
  data_envio TIMESTAMP WITH TIME ZONE NOT NULL,
  data_processamento TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_notificacoes_status ON notificacoes(status);
CREATE INDEX IF NOT EXISTS idx_notificacoes_data_envio ON notificacoes(data_envio);
CREATE INDEX IF NOT EXISTS idx_notificacoes_clinica_id ON notificacoes(clinica_id);

-- Habilitar RLS
ALTER TABLE notificacoes ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Usuários só podem ver notificações da sua clínica" ON notificacoes
FOR SELECT
USING (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = notificacoes.clinica_id
  )
);

CREATE POLICY "Usuários só podem inserir notificações da sua clínica" ON notificacoes
FOR INSERT
WITH CHECK (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = notificacoes.clinica_id
  )
);

CREATE POLICY "Usuários só podem atualizar notificações da sua clínica" ON notificacoes
FOR UPDATE
USING (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = notificacoes.clinica_id
  )
);

