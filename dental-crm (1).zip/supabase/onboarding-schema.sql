-- Adicionar campo para controlar o status do onboarding
ALTER TABLE perfis_usuario ADD COLUMN IF NOT EXISTS onboarding_completo BOOLEAN DEFAULT FALSE;

-- Criar tabela de dentistas
CREATE TABLE IF NOT EXISTS dentistas (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  especialidade TEXT,
  registro TEXT,
  email TEXT,
  telefone TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Habilitar RLS para a tabela de dentistas
ALTER TABLE dentistas ENABLE ROW LEVEL SECURITY;

-- Criar política RLS para dentistas
CREATE POLICY "Usuários só podem ver dentistas da sua clínica" ON dentistas
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = dentistas.clinica_id
    )
  );

CREATE POLICY "Usuários só podem modificar dentistas da sua clínica" ON dentistas
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM perfis_usuario WHERE clinica_id = dentistas.clinica_id
    )
  );

