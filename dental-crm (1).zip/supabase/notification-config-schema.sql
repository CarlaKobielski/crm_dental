-- Tabela de configurações de notificações
CREATE TABLE IF NOT EXISTS configuracoes_notificacoes (
  id SERIAL PRIMARY KEY,
  clinica_id UUID REFERENCES clinicas(id) ON DELETE CASCADE,
  notificacoes_email_ativo BOOLEAN DEFAULT TRUE,
  notificacoes_sms_ativo BOOLEAN DEFAULT FALSE,
  template_email_consulta TEXT,
  template_sms_consulta TEXT,
  antecedencia_lembrete_horas INTEGER DEFAULT 24,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índice para melhorar performance
CREATE INDEX IF NOT EXISTS idx_configuracoes_notificacoes_clinica_id ON configuracoes_notificacoes(clinica_id);

-- Habilitar RLS
ALTER TABLE configuracoes_notificacoes ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Usuários só podem ver configurações da sua clínica" ON configuracoes_notificacoes
FOR SELECT
USING (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = configuracoes_notificacoes.clinica_id
  )
);

CREATE POLICY "Apenas administradores podem modificar configurações" ON configuracoes_notificacoes
FOR ALL
USING (
  auth.uid() IN (
    SELECT id FROM perfis_usuario WHERE clinica_id = configuracoes_notificacoes.clinica_id AND funcao = 'admin'
  )
);

-- Inserir configurações padrão para clínicas existentes
INSERT INTO configuracoes_notificacoes (
  clinica_id,
  notificacoes_email_ativo,
  notificacoes_sms_ativo,
  template_email_consulta,
  template_sms_consulta,
  antecedencia_lembrete_horas
)
SELECT 
  id,
  TRUE,
  FALSE,
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
    <h2 style="color: #4f46e5;">Lembrete de Consulta</h2>
    <p>Olá, {paciente}!</p>
    <p>Este é um lembrete para sua consulta agendada:</p>
    <div style="background-color: #f9fafb; padding: 15px; border-radius: 5px; margin: 15px 0;">
      <p><strong>Data:</strong> {data}</p>
      <p><strong>Horário:</strong> {hora}</p>
      <p><strong>Clínica:</strong> {clinica}</p>
    </div>
    <p>Caso precise remarcar, entre em contato conosco.</p>
    <p>Atenciosamente,<br>Equipe {clinica}</p>
  </div>',
  'Lembrete: Você tem uma consulta agendada para {data} às {hora} na {clinica}. Caso precise remarcar, entre em contato.',
  24
FROM clinicas
WHERE NOT EXISTS (
  SELECT 1 FROM configuracoes_notificacoes WHERE configuracoes_notificacoes.clinica_id = clinicas.id
);

-- Atualizar a tabela de configurações de notificações para incluir WhatsApp
ALTER TABLE configuracoes_notificacoes 
ADD COLUMN IF NOT EXISTS notificacoes_whatsapp_ativo BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS template_whatsapp_consulta TEXT DEFAULT 'Olá {paciente}, este é um lembrete para sua consulta agendada para {data} às {hora} na {clinica}. Caso precise remarcar, entre em contato conosco.';

-- Adicionar campos para armazenar credenciais do WhatsApp por clínica
ALTER TABLE configuracoes_notificacoes 
ADD COLUMN IF NOT EXISTS whatsapp_api_key TEXT,
ADD COLUMN IF NOT EXISTS whatsapp_phone_number_id TEXT,
ADD COLUMN IF NOT EXISTS whatsapp_provider TEXT DEFAULT 'meta';

-- Atualizar a tabela de notificações para aceitar o tipo WhatsApp
ALTER TABLE notificacoes 
DROP CONSTRAINT IF EXISTS notificacoes_tipo_check;

ALTER TABLE notificacoes 
ADD CONSTRAINT notificacoes_tipo_check 
CHECK (tipo IN ('email', 'sms', 'whatsapp'));

-- Atualizar configurações existentes para habilitar WhatsApp
UPDATE configuracoes_notificacoes
SET 
  notificacoes_whatsapp_ativo = TRUE,
  template_whatsapp_consulta = 'Olá {paciente}, este é um lembrete para sua consulta agendada para {data} às {hora} na {clinica}. Caso precise remarcar, entre em contato conosco.'
WHERE notificacoes_whatsapp_ativo IS NULL;

