-- Habilitar o armazenamento RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Política para permitir leitura de arquivos
CREATE POLICY "Permitir leitura pública de arquivos" ON storage.objects
FOR SELECT
USING (bucket_id IN ('documentos', 'imagens', 'prontuarios', 'radiografias'));

-- Política para permitir upload de arquivos para usuários autenticados
CREATE POLICY "Permitir upload para usuários autenticados" ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id IN ('documentos', 'imagens', 'prontuarios', 'radiografias'));

-- Política para permitir atualização de arquivos para usuários autenticados
CREATE POLICY "Permitir atualização para usuários autenticados" ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id IN ('documentos', 'imagens', 'prontuarios', 'radiografias'));

-- Política para permitir exclusão de arquivos para usuários autenticados
CREATE POLICY "Permitir exclusão para usuários autenticados" ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id IN ('documentos', 'imagens', 'prontuarios', 'radiografias'));

