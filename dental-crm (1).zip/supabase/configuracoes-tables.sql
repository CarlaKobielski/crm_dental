-- Tabela de configurações do sistema
CREATE TABLE IF NOT EXISTS configuracoes_sistema (
  id SERIAL PRIMARY KEY,
  nome_clinica TEXT NOT NULL,
  endereco TEXT,
  telefone TEXT,
  email TEXT,
  site TEXT,
  logo_url TEXT,
  tema TEXT DEFAULT 'claro',
  cor_primaria TEXT DEFAULT '#4f46e5',
  notificacoes_email BOOLEAN DEFAULT TRUE,
  notificacoes_sms BOOLEAN DEFAULT FALSE,
  mensagem_agendamento TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
  id UUID PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  funcao TEXT NOT NULL,
  ultimo_acesso TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Inserir configurações padrão se não existirem
INSERT INTO configuracoes_sistema (
  nome_clinica, 
  endereco, 
  telefone, 
  email, 
  site, 
  tema, 
  cor_primaria, 
  notificacoes_email, 
  notificacoes_sms, 
  mensagem_agendamento
)
SELECT 
  'Minha Clínica Odontológica',
  'Rua Exemplo, 123 - Centro',
  '(11) 99999-9999',
  'contato@minhaclínica.com',
  'www.minhaclínica.com',
  'claro',
  '#4f46e5',
  TRUE,
  FALSE,
  'Olá {paciente}, confirmamos seu agendamento para {data} às {hora}. Caso precise remarcar, entre em contato conosco.'
WHERE NOT EXISTS (SELECT 1 FROM configuracoes_sistema);

-- Inserir usuário administrador padrão se não existir
INSERT INTO usuarios (id, email, nome, funcao, created_at)
SELECT 
  '00000000-0000-0000-0000-000000000000',
  'admin@dentalcrm.com',
  'Administrador',
  'admin',
  CURRENT_TIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE email = 'admin@dentalcrm.com');

