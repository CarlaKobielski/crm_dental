"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { useEffect } from "react"

interface ConfiguracoesSistema {
  id?: number
  nome_clinica: string
  endereco: string
  telefone: string
  email: string
  site: string
  logo_url: string
  tema: string
  cor_primaria: string
  notificacoes_email: boolean
  notificacoes_sms: boolean
  mensagem_agendamento: string
}

const configuracoesDefault: ConfiguracoesSistema = {
  nome_clinica: "Minha Clínica Odontológica",
  endereco: "Rua Exemplo, 123 - Centro",
  telefone: "(11) 99999-9999",
  email: "contato@minhaclínica.com",
  site: "www.minhaclínica.com",
  logo_url: "",
  tema: "claro",
  cor_primaria: "#4f46e5",
  notificacoes_email: true,
  notificacoes_sms: false,
  mensagem_agendamento:
    "Olá {paciente}, confirmamos seu agendamento para {data} às {hora}. Caso precise remarcar, entre em contato conosco.",
}

export function ConfiguracoesSistema() {
  const [configuracoes, setConfiguracoes] = useState<ConfiguracoesSistema>(configuracoesDefault)
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    const fetchConfiguracoes = async () => {
      setIsLoading(true)
      try {
        const { data, error } = await supabase.from("configuracoes_sistema").select("*").single()

        if (error && error.code !== "PGRST116") {
          throw error
        }

        if (data) {
          setConfiguracoes(data)
        }
      } catch (error) {
        console.error("Erro ao carregar configurações:", error)
        toast({
          title: "Erro ao carregar configurações",
          description: "Não foi possível carregar as configurações do sistema.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchConfiguracoes()
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    try {
      const { data, error } = await supabase
        .from("configuracoes_sistema")
        .upsert({
          id: configuracoes.id || 1,
          ...configuracoes,
        })
        .select()

      if (error) throw error

      setConfiguracoes((prev) => ({ ...prev, id: data?.[0]?.id || prev.id }))

      toast({
        title: "Configurações salvas",
        description: "As configurações do sistema foram salvas com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      toast({
        title: "Erro ao salvar configurações",
        description: "Não foi possível salvar as configurações do sistema.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Informações da Clínica</CardTitle>
          <CardDescription>Configure as informações básicas da sua clínica odontológica.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome_clinica">Nome da Clínica</Label>
              <Input
                id="nome_clinica"
                value={configuracoes.nome_clinica}
                onChange={(e) => setConfiguracoes({ ...configuracoes, nome_clinica: e.target.value })}
                placeholder="Nome da sua clínica"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="telefone">Telefone</Label>
              <Input
                id="telefone"
                value={configuracoes.telefone}
                onChange={(e) => setConfiguracoes({ ...configuracoes, telefone: e.target.value })}
                placeholder="(00) 00000-0000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={configuracoes.email}
                onChange={(e) => setConfiguracoes({ ...configuracoes, email: e.target.value })}
                placeholder="contato@suaclinica.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="site">Site</Label>
              <Input
                id="site"
                value={configuracoes.site}
                onChange={(e) => setConfiguracoes({ ...configuracoes, site: e.target.value })}
                placeholder="www.suaclinica.com"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="endereco">Endereço</Label>
            <Textarea
              id="endereco"
              value={configuracoes.endereco}
              onChange={(e) => setConfiguracoes({ ...configuracoes, endereco: e.target.value })}
              placeholder="Endereço completo da clínica"
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="logo_url">URL do Logo</Label>
            <Input
              id="logo_url"
              value={configuracoes.logo_url}
              onChange={(e) => setConfiguracoes({ ...configuracoes, logo_url: e.target.value })}
              placeholder="https://exemplo.com/logo.png"
            />
            <p className="text-xs text-gray-500">
              Insira a URL da imagem do logo da sua clínica. Recomendamos usar uma imagem de 200x200 pixels.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Aparência</CardTitle>
          <CardDescription>Personalize a aparência do sistema.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tema">Tema</Label>
              <Select
                value={configuracoes.tema}
                onValueChange={(value) => setConfiguracoes({ ...configuracoes, tema: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um tema" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="claro">Claro</SelectItem>
                  <SelectItem value="escuro">Escuro</SelectItem>
                  <SelectItem value="sistema">Seguir sistema</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cor_primaria">Cor Primária</Label>
              <div className="flex gap-2">
                <Input
                  id="cor_primaria"
                  type="color"
                  value={configuracoes.cor_primaria}
                  onChange={(e) => setConfiguracoes({ ...configuracoes, cor_primaria: e.target.value })}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={configuracoes.cor_primaria}
                  onChange={(e) => setConfiguracoes({ ...configuracoes, cor_primaria: e.target.value })}
                  placeholder="#000000"
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notificações</CardTitle>
          <CardDescription>Configure como o sistema enviará notificações aos pacientes.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="notificacoes_email">Notificações por E-mail</Label>
              <p className="text-sm text-gray-500">Enviar lembretes de consulta por e-mail</p>
            </div>
            <Switch
              id="notificacoes_email"
              checked={configuracoes.notificacoes_email}
              onCheckedChange={(checked) => setConfiguracoes({ ...configuracoes, notificacoes_email: checked })}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="notificacoes_sms">Notificações por SMS</Label>
              <p className="text-sm text-gray-500">Enviar lembretes de consulta por SMS</p>
            </div>
            <Switch
              id="notificacoes_sms"
              checked={configuracoes.notificacoes_sms}
              onCheckedChange={(checked) => setConfiguracoes({ ...configuracoes, notificacoes_sms: checked })}
            />
          </div>
          <div className="space-y-2 pt-2">
            <Label htmlFor="mensagem_agendamento">Mensagem de Agendamento</Label>
            <Textarea
              id="mensagem_agendamento"
              value={configuracoes.mensagem_agendamento}
              onChange={(e) => setConfiguracoes({ ...configuracoes, mensagem_agendamento: e.target.value })}
              placeholder="Mensagem para confirmação de agendamento"
              rows={3}
            />
            <p className="text-xs text-gray-500">
              Use {"{paciente}"} para o nome do paciente, {"{data}"} para a data e {"{hora}"} para o horário da
              consulta.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSave} disabled={isLoading || isSaving}>
            {isSaving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

