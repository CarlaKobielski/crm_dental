"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { createAppointmentReminders } from "@/lib/notifications"

interface Paciente {
  id: number
  nome: string
  email: string
  telefone: string
}

interface CriarConsultaFormProps {
  onSuccess?: () => void
  clinicaId: string
  clinicaNome: string
}

export function CriarConsultaForm({ onSuccess, clinicaId, clinicaNome }: CriarConsultaFormProps) {
  const [pacientes, setPacientes] = useState<Paciente[]>([])
  const [pacienteId, setPacienteId] = useState<string>("")
  const [data, setData] = useState("")
  const [hora, setHora] = useState("")
  const [tipo, setTipo] = useState("")
  const [descricao, setDescricao] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingPacientes, setIsLoadingPacientes] = useState(true)
  const [criarLembretes, setCriarLembretes] = useState(true)

  useEffect(() => {
    const fetchPacientes = async () => {
      setIsLoadingPacientes(true)
      try {
        const { data, error } = await supabase
          .from("pacientes")
          .select("id, nome, email, telefone")
          .eq("clinica_id", clinicaId)
          .order("nome")

        if (error) throw error

        setPacientes(data || [])
      } catch (error) {
        console.error("Erro ao carregar pacientes:", error)
        toast({
          title: "Erro ao carregar pacientes",
          description: "Não foi possível carregar a lista de pacientes.",
          variant: "destructive",
        })
      } finally {
        setIsLoadingPacientes(false)
      }
    }

    if (clinicaId) {
      fetchPacientes()
    }
  }, [clinicaId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (!pacienteId || !data || !hora || !tipo) {
        toast({
          title: "Campos obrigatórios",
          description: "Por favor, preencha todos os campos obrigatórios.",
          variant: "destructive",
        })
        return
      }

      // Criar consulta
      const { data: consultaData, error } = await supabase
        .from("consultas")
        .insert({
          paciente_id: Number.parseInt(pacienteId),
          data,
          hora,
          tipo,
          descricao,
          status: "agendado",
          clinica_id: clinicaId,
        })
        .select()

      if (error) throw error

      // Criar lembretes automáticos se a opção estiver marcada
      if (criarLembretes) {
        const paciente = pacientes.find((p) => p.id === Number.parseInt(pacienteId))

        if (paciente && consultaData && consultaData.length > 0) {
          await createAppointmentReminders(
            consultaData[0].id,
            paciente.id,
            paciente.nome,
            paciente.email,
            paciente.telefone,
            data,
            hora,
            clinicaId,
            clinicaNome,
          )
        }
      }

      toast({
        title: "Consulta agendada",
        description: "A consulta foi agendada com sucesso.",
      })

      // Limpar formulário
      setPacienteId("")
      setData("")
      setHora("")
      setTipo("")
      setDescricao("")

      // Callback de sucesso
      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      console.error("Erro ao agendar consulta:", error)
      toast({
        title: "Erro ao agendar consulta",
        description: "Não foi possível agendar a consulta.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="paciente">Paciente *</Label>
        <Select value={pacienteId} onValueChange={setPacienteId}>
          <SelectTrigger id="paciente">
            <SelectValue placeholder="Selecione um paciente" />
          </SelectTrigger>
          <SelectContent>
            {isLoadingPacientes ? (
              <SelectItem value="loading" disabled>
                Carregando pacientes...
              </SelectItem>
            ) : pacientes.length === 0 ? (
              <SelectItem value="empty" disabled>
                Nenhum paciente cadastrado
              </SelectItem>
            ) : (
              pacientes.map((paciente) => (
                <SelectItem key={paciente.id} value={paciente.id.toString()}>
                  {paciente.nome}
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="data">Data *</Label>
          <Input
            id="data"
            type="date"
            value={data}
            onChange={(e) => setData(e.target.value)}
            min={new Date().toISOString().split("T")[0]}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="hora">Hora *</Label>
          <Input id="hora" type="time" value={hora} onChange={(e) => setHora(e.target.value)} />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="tipo">Tipo de Consulta *</Label>
        <Select value={tipo} onValueChange={setTipo}>
          <SelectTrigger id="tipo">
            <SelectValue placeholder="Selecione o tipo de consulta" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="avaliacao">Avaliação</SelectItem>
            <SelectItem value="limpeza">Limpeza</SelectItem>
            <SelectItem value="tratamento">Tratamento</SelectItem>
            <SelectItem value="emergencia">Emergência</SelectItem>
            <SelectItem value="retorno">Retorno</SelectItem>
            <SelectItem value="outro">Outro</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="descricao">Descrição</Label>
        <Textarea
          id="descricao"
          placeholder="Detalhes adicionais sobre a consulta"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
          rows={3}
        />
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="criarLembretes"
          checked={criarLembretes}
          onChange={(e) => setCriarLembretes(e.target.checked)}
          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
        />
        <Label htmlFor="criarLembretes" className="text-sm font-normal">
          Criar lembretes automáticos para o paciente
        </Label>
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? "Agendando..." : "Agendar Consulta"}
      </Button>
    </form>
  )
}

