"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { listFiles, deleteFile, getPublicUrl } from "@/lib/storage"
import { FileText, Image, File, Download, Trash2, RefreshCw, AlertCircle } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface FileListProps {
  bucket: string
  path?: string
  onDelete?: (filePath: string) => void
  onRefresh?: () => void
}

export function FileList({ bucket, path = "", onDelete, onRefresh }: FileListProps) {
  const [files, setFiles] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadFiles()
  }, [bucket, path])

  async function loadFiles() {
    setIsLoading(true)
    setError(null)
    try {
      console.log(`Listando arquivos do bucket ${bucket}, path: ${path}`)
      const fileList = await listFiles(bucket, path)
      console.log(`Arquivos encontrados:`, fileList)
      setFiles(fileList)
    } catch (error) {
      console.error("Erro ao listar arquivos:", error)
      setError(
        "Não foi possível carregar a lista de arquivos. Verifique se o bucket existe e se você tem permissão para acessá-lo.",
      )
      toast({
        title: "Erro ao carregar arquivos",
        description:
          "Não foi possível carregar a lista de arquivos. Verifique se o bucket existe e se você tem permissão para acessá-lo.",
        variant: "destructive",
      })
      setFiles([])
    } finally {
      setIsLoading(false)
    }
  }

  async function handleDelete(filePath: string) {
    if (!confirm("Tem certeza que deseja excluir este arquivo?")) {
      return
    }

    try {
      const success = await deleteFile(bucket, filePath)

      if (success) {
        toast({
          title: "Arquivo excluído",
          description: "O arquivo foi excluído com sucesso",
        })

        // Atualizar a lista
        setFiles(files.filter((file) => file.name !== filePath))

        if (onDelete) {
          onDelete(filePath)
        }
      } else {
        throw new Error("Não foi possível excluir o arquivo")
      }
    } catch (error) {
      console.error("Erro ao excluir arquivo:", error)
      toast({
        title: "Erro ao excluir",
        description: "Ocorreu um erro ao excluir o arquivo",
        variant: "destructive",
      })
    }
  }

  function getFileIcon(fileName: string) {
    const ext = fileName.split(".").pop()?.toLowerCase()

    if (["jpg", "jpeg", "png", "gif", "webp"].includes(ext || "")) {
      return <Image className="h-8 w-8 text-blue-500" />
    } else if (ext === "pdf") {
      return <FileText className="h-8 w-8 text-red-500" />
    } else {
      return <File className="h-8 w-8 text-green-500" />
    }
  }

  function handleRefresh() {
    loadFiles()
    if (onRefresh) {
      onRefresh()
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <RefreshCw className="h-8 w-8 text-gray-400 animate-spin" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button variant="outline" className="w-full" onClick={handleRefresh}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Tentar Novamente
        </Button>
      </div>
    )
  }

  if (files.length === 0) {
    return (
      <div className="text-center p-8 border rounded-lg">
        <File className="h-12 w-12 text-gray-300 mx-auto mb-2" />
        <p className="text-gray-500">Nenhum arquivo encontrado</p>
        <Button variant="outline" className="mt-4" onClick={handleRefresh}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Arquivos ({files.length})</h3>
        <Button variant="outline" size="sm" onClick={handleRefresh}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {files.map((file) => (
          <Card key={file.name} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex items-center gap-3">
                  {getFileIcon(file.name)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" title={file.name}>
                      {file.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {file.created_at ? new Date(file.created_at).toLocaleDateString() : "Data desconhecida"} •{" "}
                      {file.metadata?.size ? (file.metadata.size / 1024 / 1024).toFixed(2) : "?"} MB
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex border-t">
                <a
                  href={getPublicUrl(bucket, file.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2 px-3 text-center text-sm text-blue-600 hover:bg-blue-50"
                >
                  <Download className="h-4 w-4 inline mr-1" />
                  Baixar
                </a>
                <button
                  onClick={() => handleDelete(file.name)}
                  className="flex-1 py-2 px-3 text-center text-sm text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4 inline mr-1" />
                  Excluir
                </button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

