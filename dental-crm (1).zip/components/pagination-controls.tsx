"use client"

import { Button } from "@/components/ui/button"

export function PaginationControls({
  currentPage,
  totalPages,
  onPageChange,
}: {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
}) {
  return (
    <div className="flex justify-center gap-2 mt-4">
      <Button variant="outline" onClick={() => onPageChange(currentPage - 1)} disabled={currentPage <= 1}>
        Anterior
      </Button>
      <span className="py-2 px-4">
        Página {currentPage} de {totalPages}
      </span>
      <Button variant="outline" onClick={() => onPageChange(currentPage + 1)} disabled={currentPage >= totalPages}>
        Próxima
      </Button>
    </div>
  )
}

