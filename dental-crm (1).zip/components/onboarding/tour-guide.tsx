"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { ChevronLeft, ChevronRight, Check } from "lucide-react"

const tourSteps = [
  {
    title: "Bem-vindo ao Dental CRM",
    description: "Vamos conhecer as principais funcionalidades do sistema.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Dashboard",
    description: "O dashboard mostra uma visão geral da sua clínica, com gráficos e indicadores importantes.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Pacientes",
    description: "Gerencie todos os seus pacientes, com histórico completo, prontuários e documentos.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Agenda",
    description: "Agende consultas e procedimentos, com visualização diária, semanal ou mensal.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Financeiro",
    description: "Controle financeiro completo, com faturamento, recebimentos e relatórios.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Pronto para começar!",
    description: "Agora você já conhece as principais funcionalidades do Dental CRM. Vamos começar a usar?",
    image: "/placeholder.svg?height=300&width=500",
  },
]

export function TourGuide() {
  const [currentStep, setCurrentStep] = useState(0)
  const router = useRouter()

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      // Último passo, redirecionar para o dashboard
      router.push("/dashboard")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSkip = () => {
    router.push("/dashboard")
  }

  const step = tourSteps[currentStep]
  const isLastStep = currentStep === tourSteps.length - 1

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <Card className="w-full max-w-3xl overflow-hidden">
        <div className="relative">
          <img src={step.image || "/placeholder.svg"} alt={step.title} className="w-full h-64 object-cover" />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
            <h2 className="text-2xl font-bold text-white">{step.title}</h2>
          </div>
        </div>

        <CardContent className="p-6">
          <p className="text-gray-600 mb-8">{step.description}</p>

          <div className="flex items-center justify-between">
            <div>
              {currentStep > 0 ? (
                <Button variant="outline" onClick={handlePrevious}>
                  <ChevronLeft className="mr-2 h-4 w-4" /> Anterior
                </Button>
              ) : (
                <Button variant="outline" onClick={handleSkip}>
                  Pular tour
                </Button>
              )}
            </div>

            <div className="flex items-center space-x-1">
              {tourSteps.map((_, index) => (
                <span
                  key={index}
                  className={`block h-2 w-2 rounded-full ${index === currentStep ? "bg-blue-600" : "bg-gray-300"}`}
                ></span>
              ))}
            </div>

            <Button onClick={handleNext}>
              {isLastStep ? (
                <>
                  Começar <Check className="ml-2 h-4 w-4" />
                </>
              ) : (
                <>
                  Próximo <ChevronRight className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

