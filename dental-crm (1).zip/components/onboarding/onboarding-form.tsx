"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, ArrowRight, Upload } from "lucide-react"

interface OnboardingFormProps {
  userId: string
}

export function OnboardingForm({ userId }: OnboardingFormProps) {
  const [activeStep, setActiveStep] = useState("clinica")
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const router = useRouter()

  // Dados da clínica
  const [nomeClinica, setNomeClinica] = useState("")
  const [endereco, setEndereco] = useState("")
  const [telefone, setTelefone] = useState("")
  const [email, setEmail] = useState("")
  const [site, setSite] = useState("")

  // Dados do profissional
  const [nomeProfissional, setNomeProfissional] = useState("")
  const [especialidade, setEspecialidade] = useState("")
  const [registroProfissional, setRegistroProfissional] = useState("")

  // Preferências
  const [corPrimaria, setCorPrimaria] = useState("#4f46e5")
  const [logoUrl, setLogoUrl] = useState("")

  async function handleNext() {
    if (activeStep === "clinica") {
      if (!nomeClinica || !telefone) {
        toast({
          title: "Campos obrigatórios",
          description: "Por favor, preencha o nome da clínica e telefone.",
          variant: "destructive",
        })
        return
      }
      setActiveStep("profissional")
      setProgress(33)
    } else if (activeStep === "profissional") {
      if (!nomeProfissional) {
        toast({
          title: "Campo obrigatório",
          description: "Por favor, preencha o nome do profissional.",
          variant: "destructive",
        })
        return
      }
      setActiveStep("preferencias")
      setProgress(66)
    } else if (activeStep === "preferencias") {
      await handleComplete()
    }
  }

  async function handleComplete() {
    setIsLoading(true)

    try {
      // Obter o ID da clínica do usuário
      const { data: userData, error: userError } = await supabase
        .from("perfis_usuario")
        .select("clinica_id")
        .eq("id", userId)
        .single()

      if (userError) throw userError

      const clinicaId = userData.clinica_id

      // Atualizar dados da clínica
      const { error: clinicaError } = await supabase
        .from("clinicas")
        .update({
          nome: nomeClinica,
          endereco,
          telefone,
          email,
          site,
          logo_url: logoUrl,
        })
        .eq("id", clinicaId)

      if (clinicaError) throw clinicaError

      // Atualizar configurações do sistema
      const { error: configError } = await supabase.from("configuracoes_sistema").upsert({
        clinica_id: clinicaId,
        nome_clinica: nomeClinica,
        endereco,
        telefone,
        email,
        site,
        logo_url: logoUrl,
        cor_primaria: corPrimaria,
      })

      if (configError) throw configError

      // Criar o primeiro dentista
      const { error: dentistaError } = await supabase.from("dentistas").insert({
        clinica_id: clinicaId,
        nome: nomeProfissional,
        especialidade,
        registro: registroProfissional,
      })

      if (dentistaError) throw dentistaError

      // Marcar onboarding como completo
      const { error: perfilError } = await supabase
        .from("perfis_usuario")
        .update({
          onboarding_completo: true,
          nome: nomeProfissional, // Atualizar nome do usuário com o nome do profissional
        })
        .eq("id", userId)

      if (perfilError) throw perfilError

      toast({
        title: "Configuração concluída",
        description: "Sua clínica foi configurada com sucesso!",
      })

      // Redirecionar para o tour guiado
      router.push("/tour")
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Erro ao salvar configurações",
        description: error.message || "Ocorreu um erro ao tentar salvar as configurações.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  function handlePrevious() {
    if (activeStep === "profissional") {
      setActiveStep("clinica")
      setProgress(0)
    } else if (activeStep === "preferencias") {
      setActiveStep("profissional")
      setProgress(33)
    }
  }

  return (
    <div>
      {/* Barra de progresso */}
      <div className="h-2 bg-gray-200">
        <div className="h-full bg-blue-600 transition-all duration-300" style={{ width: `${progress}%` }}></div>
      </div>

      <Tabs value={activeStep} onValueChange={setActiveStep} className="p-6">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="clinica" disabled={activeStep !== "clinica"}>
            1. Dados da Clínica
          </TabsTrigger>
          <TabsTrigger value="profissional" disabled={activeStep !== "profissional" && activeStep !== "clinica"}>
            2. Profissional
          </TabsTrigger>
          <TabsTrigger value="preferencias" disabled={activeStep === "clinica"}>
            3. Preferências
          </TabsTrigger>
        </TabsList>

        <TabsContent value="clinica">
          <Card>
            <CardHeader>
              <CardTitle>Dados da Clínica</CardTitle>
              <CardDescription>Informe os dados básicos da sua clínica odontológica</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nomeClinica">Nome da Clínica *</Label>
                <Input
                  id="nomeClinica"
                  value={nomeClinica}
                  onChange={(e) => setNomeClinica(e.target.value)}
                  placeholder="Ex: Clínica Odontológica Sorriso Perfeito"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endereco">Endereço</Label>
                <Textarea
                  id="endereco"
                  value={endereco}
                  onChange={(e) => setEndereco(e.target.value)}
                  placeholder="Ex: Rua das Flores, 123 - Centro"
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone *</Label>
                  <Input
                    id="telefone"
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="Ex: (11) 99999-9999"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Ex: contato@clinica.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="site">Site</Label>
                <Input
                  id="site"
                  value={site}
                  onChange={(e) => setSite(e.target.value)}
                  placeholder="Ex: www.clinica.com"
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end mt-6">
            <Button onClick={handleNext}>
              Próximo <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="profissional">
          <Card>
            <CardHeader>
              <CardTitle>Dados do Profissional</CardTitle>
              <CardDescription>Informe os dados do profissional responsável</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nomeProfissional">Nome do Profissional *</Label>
                <Input
                  id="nomeProfissional"
                  value={nomeProfissional}
                  onChange={(e) => setNomeProfissional(e.target.value)}
                  placeholder="Ex: Dr. João Silva"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="especialidade">Especialidade</Label>
                  <Input
                    id="especialidade"
                    value={especialidade}
                    onChange={(e) => setEspecialidade(e.target.value)}
                    placeholder="Ex: Ortodontia"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="registroProfissional">Registro Profissional (CRO)</Label>
                  <Input
                    id="registroProfissional"
                    value={registroProfissional}
                    onChange={(e) => setRegistroProfissional(e.target.value)}
                    placeholder="Ex: CRO-SP 12345"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between mt-6">
            <Button variant="outline" onClick={handlePrevious}>
              Voltar
            </Button>
            <Button onClick={handleNext}>
              Próximo <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="preferencias">
          <Card>
            <CardHeader>
              <CardTitle>Preferências</CardTitle>
              <CardDescription>Personalize a aparência do seu sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="corPrimaria">Cor Primária</Label>
                <div className="flex gap-2">
                  <Input
                    id="corPrimaria"
                    type="color"
                    value={corPrimaria}
                    onChange={(e) => setCorPrimaria(e.target.value)}
                    className="w-12 h-10 p-1"
                  />
                  <Input
                    value={corPrimaria}
                    onChange={(e) => setCorPrimaria(e.target.value)}
                    placeholder="#000000"
                    className="flex-1"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="logoUrl">URL do Logo</Label>
                <div className="flex gap-2">
                  <Input
                    id="logoUrl"
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    placeholder="https://exemplo.com/logo.png"
                    className="flex-1"
                  />
                  <Button variant="outline" type="button">
                    <Upload className="mr-2 h-4 w-4" /> Upload
                  </Button>
                </div>
                <p className="text-xs text-gray-500">Insira a URL da imagem do logo da sua clínica ou faça upload.</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between mt-6">
            <Button variant="outline" onClick={handlePrevious}>
              Voltar
            </Button>
            <Button onClick={handleComplete} disabled={isLoading}>
              {isLoading ? "Salvando..." : "Concluir"} <CheckCircle className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

