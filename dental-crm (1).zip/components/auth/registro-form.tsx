"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"

export function RegistroForm() {
  const [nome, setNome] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [nomeClinica, setNomeClinica] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (password !== confirmPassword) {
      toast({
        title: "Senhas não conferem",
        description: "As senhas digitadas não são iguais.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      console.log("Iniciando processo de registro...")

      // 1. Criar o usuário no Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            nome,
          },
        },
      })

      if (authError) {
        console.error("Erro ao criar usuário:", authError)
        throw authError
      }

      console.log("Usuário criado com sucesso:", authData.user?.id)

      if (authData.user) {
        // 2. Criar a clínica
        const { data: clinicaData, error: clinicaError } = await supabase
          .from("clinicas")
          .insert({
            nome: nomeClinica,
            criado_por: authData.user.id,
            plano: "trial", // Plano de teste gratuito
            status: "ativo",
          })
          .select()

        if (clinicaError) {
          console.error("Erro ao criar clínica:", clinicaError)
          throw clinicaError
        }

        console.log("Clínica criada com sucesso:", clinicaData)
        const clinicaId = clinicaData[0].id

        // 3. Criar o perfil do usuário
        const { error: perfilError } = await supabase.from("perfis_usuario").insert({
          id: authData.user.id,
          email,
          nome,
          clinica_id: clinicaId,
          funcao: "admin", // Primeiro usuário é sempre admin
          status: "ativo",
        })

        if (perfilError) {
          console.error("Erro ao criar perfil:", perfilError)
          throw perfilError
        }

        console.log("Perfil criado com sucesso")

        toast({
          title: "Conta criada com sucesso",
          description: "Você será redirecionado para o processo de configuração inicial.",
        })

        // Redirecionar para o onboarding
        router.push("/onboarding")
        router.refresh()
      }
    } catch (error: any) {
      console.error("Erro completo:", error)

      let errorMessage = "Ocorreu um erro ao tentar criar sua conta."

      // Mensagens de erro mais específicas
      if (error.message.includes("duplicate key")) {
        errorMessage = "Este e-mail já está em uso. Por favor, tente outro ou faça login."
      } else if (error.message.includes("password")) {
        errorMessage = "A senha deve ter pelo menos 6 caracteres."
      } else if (error.message.includes("email")) {
        errorMessage = "Por favor, forneça um e-mail válido."
      }

      toast({
        title: "Erro ao criar conta",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="nome">Nome completo</Label>
        <div className="mt-1">
          <Input
            id="nome"
            name="nome"
            type="text"
            autoComplete="name"
            required
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="email">E-mail</Label>
        <div className="mt-1">
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="nomeClinica">Nome da Clínica</Label>
        <div className="mt-1">
          <Input
            id="nomeClinica"
            name="nomeClinica"
            type="text"
            required
            value={nomeClinica}
            onChange={(e) => setNomeClinica(e.target.value)}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="password">Senha</Label>
        <div className="mt-1">
          <Input
            id="password"
            name="password"
            type="password"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="confirmPassword">Confirmar senha</Label>
        <div className="mt-1">
          <Input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            autoComplete="new-password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>
      </div>

      <div>
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Criando conta..." : "Criar conta"}
        </Button>
      </div>
    </form>
  )
}

