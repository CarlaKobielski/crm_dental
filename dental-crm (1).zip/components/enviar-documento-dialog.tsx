"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { supabase } from "@/lib/supabase" // Importar o cliente Supabase do lado do cliente
import { toast } from "@/components/ui/use-toast"

export function EnviarDocumentoDialog() {
  const [open, setOpen] = useState(false)
  const [pacientes, setPacientes] = useState<any[]>([])
  const [selectedPaciente, setSelectedPaciente] = useState<string | undefined>(undefined)
  const [nomeDocumento, setNomeDocumento] = useState("")
  const [tipoDocumento, setTipoDocumento] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Usar o cliente Supabase do lado do cliente
        const { data, error } = await supabase.from("pacientes").select("id, nome")

        if (error) {
          throw error
        }

        setPacientes(data || [])
      } catch (error) {
        console.error("Erro ao buscar pacientes:", error)
        toast({
          title: "Erro ao carregar pacientes",
          description: "Não foi possível carregar a lista de pacientes",
          variant: "destructive",
        })
      }
    }

    if (open) {
      fetchData()
    }
  }, [open])

  const handleSubmit = async () => {
    if (!selectedPaciente || !nomeDocumento || !tipoDocumento) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // Implementar a lógica de envio do documento aqui
      const { error } = await supabase.from("documentos").insert({
        paciente_id: selectedPaciente,
        nome: nomeDocumento,
        tipo: tipoDocumento,
        created_at: new Date().toISOString(),
      })

      if (error) throw error

      toast({
        title: "Documento registrado",
        description: "O documento foi registrado com sucesso",
      })

      // Limpar o formulário
      setSelectedPaciente(undefined)
      setNomeDocumento("")
      setTipoDocumento("")
      setOpen(false)
    } catch (error) {
      console.error("Erro ao registrar documento:", error)
      toast({
        title: "Erro ao registrar documento",
        description: "Não foi possível registrar o documento",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Enviar Documento</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Enviar Novo Documento</DialogTitle>
          <DialogDescription>Selecione o paciente, nomeie e defina o tipo do documento.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="paciente" className="text-right">
              Paciente
            </Label>
            <Select onValueChange={setSelectedPaciente} value={selectedPaciente}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione um paciente" />
              </SelectTrigger>
              <SelectContent>
                {pacientes.map((paciente) => (
                  <SelectItem key={paciente.id} value={paciente.id.toString()}>
                    {paciente.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Nome
            </Label>
            <Input
              id="name"
              value={nomeDocumento}
              onChange={(e) => setNomeDocumento(e.target.value)}
              className="col-span-3"
              type="text"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="tipo" className="text-right">
              Tipo
            </Label>
            <Select onValueChange={setTipoDocumento} value={tipoDocumento}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="prontuario">Prontuário</SelectItem>
                <SelectItem value="exame">Exame</SelectItem>
                <SelectItem value="receita">Receita</SelectItem>
                <SelectItem value="atestado">Atestado</SelectItem>
                <SelectItem value="radiografia">Radiografia</SelectItem>
                <SelectItem value="outro">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button type="submit" onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? "Enviando..." : "Enviar Documento"}
        </Button>
      </DialogContent>
    </Dialog>
  )
}

