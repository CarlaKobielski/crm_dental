"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"

export function RestoreButton() {
  const [isLoading, setIsLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  async function handleRestore(event: React.ChangeEvent<HTMLInputElement>) {
    if (!event.target.files || event.target.files.length === 0) return

    const file = event.target.files[0]
    setIsLoading(true)

    try {
      const fileContent = await file.text()
      const backupData = JSON.parse(fileContent)

      const response = await fetch("/api/restore", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(backupData),
      })

      if (!response.ok) throw new Error("Falha ao restaurar backup")

      const result = await response.json()
      alert("Backup restaurado com sucesso!")
      window.location.reload()
    } catch (error) {
      console.error("Erro ao restaurar backup:", error)
      alert("Erro ao restaurar backup. Verifique o arquivo e tente novamente.")
    } finally {
      setIsLoading(false)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  function handleClick() {
    fileInputRef.current?.click()
  }

  return (
    <>
      <input type="file" ref={fileInputRef} onChange={handleRestore} accept=".json" className="hidden" />
      <Button onClick={handleClick} disabled={isLoading} variant="outline">
        <Upload className="mr-2 h-4 w-4" />
        {isLoading ? "Restaurando..." : "Restaurar Backup"}
      </Button>
    </>
  )
}

