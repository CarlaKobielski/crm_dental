"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface ConfiguracoesNotificacoes {
  id?: number
  clinica_id: string
  notificacoes_email_ativo: boolean
  notificacoes_sms_ativo: boolean
  notificacoes_whatsapp_ativo: boolean
  template_email_consulta: string
  template_sms_consulta: string
  template_whatsapp_consulta: string
  antecedencia_lembrete_horas: number
  whatsapp_api_key?: string
  whatsapp_phone_number_id?: string
  whatsapp_provider: string
}

const configuracoesDefault: ConfiguracoesNotificacoes = {
  clinica_id: "",
  notificacoes_email_ativo: false,
  notificacoes_sms_ativo: false,
  notificacoes_whatsapp_ativo: true,
  template_email_consulta: `
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
  <h2 style="color: #4f46e5;">Lembrete de Consulta</h2>
  <p>Olá, {paciente}!</p>
  <p>Este é um lembrete para sua consulta agendada:</p>
  <div style="background-color: #f9fafb; padding: 15px; border-radius: 5px; margin: 15px 0;">
    <p><strong>Data:</strong> {data}</p>
    <p><strong>Horário:</strong> {hora}</p>
    <p><strong>Clínica:</strong> {clinica}</p>
  </div>
  <p>Caso precise remarcar, entre em contato conosco.</p>
  <p>Atenciosamente,<br>Equipe {clinica}</p>
</div>
  `,
  template_sms_consulta:
    "Lembrete: Você tem uma consulta agendada para {data} às {hora} na {clinica}. Caso precise remarcar, entre em contato.",
  template_whatsapp_consulta:
    "Olá {paciente}, este é um lembrete para sua consulta agendada para {data} às {hora} na {clinica}. Caso precise remarcar, entre em contato conosco.",
  antecedencia_lembrete_horas: 24,
  whatsapp_provider: "meta",
}

export function ConfiguracoesNotificacoes({ clinicaId }: { clinicaId: string }) {
  const [configuracoes, setConfiguracoes] = useState<ConfiguracoesNotificacoes>({
    ...configuracoesDefault,
    clinica_id: clinicaId,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [testEmail, setTestEmail] = useState("")
  const [testPhone, setTestPhone] = useState("")
  const [testWhatsApp, setTestWhatsApp] = useState("")
  const [isSendingTest, setIsSendingTest] = useState(false)
  const [activeTab, setActiveTab] = useState("whatsapp")
  const [whatsappApiKey, setWhatsappApiKey] = useState("")
  const [whatsappPhoneNumberId, setWhatsappPhoneNumberId] = useState("")
  const [whatsappConfigTab, setWhatsappConfigTab] = useState("templates")

  useEffect(() => {
    const fetchConfiguracoes = async () => {
      setIsLoading(true)
      try {
        const { data, error } = await supabase
          .from("configuracoes_notificacoes")
          .select("*")
          .eq("clinica_id", clinicaId)
          .single()

        if (error && error.code !== "PGRST116") {
          throw error
        }

        if (data) {
          setConfiguracoes(data)
          // Não exibimos as credenciais, apenas indicamos se estão configuradas
          setWhatsappApiKey(data.whatsapp_api_key ? "••••••••••••••••" : "")
          setWhatsappPhoneNumberId(data.whatsapp_phone_number_id || "")
        }
      } catch (error) {
        console.error("Erro ao carregar configurações de notificações:", error)
        toast({
          title: "Erro ao carregar configurações",
          description: "Não foi possível carregar as configurações de notificações.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (clinicaId) {
      fetchConfiguracoes()
    }
  }, [clinicaId])

  const handleSave = async () => {
    setIsSaving(true)
    try {
      // Preparar dados para salvar
      const dataToSave = {
        ...configuracoes,
        clinica_id: clinicaId,
      }

      // Se o usuário inseriu uma nova chave de API, incluí-la
      if (whatsappApiKey && !whatsappApiKey.includes("•")) {
        dataToSave.whatsapp_api_key = whatsappApiKey
      }

      // Incluir o ID do número de telefone
      if (whatsappPhoneNumberId) {
        dataToSave.whatsapp_phone_number_id = whatsappPhoneNumberId
      }

      const { data, error } = await supabase.from("configuracoes_notificacoes").upsert(dataToSave).select()

      if (error) throw error

      setConfiguracoes((prev) => ({ ...prev, id: data?.[0]?.id || prev.id }))

      toast({
        title: "Configurações salvas",
        description: "As configurações de notificações foram salvas com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      toast({
        title: "Erro ao salvar configurações",
        description: "Não foi possível salvar as configurações de notificações.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleSendTestNotification = async (type: "email" | "sms" | "whatsapp") => {
    setIsSendingTest(true)
    try {
      const endpoint = `/api/notificacoes/test-${type}`
      let to = ""
      let template = ""

      if (type === "email") {
        to = testEmail
        template = configuracoes.template_email_consulta
      } else if (type === "sms") {
        to = testPhone
        template = configuracoes.template_sms_consulta
      } else if (type === "whatsapp") {
        to = testWhatsApp
        template = configuracoes.template_whatsapp_consulta
      }

      if (!to) {
        toast({
          title: `${type === "email" ? "E-mail" : type === "sms" ? "Telefone" : "WhatsApp"} não informado`,
          description: `Por favor, informe um ${type === "email" ? "e-mail" : "número de telefone"} para enviar o teste.`,
          variant: "destructive",
        })
        return
      }

      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          to,
          template,
          clinicaId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        if (data.needsConfig) {
          toast({
            title: "Configuração necessária",
            description: "Configure as credenciais do WhatsApp antes de enviar mensagens de teste.",
            variant: "warning",
          })
          setWhatsappConfigTab("credenciais")
          return
        }

        throw new Error(
          data.error || `Erro ao enviar ${type === "email" ? "e-mail" : type === "sms" ? "SMS" : "WhatsApp"} de teste`,
        )
      }

      toast({
        title: `${type === "email" ? "E-mail" : type === "sms" ? "SMS" : "WhatsApp"} de teste enviado`,
        description: `A mensagem de teste foi enviada com sucesso para ${to}.`,
      })
    } catch (error) {
      console.error(`Erro ao enviar ${type} de teste:`, error)
      toast({
        title: `Erro ao enviar ${type === "email" ? "e-mail" : type === "sms" ? "SMS" : "WhatsApp"} de teste`,
        description: error instanceof Error ? error.message : "Ocorreu um erro ao enviar a notificação de teste.",
        variant: "destructive",
      })
    } finally {
      setIsSendingTest(false)
    }
  }

  if (isLoading) {
    return <div className="text-center py-4">Carregando configurações...</div>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Configurações de Notificações</CardTitle>
          <CardDescription>Configure como o sistema enviará notificações aos pacientes.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="notificacoes_whatsapp_ativo">Notificações por WhatsApp</Label>
              <p className="text-sm text-gray-500">Enviar lembretes de consulta por WhatsApp</p>
            </div>
            <Switch
              id="notificacoes_whatsapp_ativo"
              checked={configuracoes.notificacoes_whatsapp_ativo}
              onCheckedChange={(checked) =>
                setConfiguracoes({ ...configuracoes, notificacoes_whatsapp_ativo: checked })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="notificacoes_email_ativo">Notificações por E-mail</Label>
              <p className="text-sm text-gray-500">Enviar lembretes de consulta por e-mail</p>
            </div>
            <Switch
              id="notificacoes_email_ativo"
              checked={configuracoes.notificacoes_email_ativo}
              onCheckedChange={(checked) => setConfiguracoes({ ...configuracoes, notificacoes_email_ativo: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="notificacoes_sms_ativo">Notificações por SMS</Label>
              <p className="text-sm text-gray-500">Enviar lembretes de consulta por SMS</p>
            </div>
            <Switch
              id="notificacoes_sms_ativo"
              checked={configuracoes.notificacoes_sms_ativo}
              onCheckedChange={(checked) => setConfiguracoes({ ...configuracoes, notificacoes_sms_ativo: checked })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="antecedencia_lembrete_horas">Antecedência do Lembrete (horas)</Label>
            <Input
              id="antecedencia_lembrete_horas"
              type="number"
              min="1"
              max="72"
              value={configuracoes.antecedencia_lembrete_horas}
              onChange={(e) =>
                setConfiguracoes({
                  ...configuracoes,
                  antecedencia_lembrete_horas: Number.parseInt(e.target.value) || 24,
                })
              }
            />
            <p className="text-xs text-gray-500">Quantas horas antes da consulta o lembrete deve ser enviado.</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
              <TabsTrigger value="email">E-mail</TabsTrigger>
              <TabsTrigger value="sms">SMS</TabsTrigger>
            </TabsList>

            <TabsContent value="whatsapp" className="space-y-4 pt-4">
              <Tabs value={whatsappConfigTab} onValueChange={setWhatsappConfigTab}>
                <TabsList className="w-full">
                  <TabsTrigger value="templates">Templates</TabsTrigger>
                  <TabsTrigger value="credenciais">Credenciais</TabsTrigger>
                </TabsList>

                <TabsContent value="templates" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="template_whatsapp_consulta">Template de WhatsApp para Consultas</Label>
                    <Textarea
                      id="template_whatsapp_consulta"
                      value={configuracoes.template_whatsapp_consulta}
                      onChange={(e) =>
                        setConfiguracoes({ ...configuracoes, template_whatsapp_consulta: e.target.value })
                      }
                      rows={5}
                    />
                    <p className="text-xs text-gray-500">
                      Use {"{paciente}"} para o nome do paciente, {"{data}"} para a data, {"{hora}"} para o horário e{" "}
                      {"{clinica}"} para o nome da clínica.
                    </p>

                    <div className="flex items-end gap-2 mt-2">
                      <div className="flex-1">
                        <Label htmlFor="test_whatsapp">Número para teste (WhatsApp)</Label>
                        <Input
                          id="test_whatsapp"
                          type="tel"
                          placeholder="(11) 99999-9999"
                          value={testWhatsApp}
                          onChange={(e) => setTestWhatsApp(e.target.value)}
                        />
                      </div>
                      <Button
                        onClick={() => handleSendTestNotification("whatsapp")}
                        disabled={isSendingTest || !testWhatsApp}
                        size="sm"
                      >
                        Enviar Teste
                      </Button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="credenciais" className="space-y-4 pt-4">
                  <Alert className="mb-4">
                    <Info className="h-4 w-4" />
                    <AlertTitle>Configuração do WhatsApp Business API</AlertTitle>
                    <AlertDescription>
                      Configure as credenciais da API do WhatsApp Business para enviar mensagens aos pacientes. Você
                      precisará obter essas informações no painel do provedor escolhido.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="whatsapp_provider">Provedor de WhatsApp</Label>
                      <Select
                        value={configuracoes.whatsapp_provider}
                        onValueChange={(value) => setConfiguracoes({ ...configuracoes, whatsapp_provider: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o provedor" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="meta">Meta WhatsApp Business API</SelectItem>
                          <SelectItem value="twilio">Twilio</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-gray-500">
                        Selecione o provedor que você está utilizando para enviar mensagens pelo WhatsApp.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="whatsapp_api_key">Chave da API (Token de Acesso)</Label>
                      <Input
                        id="whatsapp_api_key"
                        type="password"
                        value={whatsappApiKey}
                        onChange={(e) => setWhatsappApiKey(e.target.value)}
                        placeholder="Insira a chave da API do WhatsApp"
                      />
                      <p className="text-xs text-gray-500">
                        {configuracoes.whatsapp_provider === "meta"
                          ? "Token de acesso permanente da API do WhatsApp Business"
                          : "Token de autenticação do Twilio (Auth Token)"}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="whatsapp_phone_number_id">
                        {configuracoes.whatsapp_provider === "meta"
                          ? "ID do Número de Telefone"
                          : "SID da Conta e Número do WhatsApp"}
                      </Label>
                      <Input
                        id="whatsapp_phone_number_id"
                        value={whatsappPhoneNumberId}
                        onChange={(e) => setWhatsappPhoneNumberId(e.target.value)}
                        placeholder={
                          configuracoes.whatsapp_provider === "meta"
                            ? "Ex: 123456789012345"
                            : "Ex: AC1234567890:+5511999999999"
                        }
                      />
                      <p className="text-xs text-gray-500">
                        {configuracoes.whatsapp_provider === "meta"
                          ? "ID do número de telefone registrado no WhatsApp Business"
                          : "SID da conta Twilio seguido de dois pontos e o número do WhatsApp (formato: SID:+número)"}
                      </p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </TabsContent>

            <TabsContent value="email" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="template_email_consulta">Template de E-mail para Consultas</Label>
                <Textarea
                  id="template_email_consulta"
                  value={configuracoes.template_email_consulta}
                  onChange={(e) => setConfiguracoes({ ...configuracoes, template_email_consulta: e.target.value })}
                  rows={10}
                />
                <p className="text-xs text-gray-500">
                  Use {"{paciente}"} para o nome do paciente, {"{data}"} para a data, {"{hora}"} para o horário e{" "}
                  {"{clinica}"} para o nome da clínica.
                </p>

                <div className="flex items-end gap-2 mt-2">
                  <div className="flex-1">
                    <Label htmlFor="test_email">E-mail para teste</Label>
                    <Input
                      id="test_email"
                      type="email"
                      placeholder="exemplo@email.com"
                      value={testEmail}
                      onChange={(e) => setTestEmail(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={() => handleSendTestNotification("email")}
                    disabled={isSendingTest || !testEmail}
                    size="sm"
                  >
                    Enviar Teste
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="sms" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="template_sms_consulta">Template de SMS para Consultas</Label>
                <Textarea
                  id="template_sms_consulta"
                  value={configuracoes.template_sms_consulta}
                  onChange={(e) => setConfiguracoes({ ...configuracoes, template_sms_consulta: e.target.value })}
                  rows={3}
                />
                <p className="text-xs text-gray-500">
                  Use {"{paciente}"} para o nome do paciente, {"{data}"} para a data, {"{hora}"} para o horário e{" "}
                  {"{clinica}"} para o nome da clínica.
                </p>

                <div className="flex items-end gap-2 mt-2">
                  <div className="flex-1">
                    <Label htmlFor="test_phone">Telefone para teste</Label>
                    <Input
                      id="test_phone"
                      type="tel"
                      placeholder="(11) 99999-9999"
                      value={testPhone}
                      onChange={(e) => setTestPhone(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={() => handleSendTestNotification("sms")}
                    disabled={isSendingTest || !testPhone}
                    size="sm"
                  >
                    Enviar Teste
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSave} disabled={isLoading || isSaving}>
            {isSaving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

