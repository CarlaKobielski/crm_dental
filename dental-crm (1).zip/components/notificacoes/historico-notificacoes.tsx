"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { RefreshCw, Mail, MessageSquare, MessageCircle } from "lucide-react"

interface Notificacao {
  id: number
  paciente_id: number
  consulta_id: number | null
  destinatario: string
  tipo: "email" | "sms" | "whatsapp"
  assunto: string
  mensagem: string
  status: "agendado" | "enviado" | "falha" | "cancelado"
  data_envio: string
  data_processamento: string | null
  created_at: string
  paciente?: {
    nome: string
  }
}

export function HistoricoNotificacoes({ clinicaId }: { clinicaId: string }) {
  const [notificacoes, setNotificacoes] = useState<Notificacao[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const limit = 10

  const fetchNotificacoes = async () => {
    setIsLoading(true)
    try {
      const from = (page - 1) * limit
      const to = from + limit - 1

      const { data, error, count } = await supabase
        .from("notificacoes")
        .select(
          `
          *,
          paciente:paciente_id (
            nome
          )
        `,
          { count: "exact" },
        )
        .eq("clinica_id", clinicaId)
        .order("data_envio", { ascending: false })
        .range(from, to)

      if (error) throw error

      setNotificacoes(data || [])
      setTotalPages(Math.ceil((count || 0) / limit))
    } catch (error) {
      console.error("Erro ao carregar notificações:", error)
      toast({
        title: "Erro ao carregar notificações",
        description: "Não foi possível carregar o histórico de notificações.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (clinicaId) {
      fetchNotificacoes()
    }
  }, [clinicaId, page])

  const handlePageChange = (newPage: number) => {
    setPage(newPage)
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A"
    return new Date(dateString).toLocaleString("pt-BR")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "agendado":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Agendado
          </Badge>
        )
      case "enviado":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Enviado
          </Badge>
        )
      case "falha":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Falha
          </Badge>
        )
      case "cancelado":
        return (
          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
            Cancelado
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case "email":
        return <Mail className="h-4 w-4 text-blue-500" />
      case "sms":
        return <MessageSquare className="h-4 w-4 text-green-500" />
      case "whatsapp":
        return <MessageCircle className="h-4 w-4 text-green-600" />
      default:
        return null
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Histórico de Notificações</CardTitle>
          <CardDescription>Histórico de notificações enviadas aos pacientes</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={fetchNotificacoes} disabled={isLoading}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Atualizar
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4">Carregando notificações...</div>
        ) : notificacoes.length === 0 ? (
          <div className="text-center py-4 text-gray-500">Nenhuma notificação encontrada.</div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Paciente</TableHead>
                  <TableHead>Destinatário</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data de Envio</TableHead>
                  <TableHead>Processado em</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {notificacoes.map((notificacao) => (
                  <TableRow key={notificacao.id}>
                    <TableCell>
                      <div className="flex items-center">
                        {getTipoIcon(notificacao.tipo)}
                        <span className="ml-2 capitalize">{notificacao.tipo}</span>
                      </div>
                    </TableCell>
                    <TableCell>{notificacao.paciente?.nome || "N/A"}</TableCell>
                    <TableCell>{notificacao.destinatario}</TableCell>
                    <TableCell>{getStatusBadge(notificacao.status)}</TableCell>
                    <TableCell>{formatDate(notificacao.data_envio)}</TableCell>
                    <TableCell>{formatDate(notificacao.data_processamento)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {totalPages > 1 && (
              <div className="flex justify-center mt-4">
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handlePageChange(page - 1)} disabled={page === 1}>
                    Anterior
                  </Button>
                  <div className="flex items-center px-4">
                    Página {page} de {totalPages}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(page + 1)}
                    disabled={page === totalPages}
                  >
                    Próxima
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}

