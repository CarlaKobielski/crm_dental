"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export function BackupButton() {
  const [isLoading, setIsLoading] = useState(false)

  async function handleBackup() {
    setIsLoading(true)
    try {
      const response = await fetch("/api/backup")

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.details || "Falha ao gerar backup")
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `dental-crm-backup-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      toast({
        title: "Backup concluído",
        description: "O backup foi gerado com sucesso.",
        variant: "default",
      })
    } catch (error) {
      console.error("Erro ao fazer backup:", error)
      toast({
        title: "Erro ao gerar backup",
        description: String(error),
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleBackup} disabled={isLoading}>
      <Download className="mr-2 h-4 w-4" />
      {isLoading ? "Gerando backup..." : "Fazer Backup"}
    </Button>
  )
}

