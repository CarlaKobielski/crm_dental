"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Database } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { initializeBuckets } from "@/lib/storage"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { STORAGE_BUCKETS } from "@/lib/storage"

export function InitializeStorageButton() {
  const [isLoading, setIsLoading] = useState(false)
  const [showManualInstructions, setShowManualInstructions] = useState(false)

  async function handleInitializeStorage() {
    setIsLoading(true)
    try {
      console.log("Iniciando criação de buckets de armazenamento...")
      const success = await initializeBuckets()

      if (success) {
        toast({
          title: "Armazenamento inicializado",
          description: "Os buckets de armazenamento foram inicializados com sucesso ou já existem.",
          variant: "default",
        })
        console.log("Buckets inicializados com sucesso")
      } else {
        // Mostrar instruções manuais se a inicialização automática falhar
        setShowManualInstructions(true)
        toast({
          title: "Inicialização parcial",
          description: "Alguns buckets podem precisar ser criados manualmente. Veja as instruções.",
          variant: "warning",
        })
      }
    } catch (error) {
      console.error("Erro ao inicializar armazenamento:", error)
      setShowManualInstructions(true)
      toast({
        title: "Erro ao inicializar armazenamento",
        description: "Ocorreu um erro ao inicializar os buckets. Veja as instruções para criação manual.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <Button onClick={handleInitializeStorage} disabled={isLoading} variant="outline">
        <Database className="mr-2 h-4 w-4" />
        {isLoading ? "Inicializando..." : "Inicializar Armazenamento"}
      </Button>

      <Dialog open={showManualInstructions} onOpenChange={setShowManualInstructions}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Instruções para Criação Manual de Buckets</DialogTitle>
            <DialogDescription>
              Devido a restrições de segurança, alguns buckets podem precisar ser criados manualmente no painel do
              Supabase.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 my-4">
            <p>Siga estas etapas para criar os buckets necessários:</p>

            <ol className="list-decimal pl-5 space-y-2">
              <li>Acesse o painel de administração do Supabase</li>
              <li>Navegue até a seção "Storage"</li>
              <li>Clique em "New Bucket" para cada um dos seguintes buckets:</li>
              <ul className="list-disc pl-5 mt-2">
                {Object.values(STORAGE_BUCKETS).map((bucket) => (
                  <li key={bucket}>
                    <code>{bucket}</code>
                  </li>
                ))}
              </ul>
              <li>
                Para cada bucket, marque a opção "Public" se desejar que os arquivos sejam acessíveis publicamente
              </li>
              <li>Configure as políticas RLS (Row Level Security) conforme necessário</li>
            </ol>

            <div className="bg-amber-50 p-4 rounded-md border border-amber-200 mt-4">
              <p className="text-amber-800 font-medium">Importante:</p>
              <p className="text-amber-700 text-sm mt-1">
                Para que o sistema funcione corretamente, você precisa configurar políticas RLS adequadas para permitir
                que os usuários autenticados possam fazer upload, listar e excluir arquivos nos buckets.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button onClick={() => setShowManualInstructions(false)}>Entendi</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

