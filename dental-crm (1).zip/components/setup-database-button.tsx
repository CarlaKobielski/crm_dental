"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { supabase } from "@/lib/supabase"
import { toast } from "@/components/ui/use-toast"

export function SetupDatabaseButton() {
  const [isLoading, setIsLoading] = useState(false)

  async function setupDatabase() {
    setIsLoading(true)
    try {
      // Verificar se a função execute_sql existe
      const { data: functionExists, error: functionError } = await supabase
        .rpc("execute_sql", {
          sql_query: "SELECT 1",
        })
        .single()

      // Se a função não existir, mostrar instruções
      if (
        functionError &&
        functionError.message.includes("function") &&
        functionError.message.includes("does not exist")
      ) {
        toast({
          title: "Função SQL não encontrada",
          description:
            "A função execute_sql não existe no seu banco de dados. Por favor, crie-a manualmente no painel do Supabase.",
          variant: "destructive",
        })
        return
      }

      // Criar tabelas
      await supabase.rpc("execute_sql", {
        sql_query: `
          -- Tabela de clínicas (tenants)
          CREATE TABLE IF NOT EXISTS clinicas (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            nome TEXT NOT NULL,
            endereco TEXT,
            telefone TEXT,
            email TEXT,
            site TEXT,
            logo_url TEXT,
            plano TEXT NOT NULL DEFAULT 'trial',
            status TEXT NOT NULL DEFAULT 'ativo',
            data_expiracao TIMESTAMP WITH TIME ZONE,
            stripe_customer_id TEXT,
            stripe_subscription_id TEXT,
            criado_por UUID NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      await supabase.rpc("execute_sql", {
        sql_query: `
          -- Tabela de perfis de usuário
          CREATE TABLE IF NOT EXISTS perfis_usuario (
            id UUID PRIMARY KEY REFERENCES auth.users(id),
            email TEXT NOT NULL UNIQUE,
            nome TEXT NOT NULL,
            clinica_id UUID REFERENCES clinicas(id),
            funcao TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'ativo',
            ultimo_acesso TIMESTAMP WITH TIME ZONE,
            onboarding_completo BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Habilitar RLS
      await supabase.rpc("execute_sql", {
        sql_query: `
          -- Habilitar RLS para as tabelas
          ALTER TABLE clinicas ENABLE ROW LEVEL SECURITY;
          ALTER TABLE perfis_usuario ENABLE ROW LEVEL SECURITY;
        `,
      })

      // Criar políticas RLS
      await supabase.rpc("execute_sql", {
        sql_query: `
          -- Políticas RLS para clínicas
          CREATE POLICY IF NOT EXISTS "Usuários podem ver sua própria clínica" ON clinicas
          FOR SELECT
          USING (auth.uid() IN (
            SELECT id FROM perfis_usuario WHERE clinica_id = clinicas.id
          ));

          CREATE POLICY IF NOT EXISTS "Usuários podem inserir clínicas" ON clinicas
          FOR INSERT
          WITH CHECK (auth.uid() = criado_por);

          CREATE POLICY IF NOT EXISTS "Apenas administradores podem editar clínicas" ON clinicas
          FOR UPDATE
          USING (auth.uid() IN (
            SELECT id FROM perfis_usuario WHERE clinica_id = clinicas.id AND funcao = 'admin'
          ));
        `,
      })

      await supabase.rpc("execute_sql", {
        sql_query: `
          -- Políticas RLS para perfis de usuário
          CREATE POLICY IF NOT EXISTS "Usuários podem ver perfis da mesma clínica" ON perfis_usuario
          FOR SELECT
          USING (
            auth.uid() IN (
              SELECT id FROM perfis_usuario WHERE clinica_id = perfis_usuario.clinica_id
            ) OR auth.uid() = perfis_usuario.id
          );

          CREATE POLICY IF NOT EXISTS "Usuários podem inserir seu próprio perfil" ON perfis_usuario
          FOR INSERT
          WITH CHECK (auth.uid() = id);

          CREATE POLICY IF NOT EXISTS "Usuários podem atualizar seu próprio perfil" ON perfis_usuario
          FOR UPDATE
          USING (auth.uid() = id);

          CREATE POLICY IF NOT EXISTS "Apenas administradores podem gerenciar outros usuários" ON perfis_usuario
          FOR ALL
          USING (
            auth.uid() IN (
              SELECT id FROM perfis_usuario WHERE clinica_id = perfis_usuario.clinica_id AND funcao = 'admin'
            ) OR auth.uid() = perfis_usuario.id
          );
        `,
      })

      toast({
        title: "Banco de dados configurado",
        description: "As tabelas e políticas foram criadas com sucesso.",
      })
    } catch (error: any) {
      console.error("Erro ao configurar banco de dados:", error)
      toast({
        title: "Erro ao configurar banco de dados",
        description: error.message || "Ocorreu um erro ao configurar o banco de dados.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={setupDatabase} disabled={isLoading}>
      {isLoading ? "Configurando..." : "Configurar Banco de Dados"}
    </Button>
  )
}

