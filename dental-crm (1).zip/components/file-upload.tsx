"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, X, FileText, Image, File } from "lucide-react"
import { uploadFile } from "@/lib/storage"
import { toast } from "@/components/ui/use-toast"

interface FileUploadProps {
  bucket: string
  path?: string
  onUploadComplete?: (fileData: { url: string; path: string; name: string; size: number; type: string }) => void
  allowedTypes?: string[]
  maxSizeMB?: number
}

export function FileUpload({
  bucket,
  path = "",
  onUploadComplete,
  allowedTypes = [],
  maxSizeMB = 10,
}: FileUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  function handleFileChange(event: React.ChangeEvent<HTMLInputElement>) {
    if (!event.target.files || event.target.files.length === 0) {
      setFile(null)
      return
    }

    const selectedFile = event.target.files[0]

    // Verificar tipo de arquivo
    if (allowedTypes.length > 0 && !allowedTypes.includes(selectedFile.type)) {
      toast({
        title: "Tipo de arquivo não permitido",
        description: `Por favor, selecione um arquivo do tipo: ${allowedTypes.join(", ")}`,
        variant: "destructive",
      })
      return
    }

    // Verificar tamanho do arquivo
    const maxSizeBytes = maxSizeMB * 1024 * 1024
    if (selectedFile.size > maxSizeBytes) {
      toast({
        title: "Arquivo muito grande",
        description: `O tamanho máximo permitido é ${maxSizeMB}MB`,
        variant: "destructive",
      })
      return
    }

    setFile(selectedFile)
  }

  function handleRemoveFile() {
    setFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  async function handleUpload() {
    if (!file) return

    setIsUploading(true)
    setProgress(0)

    // Simulação de progresso (na prática, você usaria um hook de upload com progresso real)
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) {
          clearInterval(progressInterval)
          return prev
        }
        return prev + 5
      })
    }, 100)

    try {
      const result = await uploadFile(bucket, file, path)

      if (!result) {
        throw new Error("Falha ao fazer upload do arquivo")
      }

      setProgress(100)

      toast({
        title: "Upload concluído",
        description: "O arquivo foi enviado com sucesso",
      })

      if (onUploadComplete) {
        onUploadComplete({
          ...result,
          name: file.name,
          size: file.size,
          type: file.type,
        })
      }

      // Limpar após o upload
      setTimeout(() => {
        setFile(null)
        setProgress(0)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
      }, 1500)
    } catch (error) {
      console.error("Erro no upload:", error)
      toast({
        title: "Erro no upload",
        description: "Ocorreu um erro ao enviar o arquivo",
        variant: "destructive",
      })
    } finally {
      clearInterval(progressInterval)
      setIsUploading(false)
    }
  }

  function getFileIcon() {
    if (!file) return <Upload className="h-12 w-12 text-gray-400" />

    if (file.type.startsWith("image/")) {
      return <Image className="h-12 w-12 text-blue-500" />
    } else if (file.type === "application/pdf") {
      return <FileText className="h-12 w-12 text-red-500" />
    } else {
      return <File className="h-12 w-12 text-green-500" />
    }
  }

  // Função para acionar o input de arquivo
  function handleAreaClick() {
    if (fileInputRef.current && !isUploading) {
      fileInputRef.current.click()
    }
  }

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="flex flex-col items-center justify-center gap-4">
          {/* Área clicável para selecionar arquivo */}
          <div
            className="flex flex-col items-center justify-center w-full p-4 border-2 border-dashed rounded-lg cursor-pointer hover:bg-gray-50"
            onClick={handleAreaClick}
            onDragOver={(e) => {
              e.preventDefault()
              e.stopPropagation()
            }}
            onDrop={(e) => {
              e.preventDefault()
              e.stopPropagation()

              if (e.dataTransfer.files && e.dataTransfer.files.length > 0 && !isUploading) {
                const droppedFile = e.dataTransfer.files[0]

                // Verificar tipo de arquivo
                if (allowedTypes.length > 0 && !allowedTypes.includes(droppedFile.type)) {
                  toast({
                    title: "Tipo de arquivo não permitido",
                    description: `Por favor, selecione um arquivo do tipo: ${allowedTypes.join(", ")}`,
                    variant: "destructive",
                  })
                  return
                }

                // Verificar tamanho do arquivo
                const maxSizeBytes = maxSizeMB * 1024 * 1024
                if (droppedFile.size > maxSizeBytes) {
                  toast({
                    title: "Arquivo muito grande",
                    description: `O tamanho máximo permitido é ${maxSizeMB}MB`,
                    variant: "destructive",
                  })
                  return
                }

                setFile(droppedFile)
              }
            }}
          >
            {getFileIcon()}

            <div className="mt-4 text-center">
              {!file ? (
                <>
                  <p className="text-sm text-gray-500">Clique para selecionar ou arraste um arquivo</p>
                  <p className="text-xs text-gray-400 mt-1">
                    {allowedTypes.length > 0
                      ? `Tipos permitidos: ${allowedTypes.join(", ")}`
                      : "Todos os tipos de arquivo são aceitos"}
                  </p>
                  <p className="text-xs text-gray-400">Tamanho máximo: {maxSizeMB}MB</p>
                </>
              ) : (
                <>
                  <p className="text-sm font-medium">{file.name}</p>
                  <p className="text-xs text-gray-500 mt-1">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </>
              )}
            </div>

            {/* Input de arquivo oculto */}
            <Input
              ref={fileInputRef}
              type="file"
              className="hidden"
              onChange={handleFileChange}
              disabled={isUploading}
              accept={allowedTypes.length > 0 ? allowedTypes.join(",") : undefined}
            />
          </div>

          {file && (
            <>
              {isUploading && (
                <div className="w-full">
                  <Progress value={progress} className="h-2" />
                  <p className="text-xs text-center mt-1">{progress}%</p>
                </div>
              )}

              <div className="flex gap-2">
                {!isUploading && (
                  <Button onClick={handleUpload} disabled={isUploading}>
                    <Upload className="mr-2 h-4 w-4" />
                    Enviar Arquivo
                  </Button>
                )}

                <Button variant="outline" onClick={handleRemoveFile} disabled={isUploading}>
                  <X className="mr-2 h-4 w-4" />
                  Remover
                </Button>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

