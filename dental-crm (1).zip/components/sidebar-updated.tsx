"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Home,
  Users,
  Calendar,
  Stethoscope,
  FileText,
  DollarSign,
  BarChart2,
  FileBarChart,
  File,
  Bell,
  LinkIcon,
  Settings,
} from "lucide-react"

export function Sidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <div className="w-64 border-r bg-white h-screen fixed">
      <div className="p-4 border-b">
        <Link href="/dashboard" className="text-xl font-bold text-blue-600">
          Dental CRM
        </Link>
      </div>

      <div className="p-4">
        <SidebarItem href="/dashboard" icon={<Home size={20} />} label="Dashboard" active={isActive("/dashboard")} />

        <div className="mt-6">
          <p className="text-xs font-semibold text-gray-500 mb-2">ATENDIMENTO</p>
          <SidebarItem
            href="/pacientes"
            icon={<Users size={20} />}
            label="Pacientes"
            active={pathname.startsWith("/pacientes")}
          />
          <SidebarItem
            href="/consultas"
            icon={<Calendar size={20} />}
            label="Consultas"
            active={pathname.startsWith("/consultas")}
          />
        </div>

        <div className="mt-6">
          <p className="text-xs font-semibold text-gray-500 mb-2">GESTÃO ODONTOLÓGICA</p>
          <SidebarItem
            href="/tratamentos"
            icon={<Stethoscope size={20} />}
            label="Tratamentos"
            active={pathname.startsWith("/tratamentos")}
          />
          <SidebarItem
            href="/prontuario"
            icon={<FileText size={20} />}
            label="Prontuário Eletrônico"
            active={pathname.startsWith("/prontuario")}
          />
          <SidebarItem
            href="/financeiro"
            icon={<DollarSign size={20} />}
            label="Financeiro"
            active={pathname.startsWith("/financeiro")}
          />
        </div>

        <div className="mt-6">
          <p className="text-xs font-semibold text-gray-500 mb-2">MARKETING E ANÁLISE</p>
          <SidebarItem
            href="/marketing"
            icon={<BarChart2 size={20} />}
            label="Marketing"
            active={pathname.startsWith("/marketing")}
          />
          <SidebarItem
            href="/relatorios"
            icon={<FileBarChart size={20} />}
            label="Relatórios"
            active={pathname.startsWith("/relatorios")}
          />
          <SidebarItem
            href="/documentos"
            icon={<File size={20} />}
            label="Documentos"
            active={pathname.startsWith("/documentos")}
          />
        </div>

        <div className="mt-6">
          <p className="text-xs font-semibold text-gray-500 mb-2">COMUNICAÇÃO E AUTOMAÇÃO</p>
          <SidebarItem
            href="/notificacoes"
            icon={<Bell size={20} />}
            label="Notificações"
            active={pathname.startsWith("/notificacoes")}
          />
          <SidebarItem
            href="/lembretes"
            icon={<Bell size={20} />}
            label="Lembretes"
            active={pathname.startsWith("/lembretes")}
          />
          <SidebarItem
            href="/integracoes"
            icon={<LinkIcon size={20} />}
            label="Integrações"
            active={pathname.startsWith("/integracoes")}
          />
        </div>

        <div className="mt-6">
          <p className="text-xs font-semibold text-gray-500 mb-2">SISTEMA</p>
          <SidebarItem
            href="/configuracoes"
            icon={<Settings size={20} />}
            label="Configurações"
            active={pathname.startsWith("/configuracoes")}
          />
        </div>
      </div>
    </div>
  )
}

interface SidebarItemProps {
  href: string
  icon: React.ReactNode
  label: string
  active: boolean
}

function SidebarItem({ href, icon, label, active }: SidebarItemProps) {
  return (
    <Link
      href={href}
      className={`flex items-center w-full p-2 rounded-md mb-1 ${
        active ? "text-blue-600 font-medium" : "text-gray-700 hover:bg-gray-100"
      }`}
    >
      <span className="mr-3">{icon}</span>
      <span>{label}</span>
    </Link>
  )
}

