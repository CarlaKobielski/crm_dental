"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Database } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"

export function CreateTablesButton() {
  const [isLoading, setIsLoading] = useState(false)

  async function handleCreateTables() {
    setIsLoading(true)
    try {
      // Tabela de pacientes
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS pacientes (
            id SERIAL PRIMARY KEY,
            nome TEXT NOT NULL,
            email TEXT,
            telefone TEXT,
            endereco TEXT,
            data_nascimento DATE,
            observacoes TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de consultas
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS consultas (
            id SERIAL PRIMARY KEY,
            paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            data DATE NOT NULL,
            hora TIME NOT NULL,
            tipo TEXT NOT NULL,
            descricao TEXT,
            status TEXT DEFAULT 'agendado',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de tratamentos
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS tratamentos (
            id SERIAL PRIMARY KEY,
            paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            nome TEXT NOT NULL,
            descricao TEXT,
            status TEXT DEFAULT 'em andamento',
            data_inicio DATE,
            data_fim DATE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de financeiro
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS financeiro (
            id SERIAL PRIMARY KEY,
            paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            tratamento_id INTEGER REFERENCES tratamentos(id) ON DELETE SET NULL,
            valor DECIMAL(10, 2) NOT NULL,
            status_pagamento TEXT DEFAULT 'pendente',
            data_pagamento DATE,
            metodo_pagamento TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de prontuários
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS prontuarios (
            id SERIAL PRIMARY KEY,
            paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            historico_medico TEXT,
            alergias TEXT,
            medicamentos TEXT,
            observacoes TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de documentos
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS documentos (
            id SERIAL PRIMARY KEY,
            paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            nome TEXT NOT NULL,
            tipo TEXT,
            url TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de lembretes
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS lembretes (
            id SERIAL PRIMARY KEY,
            paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            consulta_id INTEGER REFERENCES consultas(id) ON DELETE SET NULL,
            mensagem TEXT NOT NULL,
            status TEXT DEFAULT 'pendente',
            data_envio TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de logs de auditoria
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS audit_logs (
            id SERIAL PRIMARY KEY,
            user_id TEXT NOT NULL,
            action TEXT NOT NULL,
            resource TEXT NOT NULL,
            resource_id TEXT NOT NULL,
            details JSONB,
            ip_address TEXT,
            timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela para dados sensíveis criptografados
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS patient_sensitive_data (
            id SERIAL PRIMARY KEY,
            patient_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
            encrypted_data TEXT NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de configurações do sistema
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS configuracoes_sistema (
            id SERIAL PRIMARY KEY,
            nome_clinica TEXT NOT NULL,
            endereco TEXT,
            telefone TEXT,
            email TEXT,
            site TEXT,
            logo_url TEXT,
            tema TEXT DEFAULT 'claro',
            cor_primaria TEXT DEFAULT '#4f46e5',
            notificacoes_email BOOLEAN DEFAULT TRUE,
            notificacoes_sms BOOLEAN DEFAULT FALSE,
            mensagem_agendamento TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Tabela de usuários
      await supabase.rpc("execute_sql", {
        sql_query: `
          CREATE TABLE IF NOT EXISTS usuarios (
            id UUID PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            nome TEXT NOT NULL,
            funcao TEXT NOT NULL,
            ultimo_acesso TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
          );
        `,
      })

      // Inserir configurações padrão se não existirem
      await supabase.rpc("execute_sql", {
        sql_query: `
          INSERT INTO configuracoes_sistema (
            nome_clinica, 
            endereco, 
            telefone, 
            email, 
            site, 
            tema, 
            cor_primaria, 
            notificacoes_email, 
            notificacoes_sms, 
            mensagem_agendamento
          )
          SELECT 
            'Minha Clínica Odontológica',
            'Rua Exemplo, 123 - Centro',
            '(11) 99999-9999',
            'contato@minhaclínica.com',
            'www.minhaclínica.com',
            'claro',
            '#4f46e5',
            TRUE,
            FALSE,
            'Olá {paciente}, confirmamos seu agendamento para {data} às {hora}. Caso precise remarcar, entre em contato conosco.'
          WHERE NOT EXISTS (SELECT 1 FROM configuracoes_sistema);
        `,
      })

      // Inserir usuário administrador padrão se não existir
      await supabase.rpc("execute_sql", {
        sql_query: `
          INSERT INTO usuarios (id, email, nome, funcao, created_at)
          SELECT 
            '00000000-0000-0000-0000-000000000000',
            'admin@dentalcrm.com',
            'Administrador',
            'admin',
            CURRENT_TIMESTAMP
          WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE email = 'admin@dentalcrm.com');
        `,
      })

      toast({
        title: "Tabelas criadas",
        description: "As tabelas foram criadas com sucesso no banco de dados.",
        variant: "default",
      })
    } catch (error) {
      console.error("Erro ao criar tabelas:", error)
      toast({
        title: "Erro ao criar tabelas",
        description: String(error),
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleCreateTables} disabled={isLoading} variant="outline">
      <Database className="mr-2 h-4 w-4" />
      {isLoading ? "Criando tabelas..." : "Criar Tabelas"}
    </Button>
  )
}

