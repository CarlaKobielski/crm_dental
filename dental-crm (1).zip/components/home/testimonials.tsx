import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Star } from "lucide-react"

export function Testimonials() {
  const testimonials = [
    {
      name: "Dra. Ana Silva",
      role: "Ortodontista",
      image: "/placeholder.svg?height=100&width=100",
      content:
        "O Dental CRM transformou completamente a gestão da minha clínica. Consigo acompanhar todos os pacientes, agendamentos e financeiro em um só lugar. Recomendo a todos os colegas!",
      stars: 5,
    },
    {
      name: "Dr. Carlos Oliveira",
      role: "Implantodontista",
      image: "/placeholder.svg?height=100&width=100",
      content:
        "Desde que implementamos o Dental CRM, reduzimos em 40% o tempo gasto com tarefas administrativas. A equipe está mais produtiva e os pacientes mais satisfeitos com o atendimento.",
      stars: 5,
    },
    {
      name: "Dra. Mariana Costa",
      role: "Clínica Geral",
      image: "/placeholder.svg?height=100&width=100",
      content:
        "O sistema é muito intuitivo e fácil de usar. Minha equipe se adaptou rapidamente e agora temos todos os processos muito mais organizados. O suporte é excelente!",
      stars: 4,
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {testimonials.map((testimonial, index) => (
        <Card key={index} className="bg-white">
          <CardContent className="pt-6">
            <div className="flex mb-4">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-5 w-5 ${i < testimonial.stars ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                />
              ))}
            </div>
            <p className="text-gray-700 italic mb-6">"{testimonial.content}"</p>
          </CardContent>
          <CardFooter className="border-t pt-6 flex items-center">
            <img
              src={testimonial.image || "/placeholder.svg"}
              alt={testimonial.name}
              className="h-12 w-12 rounded-full mr-4"
            />
            <div>
              <h4 className="font-semibold">{testimonial.name}</h4>
              <p className="text-sm text-gray-500">{testimonial.role}</p>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

