import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function FAQ() {
  const faqs = [
    {
      question: "O que é o Dental CRM?",
      answer:
        "O Dental CRM é um sistema completo de gestão para clínicas odontológicas. Ele integra agendamento, prontuário eletrônico, gestão de pacientes, financeiro e muito mais em uma única plataforma fácil de usar.",
    },
    {
      question: "Preciso instalar algum software?",
      answer:
        "Não, o Dental CRM é uma solução 100% baseada em nuvem (SaaS). Você pode acessar de qualquer dispositivo com conexão à internet, sem necessidade de instalação ou manutenção de servidores.",
    },
    {
      question: "Como funciona o período de teste gratuito?",
      answer:
        "Oferecemos 14 dias de teste gratuito com acesso a todas as funcionalidades do plano Profissional. Não é necessário cartão de crédito para começar. Ao final do período, você pode escolher o plano que melhor atende às suas necessidades.",
    },
    {
      question: "Posso cancelar minha assinatura a qualquer momento?",
      answer:
        "Sim, você pode cancelar sua assinatura a qualquer momento sem taxas ou multas. Seus dados ficarão disponíveis até o final do período já pago.",
    },
    {
      question: "O sistema é seguro? Como ficam meus dados?",
      answer:
        "Sim, o Dental CRM utiliza criptografia de ponta a ponta e segue todas as normas da LGPD. Seus dados são armazenados em servidores seguros com backup diário e você sempre terá total controle sobre eles.",
    },
    {
      question: "Posso migrar meus dados de outro sistema?",
      answer:
        "Sim, oferecemos serviço de migração de dados para clientes dos planos Profissional e Empresarial. Nossa equipe irá auxiliar em todo o processo para garantir uma transição tranquila.",
    },
    {
      question: "O sistema funciona em tablets e celulares?",
      answer:
        "Sim, o Dental CRM é totalmente responsivo e funciona em qualquer dispositivo com acesso à internet, incluindo computadores, tablets e smartphones.",
    },
    {
      question: "Quantos usuários posso cadastrar?",
      answer:
        "O número de usuários varia de acordo com o plano escolhido. O plano Básico permite até 3 usuários, o Profissional até 10 usuários, e o Empresarial oferece usuários ilimitados.",
    },
  ]

  return (
    <Accordion type="single" collapsible className="max-w-3xl mx-auto">
      {faqs.map((faq, index) => (
        <AccordionItem key={index} value={`item-${index}`}>
          <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
          <AccordionContent>{faq.answer}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  )
}

