import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Calendar, DollarSign, FileText, Shield, BarChart2, Bell, Settings } from "lucide-react"

export function Features() {
  const features = [
    {
      icon: <Users className="h-10 w-10 text-blue-600" />,
      title: "Gestão de Pacientes",
      description: "Cadastro completo de pacientes, histórico, documentos e prontuários eletrônicos.",
    },
    {
      icon: <Calendar className="h-10 w-10 text-blue-600" />,
      title: "Agendamento",
      description: "Agenda inteligente com visualização diária, semanal e mensal. Lembretes automáticos.",
    },
    {
      icon: <DollarSign className="h-10 w-10 text-blue-600" />,
      title: "Financeiro",
      description: "Controle financeiro completo, faturamento, recebimentos e relatórios gerenciais.",
    },
    {
      icon: <FileText className="h-10 w-10 text-blue-600" />,
      title: "Prontuário Eletrônico",
      description: "Prontuário digital completo, com histórico, odontograma e anexos de exames.",
    },
    {
      icon: <Shield className="h-10 w-10 text-blue-600" />,
      title: "Segurança",
      description: "Dados criptografados, backup automático e conformidade com LGPD e regulamentações.",
    },
    {
      icon: <BarChart2 className="h-10 w-10 text-blue-600" />,
      title: "Relatórios e Análises",
      description: "Dashboards e relatórios personalizados para acompanhar o desempenho da clínica.",
    },
    {
      icon: <Bell className="h-10 w-10 text-blue-600" />,
      title: "Lembretes e Notificações",
      description: "Sistema de lembretes automáticos para pacientes e equipe via e-mail e SMS.",
    },
    {
      icon: <Settings className="h-10 w-10 text-blue-600" />,
      title: "Personalização",
      description: "Adapte o sistema às necessidades da sua clínica com configurações flexíveis.",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {features.map((feature, index) => (
        <Card key={index} className="border-t-4 border-t-blue-500">
          <CardHeader className="pb-2">
            <div className="mb-4">{feature.icon}</div>
            <CardTitle>{feature.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription className="text-base">{feature.description}</CardDescription>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

