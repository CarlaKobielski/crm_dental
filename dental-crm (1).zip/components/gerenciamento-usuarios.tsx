"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { Pencil, Trash2, UserPlus } from "lucide-react"

interface Usuario {
  id: string
  email: string
  nome: string
  funcao: string
  ultimo_acesso?: string
  created_at: string
}

export function GerenciamentoUsuarios() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<Usuario | null>(null)

  // Formulário
  const [email, setEmail] = useState("")
  const [nome, setNome] = useState("")
  const [funcao, setFuncao] = useState("dentista")
  const [senha, setSenha] = useState("")
  const [confirmSenha, setConfirmSenha] = useState("")
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    fetchUsuarios()
  }, [])

  const fetchUsuarios = async () => {
    setIsLoading(true)
    try {
      // Em um ambiente real, você usaria a API de autenticação do Supabase
      // Aqui estamos simulando com uma tabela de usuários
      const { data, error } = await supabase.from("usuarios").select("*").order("created_at", { ascending: false })

      if (error) throw error

      setUsuarios(data || [])
    } catch (error) {
      console.error("Erro ao carregar usuários:", error)
      toast({
        title: "Erro ao carregar usuários",
        description: "Não foi possível carregar a lista de usuários.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleOpenDialog = (usuario?: Usuario) => {
    if (usuario) {
      setEditingUser(usuario)
      setEmail(usuario.email)
      setNome(usuario.nome)
      setFuncao(usuario.funcao)
      setSenha("")
      setConfirmSenha("")
    } else {
      setEditingUser(null)
      setEmail("")
      setNome("")
      setFuncao("dentista")
      setSenha("")
      setConfirmSenha("")
    }
    setDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setDialogOpen(false)
    setEditingUser(null)
  }

  const validateForm = () => {
    if (!email || !nome || !funcao) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return false
    }

    if (!editingUser && (!senha || senha.length < 6)) {
      toast({
        title: "Senha inválida",
        description: "A senha deve ter pelo menos 6 caracteres.",
        variant: "destructive",
      })
      return false
    }

    if (!editingUser && senha !== confirmSenha) {
      toast({
        title: "Senhas não conferem",
        description: "As senhas digitadas não são iguais.",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const handleSaveUser = async () => {
    if (!validateForm()) return

    setIsSaving(true)
    try {
      if (editingUser) {
        // Atualizar usuário existente
        const { error } = await supabase
          .from("usuarios")
          .update({
            nome,
            email,
            funcao,
            // Em um ambiente real, você trataria a senha separadamente
            // e usaria hash para armazenar
          })
          .eq("id", editingUser.id)

        if (error) throw error

        toast({
          title: "Usuário atualizado",
          description: "As informações do usuário foram atualizadas com sucesso.",
        })
      } else {
        // Criar novo usuário
        // Em um ambiente real, você usaria a API de autenticação do Supabase
        const { error } = await supabase.from("usuarios").insert({
          id: crypto.randomUUID(),
          nome,
          email,
          funcao,
          created_at: new Date().toISOString(),
          // Em um ambiente real, você trataria a senha separadamente
          // e usaria hash para armazenar
        })

        if (error) throw error

        toast({
          title: "Usuário criado",
          description: "O novo usuário foi criado com sucesso.",
        })
      }

      // Recarregar a lista de usuários
      fetchUsuarios()
      handleCloseDialog()
    } catch (error) {
      console.error("Erro ao salvar usuário:", error)
      toast({
        title: "Erro ao salvar usuário",
        description: "Não foi possível salvar as informações do usuário.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteUser = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.")) {
      return
    }

    try {
      const { error } = await supabase.from("usuarios").delete().eq("id", id)

      if (error) throw error

      toast({
        title: "Usuário excluído",
        description: "O usuário foi excluído com sucesso.",
      })

      // Atualizar a lista de usuários
      setUsuarios(usuarios.filter((user) => user.id !== id))
    } catch (error) {
      console.error("Erro ao excluir usuário:", error)
      toast({
        title: "Erro ao excluir usuário",
        description: "Não foi possível excluir o usuário.",
        variant: "destructive",
      })
    }
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return "Nunca"
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getFuncaoLabel = (funcao: string) => {
    switch (funcao) {
      case "admin":
        return "Administrador"
      case "dentista":
        return "Dentista"
      case "recepcionista":
        return "Recepcionista"
      case "assistente":
        return "Assistente"
      default:
        return funcao
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Usuários do Sistema</CardTitle>
            <CardDescription>Gerencie os usuários que têm acesso ao sistema.</CardDescription>
          </div>
          <Button onClick={() => handleOpenDialog()}>
            <UserPlus className="mr-2 h-4 w-4" />
            Novo Usuário
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Carregando usuários...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>E-mail</TableHead>
                  <TableHead>Função</TableHead>
                  <TableHead>Último Acesso</TableHead>
                  <TableHead>Criado em</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {usuarios.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-4">
                      Nenhum usuário encontrado.
                    </TableCell>
                  </TableRow>
                ) : (
                  usuarios.map((usuario) => (
                    <TableRow key={usuario.id}>
                      <TableCell className="font-medium">{usuario.nome}</TableCell>
                      <TableCell>{usuario.email}</TableCell>
                      <TableCell>{getFuncaoLabel(usuario.funcao)}</TableCell>
                      <TableCell>{formatDate(usuario.ultimo_acesso)}</TableCell>
                      <TableCell>{formatDate(usuario.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="icon" onClick={() => handleOpenDialog(usuario)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="text-red-500"
                            onClick={() => handleDeleteUser(usuario.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingUser ? "Editar Usuário" : "Novo Usuário"}</DialogTitle>
            <DialogDescription>
              {editingUser
                ? "Edite as informações do usuário existente."
                : "Preencha as informações para criar um novo usuário."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="nome" className="text-right">
                Nome
              </Label>
              <div className="col-span-3">
                <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Nome completo" />
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                E-mail
              </Label>
              <div className="col-span-3">
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@exemplo.com"
                />
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="funcao" className="text-right">
                Função
              </Label>
              <div className="col-span-3">
                <Select value={funcao} onValueChange={setFuncao}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma função" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrador</SelectItem>
                    <SelectItem value="dentista">Dentista</SelectItem>
                    <SelectItem value="recepcionista">Recepcionista</SelectItem>
                    <SelectItem value="assistente">Assistente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {!editingUser && (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="senha" className="text-right">
                    Senha
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="senha"
                      type="password"
                      value={senha}
                      onChange={(e) => setSenha(e.target.value)}
                      placeholder="Senha"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="confirmar-senha" className="text-right">
                    Confirmar Senha
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="confirmar-senha"
                      type="password"
                      value={confirmSenha}
                      onChange={(e) => setConfirmSenha(e.target.value)}
                      placeholder="Confirme a senha"
                    />
                  </div>
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              Cancelar
            </Button>
            <Button onClick={handleSaveUser} disabled={isSaving}>
              {isSaving ? "Salvando..." : editingUser ? "Salvar Alterações" : "Criar Usuário"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

