"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

export function DocumentosSearch() {
  const [searchTerm, setSearchTerm] = useState("")

  const handleSearch = () => {
    // Implementar a lógica de busca aqui
    console.log("Buscando por:", searchTerm)
    // Você pode usar o router para navegar para uma página de resultados
    // ou implementar uma busca no lado do cliente
  }

  return (
    <div className="flex gap-2">
      <div className="flex-1">
        <Input
          placeholder="Digite o nome do documento ou paciente"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
        />
      </div>
      <Button onClick={handleSearch}>
        <Search className="mr-2 h-4 w-4" /> Buscar
      </Button>
    </div>
  )
}

