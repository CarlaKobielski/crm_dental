"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/components/ui/use-toast"
import { STRIPE_PLANS, CICLO_DESCONTOS, calcularPrecoComDesconto, type CicloCobranca } from "@/lib/stripe"

interface UpgradePlanDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentPlan: string
  currentCiclo: CicloCobranca
}

export function UpgradePlanDialog({ open, onOpenChange, currentPlan, currentCiclo }: UpgradePlanDialogProps) {
  const [selectedPlan, setSelectedPlan] = useState<string>("")
  const [selectedCiclo, setSelectedCiclo] = useState<CicloCobranca>(currentCiclo)
  const [agendarMudanca, setAgendarMudanca] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Filtrar planos disponíveis (excluir o plano atual e o trial)
  const availablePlans = Object.entries(STRIPE_PLANS).filter(
    ([key, plan]) => plan.id.toLowerCase() !== currentPlan.toLowerCase() && plan.id !== "trial",
  )

  async function handleUpgrade() {
    if (!selectedPlan) {
      toast({
        title: "Erro",
        description: "Selecione um plano para continuar.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/assinaturas/upgrade", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          planoId: selectedPlan,
          ciclo: selectedCiclo,
          agendarMudanca,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao atualizar plano")
      }

      toast({
        title: "Sucesso",
        description: data.message || "Plano atualizado com sucesso.",
      })

      onOpenChange(false)

      // Recarregar a página após 1 segundo
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar plano",
        description: error.message || "Ocorreu um erro ao tentar atualizar o plano.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Encontrar o plano atual
  const currentPlanInfo = Object.values(STRIPE_PLANS).find(
    (plan) => plan.id.toLowerCase() === currentPlan.toLowerCase(),
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Alterar Plano</DialogTitle>
          <DialogDescription>
            Escolha o novo plano para sua clínica. Você pode alterar o ciclo de cobrança e optar por agendar a mudança
            para o próximo ciclo.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <div className="mb-6">
            <h3 className="text-sm font-medium mb-2">Plano Atual</h3>
            <div className="p-3 bg-gray-50 rounded-md">
              <p className="font-medium">{currentPlanInfo?.name || currentPlan}</p>
              <p className="text-sm text-gray-500">
                {currentCiclo === "mensal"
                  ? "Cobrança mensal"
                  : currentCiclo === "trimestral"
                    ? "Cobrança trimestral"
                    : "Cobrança anual"}
              </p>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-sm font-medium mb-2">Selecione o Novo Plano</h3>
            <RadioGroup value={selectedPlan} onValueChange={setSelectedPlan} className="space-y-3">
              {availablePlans.map(([key, plan]) => (
                <div
                  key={key}
                  className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-gray-50"
                >
                  <RadioGroupItem value={plan.id} id={`plan-${plan.id}`} />
                  <Label htmlFor={`plan-${plan.id}`} className="flex-1 cursor-pointer">
                    <div className="flex justify-between">
                      <div>
                        <div className="font-medium">{plan.name}</div>
                        <div className="text-sm text-gray-500">{plan.features[0]}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">
                          R$ {calcularPrecoComDesconto(plan.price, selectedCiclo).toFixed(2)}
                        </div>
                        <div className="text-xs text-gray-500">
                          {selectedCiclo === "mensal" ? "/mês" : selectedCiclo === "trimestral" ? "/trimestre" : "/ano"}
                        </div>
                      </div>
                    </div>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="mb-6">
            <h3 className="text-sm font-medium mb-2">Ciclo de Cobrança</h3>
            <RadioGroup
              value={selectedCiclo}
              onValueChange={(value) => setSelectedCiclo(value as CicloCobranca)}
              className="space-y-3"
            >
              <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-gray-50">
                <RadioGroupItem value="mensal" id="ciclo-mensal" />
                <Label htmlFor="ciclo-mensal" className="cursor-pointer">
                  <div className="font-medium">Mensal</div>
                  <div className="text-sm text-gray-500">Cobrança todo mês</div>
                </Label>
              </div>

              <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-gray-50 border-green-200 bg-green-50">
                <RadioGroupItem value="trimestral" id="ciclo-trimestral" />
                <Label htmlFor="ciclo-trimestral" className="cursor-pointer">
                  <div className="font-medium">Trimestral</div>
                  <div className="text-sm text-gray-500">
                    <span className="text-green-600 font-medium">{CICLO_DESCONTOS.trimestral}% de desconto</span> -
                    Cobrança a cada 3 meses
                  </div>
                </Label>
              </div>

              <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-gray-50 border-green-200 bg-green-50">
                <RadioGroupItem value="anual" id="ciclo-anual" />
                <Label htmlFor="ciclo-anual" className="cursor-pointer">
                  <div className="font-medium">Anual</div>
                  <div className="text-sm text-gray-500">
                    <span className="text-green-600 font-medium">{CICLO_DESCONTOS.anual}% de desconto</span> - Cobrança
                    anual
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="agendar-mudanca"
              checked={agendarMudanca}
              onCheckedChange={(checked) => setAgendarMudanca(checked === true)}
            />
            <Label htmlFor="agendar-mudanca" className="cursor-pointer">
              Agendar mudança para o próximo ciclo de cobrança
            </Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleUpgrade} disabled={!selectedPlan || isLoading}>
            {isLoading ? "Processando..." : "Confirmar Mudança"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

