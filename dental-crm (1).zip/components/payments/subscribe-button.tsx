"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { useRouter, useSearchParams } from "next/navigation"

interface SubscribeButtonProps {
  planId: string
  planName: string
  currentPlan?: string
  className?: string
}

export function SubscribeButton({ planId, planName, currentPlan, className }: SubscribeButtonProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const ciclo = searchParams.get("ciclo") || "mensal"

  // Verificar se o usuário já está no plano atual
  const isCurrentPlan = currentPlan === planId.toLowerCase()

  async function handleSubscribe() {
    setIsLoading(true)

    try {
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          planId,
          ciclo,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao processar pagamento")
      }

      // Redirecionar para a página de checkout do Stripe
      if (data.url) {
        window.location.href = data.url
      } else {
        throw new Error("URL de checkout não encontrada")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao assinar plano",
        description: error.message || "Ocorreu um erro ao tentar assinar o plano.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button
      onClick={handleSubscribe}
      disabled={isLoading || isCurrentPlan}
      className={className}
      variant={planName === "Trial" ? "outline" : "default"}
    >
      {isLoading
        ? "Processando..."
        : isCurrentPlan
          ? "Plano Atual"
          : planName === "Trial"
            ? "Começar Teste Grátis"
            : "Assinar Plano"}
    </Button>
  )
}

