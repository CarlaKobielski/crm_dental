"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { AlertCircle } from "lucide-react"

interface ReactivateSubscriptionButtonProps {
  dataFimCarencia: string
  className?: string
}

export function ReactivateSubscriptionButton({ dataFimCarencia, className }: ReactivateSubscriptionButtonProps) {
  const [isLoading, setIsLoading] = useState(false)

  // Formatar a data de fim de carência
  const dataFormatada = new Date(dataFimCarencia).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })

  async function handleReactivate() {
    setIsLoading(true)

    try {
      const response = await fetch("/api/assinaturas/reativar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao reativar assinatura")
      }

      toast({
        title: "Assinatura reativada",
        description: data.message || "Sua assinatura foi reativada com sucesso.",
      })

      // Recarregar a página após 1 segundo
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    } catch (error: any) {
      toast({
        title: "Erro ao reativar assinatura",
        description: error.message || "Ocorreu um erro ao tentar reativar a assinatura.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className={`space-y-3 ${className}`}>
      <div className="flex items-start gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-md">
        <AlertCircle className="h-5 w-5 text-yellow-600 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm text-yellow-800">
            Sua assinatura está em período de carência e será cancelada em <strong>{dataFormatada}</strong>.
          </p>
          <p className="text-xs text-yellow-700 mt-1">
            Você pode reativar sua assinatura até esta data para manter seu plano atual.
          </p>
        </div>
      </div>

      <Button onClick={handleReactivate} disabled={isLoading} className="w-full">
        {isLoading ? "Processando..." : "Reativar Assinatura"}
      </Button>
    </div>
  )
}

