"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CICLO_DESCONTOS } from "@/lib/stripe"

interface CicloSelectorProps {
  className?: string
}

export function CicloSelector({ className }: CicloSelectorProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [ciclo, setCiclo] = useState<string>(searchParams.get("ciclo") || "mensal")

  // Efeito para atualizar a URL quando o ciclo muda
  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString())
    params.set("ciclo", ciclo)
    router.push(`?${params.toString()}`, { scroll: false })
  }, [ciclo, router, searchParams])

  return (
    <div className={className}>
      <div className="flex flex-col items-center justify-center">
        <h2 className="text-lg font-medium mb-4">Escolha o ciclo de cobrança</h2>
        <RadioGroup value={ciclo} onValueChange={setCiclo} className="flex flex-wrap justify-center gap-4 md:gap-8">
          <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
            <RadioGroupItem value="mensal" id="mensal" />
            <Label htmlFor="mensal" className="cursor-pointer">
              <div className="font-medium">Mensal</div>
              <div className="text-sm text-gray-500">Cobrança todo mês</div>
            </Label>
          </div>

          <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:bg-gray-50 border-green-200 bg-green-50">
            <RadioGroupItem value="trimestral" id="trimestral" />
            <Label htmlFor="trimestral" className="cursor-pointer">
              <div className="font-medium">Trimestral</div>
              <div className="text-sm text-gray-500">
                <span className="text-green-600 font-medium">{CICLO_DESCONTOS.trimestral}% de desconto</span> - Cobrança
                a cada 3 meses
              </div>
            </Label>
          </div>

          <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:bg-gray-50 border-green-200 bg-green-50">
            <RadioGroupItem value="anual" id="anual" />
            <Label htmlFor="anual" className="cursor-pointer">
              <div className="font-medium">Anual</div>
              <div className="text-sm text-gray-500">
                <span className="text-green-600 font-medium">{CICLO_DESCONTOS.anual}% de desconto</span> - Cobrança
                anual
              </div>
            </Label>
          </div>
        </RadioGroup>
      </div>
    </div>
  )
}

