"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"

interface CancelSubscriptionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CancelSubscriptionDialog({ open, onOpenChange }: CancelSubscriptionDialogProps) {
  const [comCarencia, setComCarencia] = useState(true)
  const [diasCarencia, setDiasCarencia] = useState(7)
  const [isLoading, setIsLoading] = useState(false)

  async function handleCancel() {
    setIsLoading(true)

    try {
      const response = await fetch("/api/assinaturas/cancelar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          comCarencia,
          diasCarencia: comCarencia ? diasCarencia : 0,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao cancelar assinatura")
      }

      toast({
        title: "Assinatura cancelada",
        description: data.message || "Sua assinatura foi cancelada com sucesso.",
      })

      onOpenChange(false)

      // Recarregar a página após 1 segundo
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    } catch (error: any) {
      toast({
        title: "Erro ao cancelar assinatura",
        description: error.message || "Ocorreu um erro ao tentar cancelar a assinatura.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Cancelar Assinatura</DialogTitle>
          <DialogDescription>
            Tem certeza que deseja cancelar sua assinatura? Você perderá acesso a recursos premium.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-4">
          <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
            <p className="text-sm text-yellow-800">
              Ao cancelar sua assinatura, você ainda terá acesso ao sistema até o final do período pago. Após esse
              período, sua conta será rebaixada para o plano gratuito com recursos limitados.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="periodo-carencia"
              checked={comCarencia}
              onCheckedChange={(checked) => setComCarencia(checked === true)}
            />
            <Label htmlFor="periodo-carencia" className="cursor-pointer">
              Ativar período de carência (você poderá reativar sua assinatura durante este período)
            </Label>
          </div>

          {comCarencia && (
            <div className="pl-6">
              <Label htmlFor="dias-carencia" className="block mb-2 text-sm">
                Dias de carência
              </Label>
              <Input
                id="dias-carencia"
                type="number"
                min={1}
                max={30}
                value={diasCarencia}
                onChange={(e) => setDiasCarencia(Number.parseInt(e.target.value) || 7)}
                className="w-24"
              />
              <p className="text-xs text-gray-500 mt-1">
                Durante este período, você poderá reativar sua assinatura sem perder seus dados.
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            Voltar
          </Button>
          <Button variant="destructive" onClick={handleCancel} disabled={isLoading}>
            {isLoading ? "Processando..." : "Confirmar Cancelamento"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

