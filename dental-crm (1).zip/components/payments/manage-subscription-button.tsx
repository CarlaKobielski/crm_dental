"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

interface ManageSubscriptionButtonProps {
  hasSubscription: boolean
  customerId?: string
  className?: string
}

export function ManageSubscriptionButton({ hasSubscription, customerId, className }: ManageSubscriptionButtonProps) {
  const [isLoading, setIsLoading] = useState(false)

  async function handleManageSubscription() {
    if (!customerId) {
      toast({
        title: "Erro",
        description: "ID do cliente não encontrado.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/stripe/portal", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao acessar portal de faturamento")
      }

      // Redirecionar para o portal de faturamento do Stripe
      if (data.url) {
        window.location.href = data.url
      } else {
        throw new Error("URL do portal não encontrada")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao acessar portal",
        description: error.message || "Ocorreu um erro ao tentar acessar o portal de faturamento.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button
      onClick={handleManageSubscription}
      disabled={isLoading || !customerId}
      variant="outline"
      className={className}
    >
      {isLoading ? "Carregando..." : hasSubscription ? "Gerenciar Assinatura" : "Assinar Plano"}
    </Button>
  )
}

