import { render, screen } from "@testing-library/react"
import { Sidebar } from "@/components/sidebar"

// Mock usePathname
jest.mock("next/navigation", () => ({
  usePathname: () => "/dashboard",
}))

describe("Sidebar", () => {
  it("renderiza corretamente", () => {
    render(<Sidebar />)

    // Verifica se o título está presente
    expect(screen.getByText("Dental CRM")).toBeInTheDocument()

    // Verifica se as seções estão presentes
    expect(screen.getByText("ATENDIMENTO")).toBeInTheDocument()
    expect(screen.getByText("GESTÃO ODONTOLÓGICA")).toBeInTheDocument()
    expect(screen.getByText("MARKETING E ANÁLISE")).toBeInTheDocument()
    expect(screen.getByText("COMUNICAÇÃO E AUTOMAÇÃO")).toBeInTheDocument()

    // Verifica se os itens do menu estão presentes
    expect(screen.getByText("Dashboard")).toBeInTheDocument()
    expect(screen.getByText("Pacientes")).toBeInTheDocument()
    expect(screen.getByText("Consultas")).toBeInTheDocument()
    expect(screen.getByText("Tratamentos")).toBeInTheDocument()
    expect(screen.getByText("Prontuário Eletrônico")).toBeInTheDocument()
    expect(screen.getByText("Financeiro")).toBeInTheDocument()
    expect(screen.getByText("Marketing")).toBeInTheDocument()
    expect(screen.getByText("Relatórios")).toBeInTheDocument()
    expect(screen.getByText("Documentos")).toBeInTheDocument()
    expect(screen.getByText("Lembretes")).toBeInTheDocument()
    expect(screen.getByText("Integrações")).toBeInTheDocument()
    expect(screen.getByText("Configurações")).toBeInTheDocument()
  })
})

