describe("Testes de Responsividade", () => {
  const sizes = [
    [375, 667], // iPhone SE
    [390, 844], // iPhone 12/13
    [414, 896], // iPhone XR
    [768, 1024], // iPad
    [1280, 800], // Laptop
    [1920, 1080], // Desktop
  ]

  const pages = [
    "/",
    "/dashboard",
    "/pacientes",
    "/consultas",
    "/tratamentos",
    "/financeiro",
    "/documentos",
    "/notificacoes",
    "/configuracoes",
  ]

  sizes.forEach((size) => {
    const [width, height] = size

    context(`Dispositivo ${width}x${height}`, () => {
      beforeEach(() => {
        cy.viewport(width, height)
      })

      pages.forEach((page) => {
        it(`Deve renderizar corretamente a página ${page}`, () => {
          cy.visit(page)
          cy.wait(1000) // Aguardar carregamento
          cy.screenshot(`${page.replace("/", "")}-${width}x${height}`)

          // Verificar elementos principais
          if (page === "/") {
            cy.get("h1").should("be.visible")
          } else {
            // Verificar se o menu lateral está visível em telas grandes ou o botão de menu em telas pequenas
            if (width >= 768) {
              cy.get("nav").should("be.visible")
            } else {
              cy.get('button[aria-label="Menu"]').should("exist")
            }
          }
        })
      })
    })
  })
})

