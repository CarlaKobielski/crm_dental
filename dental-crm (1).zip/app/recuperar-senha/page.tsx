import { RecuperarSenhaForm } from "@/components/auth/recuperar-senha-form"
import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function RecuperarSenhaPage() {
  const session = await getSession()

  // Redirecionar para o dashboard se já estiver autenticado
  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">Recuperar senha</h2>
        <p className="mt-2 text-center text-sm text-gray-600">Enviaremos um link para redefinir sua senha</p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <RecuperarSenhaForm />
        </div>
      </div>
    </div>
  )
}

