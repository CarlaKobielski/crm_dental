import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BackupButton } from "@/components/backup-button"
import { RestoreButton } from "@/components/restore-button"
import { CreateTablesButton } from "@/components/create-tables-button"
import { InitializeStorageButton } from "@/components/initialize-storage"
import { ConfiguracoesSistema } from "@/components/configuracoes-sistema"
import { GerenciamentoUsuarios } from "@/components/gerenciamento-usuarios"

export default function ConfiguracoesPage() {
  return (
    <div>
      <div className="flex justify-between items-center p-6 border-b bg-white">
        <h1 className="text-2xl font-bold">Configurações do Sistema</h1>
      </div>

      <div className="p-6">
        <Tabs defaultValue="backup">
          <TabsList className="mb-4">
            <TabsTrigger value="backup">Backup e Restauração</TabsTrigger>
            <TabsTrigger value="database">Banco de Dados</TabsTrigger>
            <TabsTrigger value="storage">Armazenamento</TabsTrigger>
            <TabsTrigger value="sistema">Sistema</TabsTrigger>
            <TabsTrigger value="usuarios">Usuários</TabsTrigger>
          </TabsList>

          <TabsContent value="backup">
            <Card>
              <CardHeader>
                <CardTitle>Backup e Restauração</CardTitle>
                <CardDescription>
                  Faça backup dos dados do sistema ou restaure a partir de um backup anterior.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Backup</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Faça um backup completo de todos os dados do sistema. O arquivo gerado pode ser usado para
                      restaurar o sistema em caso de problemas.
                    </p>
                    <BackupButton />
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="text-lg font-medium mb-2">Restauração</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Restaure o sistema a partir de um arquivo de backup. Atenção: esta ação substituirá todos os dados
                      atuais!
                    </p>
                    <RestoreButton />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="database">
            <Card>
              <CardHeader>
                <CardTitle>Banco de Dados</CardTitle>
                <CardDescription>Gerencie a estrutura do banco de dados.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Estrutura do Banco</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Crie ou atualize as tabelas necessárias para o funcionamento do sistema.
                    </p>
                    <CreateTablesButton />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="storage">
            <Card>
              <CardHeader>
                <CardTitle>Armazenamento</CardTitle>
                <CardDescription>Gerencie o armazenamento de arquivos do sistema.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Inicialização do Armazenamento</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Inicialize os buckets de armazenamento necessários para o funcionamento do sistema.
                    </p>
                    <InitializeStorageButton />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sistema">
            <ConfiguracoesSistema />
          </TabsContent>

          <TabsContent value="usuarios">
            <GerenciamentoUsuarios />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

