import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase"
import { ManageSubscriptionButton } from "@/components/payments/manage-subscription-button"
import { UpgradePlanDialog } from "@/components/payments/upgrade-plan-dialog"
import { CancelSubscriptionDialog } from "@/components/payments/cancel-subscription-dialog"
import { ReactivateSubscriptionButton } from "@/components/payments/reactivate-subscription-button"
import { STRIPE_PLANS, type CicloCobranca } from "@/lib/stripe"

export default async function AssinaturaPage() {
  const session = await getSession()

  // Redirecionar para login se não estiver autenticado
  if (!session) {
    redirect("/login")
  }

  // Obter perfil do usuário com dados da clínica
  const supabase = createServerClient()
  const { data: profile, error } = await supabase
    .from("perfis_usuario")
    .select(`
      *,
      clinicas (
        *
      )
    `)
    .eq("id", session.user.id)
    .single()

  if (error || !profile) {
    redirect("/dashboard")
  }

  const clinica = profile.clinicas

  // Formatar data de expiração
  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A"
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  // Mapear status para texto amigável
  const getStatusText = (status?: string) => {
    switch (status) {
      case "ativo":
        return "Ativo"
      case "inativo":
        return "Inativo"
      case "cancelado":
        return "Cancelado"
      case "cancelado_pendente":
        return "Cancelamento Pendente"
      case "trial":
        return "Período de Teste"
      default:
        return "Desconhecido"
    }
  }

  // Mapear plano para texto amigável
  const getPlanText = (plan?: string) => {
    const planKey = Object.keys(STRIPE_PLANS).find(
      (key) => STRIPE_PLANS[key].id.toLowerCase() === (plan || "").toLowerCase(),
    )

    return planKey ? STRIPE_PLANS[planKey].name : "Desconhecido"
  }

  // Mapear ciclo para texto amigável
  const getCicloText = (ciclo?: string) => {
    switch (ciclo) {
      case "mensal":
        return "Mensal"
      case "trimestral":
        return "Trimestral"
      case "anual":
        return "Anual"
      default:
        return "Mensal"
    }
  }

  // Verificar se a assinatura está em período de carência
  const emCarencia = clinica?.periodo_carencia && clinica?.data_fim_carencia

  // Verificar se há um upgrade agendado
  const upgradeAgendado = clinica?.upgrade_agendado && clinica?.plano_agendado

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Gerenciar Assinatura</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Detalhes da Assinatura</CardTitle>
            <CardDescription>Informações sobre sua assinatura atual</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="space-y-4">
              <div>
                <dt className="text-sm font-medium text-gray-500">Plano</dt>
                <dd className="mt-1 text-lg font-semibold">{getPlanText(clinica?.plano)}</dd>
              </div>

              {upgradeAgendado && (
                <div>
                  <dt className="text-sm font-medium text-gray-500">Upgrade Agendado</dt>
                  <dd className="mt-1">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {getPlanText(clinica?.plano_agendado)} (próximo ciclo)
                    </span>
                  </dd>
                </div>
              )}

              <div>
                <dt className="text-sm font-medium text-gray-500">Ciclo de Cobrança</dt>
                <dd className="mt-1">{getCicloText(clinica?.ciclo_cobranca)}</dd>
              </div>

              <div>
                <dt className="text-sm font-medium text-gray-500">Status</dt>
                <dd className="mt-1">
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      clinica?.status === "ativo"
                        ? "bg-green-100 text-green-800"
                        : clinica?.status === "inativo"
                          ? "bg-yellow-100 text-yellow-800"
                          : clinica?.status === "cancelado_pendente"
                            ? "bg-orange-100 text-orange-800"
                            : "bg-red-100 text-red-800"
                    }`}
                  >
                    {getStatusText(clinica?.status)}
                  </span>
                </dd>
              </div>

              {clinica?.data_proximo_ciclo && (
                <div>
                  <dt className="text-sm font-medium text-gray-500">Próximo Ciclo de Cobrança</dt>
                  <dd className="mt-1">{formatDate(clinica.data_proximo_ciclo)}</dd>
                </div>
              )}

              {clinica?.data_expiracao && clinica?.status === "cancelado_pendente" && (
                <div>
                  <dt className="text-sm font-medium text-gray-500">Acesso Disponível Até</dt>
                  <dd className="mt-1">{formatDate(clinica.data_expiracao)}</dd>
                </div>
              )}
            </dl>

            {emCarencia ? (
              <div className="mt-6">
                <ReactivateSubscriptionButton dataFimCarencia={clinica.data_fim_carencia} />
              </div>
            ) : (
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <ManageSubscriptionButton
                  hasSubscription={!!clinica?.stripe_subscription_id}
                  customerId={clinica?.stripe_customer_id}
                  className="flex-1"
                />

                <div className="flex gap-2 flex-1">
                  <UpgradePlanClientWrapper
                    currentPlan={clinica?.plano || "trial"}
                    currentCiclo={(clinica?.ciclo_cobranca || "mensal") as CicloCobranca}
                  />

                  <CancelSubscriptionClientWrapper />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Histórico de Pagamentos</CardTitle>
            <CardDescription>Visualize e baixe suas faturas</CardDescription>
          </CardHeader>
          <CardContent>
            {clinica?.stripe_customer_id ? (
              <div>
                <p className="text-sm text-gray-500 mb-4">
                  Para visualizar seu histórico completo de pagamentos e faturas, acesse o portal de gerenciamento de
                  assinatura.
                </p>

                <HistoricoAssinaturasClientWrapper clinicaId={clinica.id} />
              </div>
            ) : (
              <p className="text-sm text-gray-500">Você ainda não possui histórico de pagamentos.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-10">
        <h2 className="text-xl font-bold mb-4">Alterar Plano</h2>
        <p className="mb-4">Para alterar seu plano atual, visite nossa página de planos e escolha a opção desejada.</p>
        <Button asChild>
          <a href="/planos">Ver Planos Disponíveis</a>
        </Button>
      </div>
    </div>
  )
}
// Wrappers para componentes client
;("use client")

import { useState } from "react"

function UpgradePlanClientWrapper({ currentPlan, currentCiclo }) {
  const [open, setOpen] = useState(false)

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} className="flex-1">
        Alterar Plano
      </Button>
      <UpgradePlanDialog open={open} onOpenChange={setOpen} currentPlan={currentPlan} currentCiclo={currentCiclo} />
    </>
  )
}

function CancelSubscriptionClientWrapper() {
  const [open, setOpen] = useState(false)

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} className="flex-1">
        Cancelar
      </Button>
      <CancelSubscriptionDialog open={open} onOpenChange={setOpen} />
    </>
  )
}

function HistoricoAssinaturasClientWrapper({ clinicaId }) {
  const [historico, setHistorico] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  // Carregar histórico de assinaturas
  useState(() => {
    async function loadHistorico() {
      try {
        const response = await fetch(`/api/assinaturas/historico?clinicaId=${clinicaId}`)
        const data = await response.json()

        if (response.ok) {
          setHistorico(data)
        }
      } catch (error) {
        console.error("Erro ao carregar histórico:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadHistorico()
  }, [clinicaId])

  const getPlanText = (plan?: string) => {
    const planKey = Object.keys(STRIPE_PLANS).find(
      (key) => STRIPE_PLANS[key].id.toLowerCase() === (plan || "").toLowerCase(),
    )

    return planKey ? STRIPE_PLANS[planKey].name : "Desconhecido"
  }

  const getCicloText = (ciclo?: string) => {
    switch (ciclo) {
      case "mensal":
        return "Mensal"
      case "trimestral":
        return "Trimestral"
      case "anual":
        return "Anual"
      default:
        return "Mensal"
    }
  }

  if (isLoading) {
    return <p className="text-sm text-gray-500">Carregando histórico...</p>
  }

  if (historico.length === 0) {
    return <p className="text-sm text-gray-500">Nenhum registro encontrado.</p>
  }

  return (
    <div className="space-y-4">
      {historico.map((item) => (
        <div key={item.id} className="border rounded-md p-3">
          <div className="flex justify-between">
            <div>
              <p className="font-medium">{getPlanText(item.plano)}</p>
              <p className="text-sm text-gray-500">
                {new Date(item.data_inicio).toLocaleDateString("pt-BR")} -
                {item.data_fim ? new Date(item.data_fim).toLocaleDateString("pt-BR") : "Atual"}
              </p>
            </div>
            <div className="text-right">
              <p className="font-medium">R$ {item.valor_pago.toFixed(2)}</p>
              <p className="text-xs text-gray-500">{getCicloText(item.ciclo_cobranca)}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

