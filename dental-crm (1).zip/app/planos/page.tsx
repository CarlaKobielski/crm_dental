import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import { STRIPE_PLANS, CICLO_DESCONTOS } from "@/lib/stripe"
import { getSession, getCurrentUserProfile } from "@/lib/auth"
import { redirect } from "next/navigation"
import { SubscribeButton } from "@/components/payments/subscribe-button"
import { CicloSelector } from "@/components/payments/ciclo-selector"
import { createServerClient } from "@/lib/supabase"

export default async function PlanosPage() {
  const session = await getSession()

  // Redirecionar para login se não estiver autenticado
  if (!session) {
    redirect("/login")
  }

  const profile = await getCurrentUserProfile()

  // Obter descontos personalizados do banco de dados
  const supabase = createServerClient()
  const { data: descontos } = await supabase.from("descontos_ciclos").select("*")

  // Criar um mapa de descontos
  const descontosMap = {}
  if (descontos) {
    descontos.forEach((d) => {
      descontosMap[d.ciclo] = d.percentual_desconto
    })
  }

  return (
    <div className="container py-10">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold">Escolha o plano ideal para sua clínica</h1>
        <p className="text-gray-500 mt-2">Todos os planos incluem acesso a todas as funcionalidades principais</p>
      </div>

      <CicloSelector className="mb-8" />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Object.entries(STRIPE_PLANS).map(([key, plan]) => (
          <Card key={key} className={`flex flex-col ${key === "PROFESSIONAL" ? "border-blue-500 shadow-lg" : ""}`}>
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{key === "TRIAL" ? "Gratuito por 14 dias" : "Cobrança flexível"}</CardDescription>
              <div className="mt-4">
                <span className="text-3xl font-bold">
                  {plan.price === 0 ? "Grátis" : `R$ ${plan.price.toFixed(2)}`}
                </span>
                {plan.price > 0 && <span className="text-sm text-gray-500">/mês</span>}
              </div>
              {plan.price > 0 && (
                <div className="mt-1 space-y-1">
                  <p className="text-sm text-green-600">
                    Trimestral: {descontosMap["trimestral"] || CICLO_DESCONTOS.trimestral}% de desconto
                  </p>
                  <p className="text-sm text-green-600">
                    Anual: {descontosMap["anual"] || CICLO_DESCONTOS.anual}% de desconto
                  </p>
                </div>
              )}
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <SubscribeButton
                planId={plan.id}
                planName={plan.name}
                currentPlan={profile?.clinicas?.plano}
                className="w-full"
              />
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-10 text-center">
        <p className="text-sm text-gray-500">
          Todos os planos incluem 14 dias de teste grátis. Cancele a qualquer momento.
        </p>
      </div>
    </div>
  )
}

