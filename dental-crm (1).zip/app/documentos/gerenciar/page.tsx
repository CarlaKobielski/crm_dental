"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileUpload } from "@/components/file-upload"
import { FileList } from "@/components/file-list"
import { STORAGE_BUCKETS, initializeBuckets } from "@/lib/storage"
import { supabase } from "@/lib/supabase"
import { toast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { checkStorageAvailability } from "@/lib/check-storage"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function GerenciarDocumentosPage() {
  const [activeTab, setActiveTab] = useState("documentos")
  const [refreshKey, setRefreshKey] = useState(0)
  const [storageAvailable, setStorageAvailable] = useState(true)
  const [storageError, setStorageError] = useState<string | null>(null)
  const [isInitializing, setIsInitializing] = useState(true)

  useEffect(() => {
    const checkStorage = async () => {
      try {
        setIsInitializing(true)
        const isAvailable = await checkStorageAvailability()
        setStorageAvailable(isAvailable)

        if (!isAvailable) {
          setStorageError("O serviço de armazenamento não está disponível no momento.")
          toast({
            title: "Armazenamento não disponível",
            description: "O serviço de armazenamento não está disponível. Verifique sua configuração do Supabase.",
            variant: "destructive",
          })
          return
        }

        // Se o Storage estiver disponível, inicializar os buckets
        console.log("Inicializando buckets de armazenamento...")
        await initializeBuckets()
        console.log("Verificação de buckets concluída")
      } catch (error) {
        console.error("Erro ao verificar/inicializar armazenamento:", error)
        setStorageAvailable(false)
        setStorageError(
          "Erro ao acessar o serviço de armazenamento: " + (error instanceof Error ? error.message : String(error)),
        )
        toast({
          title: "Erro no serviço de armazenamento",
          description: "Não foi possível acessar o serviço de armazenamento. Verifique sua configuração do Supabase.",
          variant: "destructive",
        })
      } finally {
        setIsInitializing(false)
      }
    }

    checkStorage()
  }, [])

  async function handleUploadComplete(fileData: any) {
    try {
      // Salvar referência ao arquivo no banco de dados
      const { error } = await supabase.from("documentos").insert({
        nome: fileData.name,
        tipo: activeTab,
        url: fileData.url,
        paciente_id: null, // Você pode adicionar um seletor de paciente na interface
        created_at: new Date().toISOString(),
      })

      if (error) throw error

      // Forçar atualização da lista
      setRefreshKey((prev) => prev + 1)
    } catch (error) {
      console.error("Erro ao salvar referência do documento:", error)
      toast({
        title: "Erro ao salvar documento",
        description: "O arquivo foi enviado, mas não foi possível salvar a referência no banco de dados",
        variant: "destructive",
      })
    }
  }

  function getBucketForTab(tab: string) {
    switch (tab) {
      case "documentos":
        return STORAGE_BUCKETS.DOCUMENTOS
      case "imagens":
        return STORAGE_BUCKETS.IMAGENS
      case "prontuarios":
        return STORAGE_BUCKETS.PRONTUARIOS
      case "radiografias":
        return STORAGE_BUCKETS.RADIOGRAFIAS
      default:
        return STORAGE_BUCKETS.DOCUMENTOS
    }
  }

  function getAllowedTypesForTab(tab: string) {
    switch (tab) {
      case "documentos":
        return [
          "application/pdf",
          "application/msword",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ]
      case "imagens":
        return ["image/jpeg", "image/png", "image/gif", "image/webp"]
      case "prontuarios":
        return ["application/pdf"]
      case "radiografias":
        return ["image/jpeg", "image/png", "image/dicom"]
      default:
        return []
    }
  }

  if (isInitializing) {
    return (
      <div>
        <div className="flex justify-between items-center p-6 border-b bg-white">
          <h1 className="text-2xl font-bold">Gerenciar Documentos</h1>
        </div>
        <div className="p-6">
          <Card>
            <CardContent className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4 text-gray-500">Verificando serviço de armazenamento...</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (!storageAvailable) {
    return (
      <div>
        <div className="flex justify-between items-center p-6 border-b bg-white">
          <h1 className="text-2xl font-bold">Gerenciar Documentos</h1>
        </div>
        <div className="p-6">
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Serviço de Armazenamento Indisponível</AlertTitle>
            <AlertDescription>
              {storageError || "O serviço de armazenamento não está disponível no momento."}
            </AlertDescription>
          </Alert>

          <Card>
            <CardHeader>
              <CardTitle>Resolução de Problemas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>Isso pode ocorrer pelos seguintes motivos:</p>
                <ul className="list-disc ml-6 space-y-2">
                  <li>O Storage não está habilitado no seu projeto Supabase</li>
                  <li>As políticas de RLS não estão configuradas corretamente</li>
                  <li>Você não tem permissões para criar buckets</li>
                  <li>Há um problema temporário com o serviço Supabase</li>
                </ul>

                <div className="bg-blue-50 p-4 rounded-md border border-blue-200 mt-4">
                  <p className="text-blue-800 font-medium">Solução:</p>
                  <ol className="list-decimal ml-6 mt-2 space-y-2 text-blue-700">
                    <li>Acesse o painel de administração do Supabase</li>
                    <li>Navegue até a seção "Storage"</li>
                    <li>Verifique se o Storage está habilitado</li>
                    <li>Crie manualmente os buckets necessários: documentos, imagens, prontuarios, radiografias</li>
                    <li>Configure as políticas RLS para permitir acesso aos buckets</li>
                  </ol>
                </div>

                <Button onClick={() => window.location.reload()} className="mt-4">
                  Tentar Novamente
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex justify-between items-center p-6 border-b bg-white">
        <h1 className="text-2xl font-bold">Gerenciar Documentos</h1>
      </div>

      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="documentos">Documentos</TabsTrigger>
            <TabsTrigger value="imagens">Imagens</TabsTrigger>
            <TabsTrigger value="prontuarios">Prontuários</TabsTrigger>
            <TabsTrigger value="radiografias">Radiografias</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>Upload de {activeTab}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <FileUpload
                      bucket={getBucketForTab(activeTab)}
                      allowedTypes={getAllowedTypesForTab(activeTab)}
                      onUploadComplete={handleUploadComplete}
                    />
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Arquivos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <FileList
                      key={refreshKey}
                      bucket={getBucketForTab(activeTab)}
                      onRefresh={() => setRefreshKey((prev) => prev + 1)}
                    />
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

