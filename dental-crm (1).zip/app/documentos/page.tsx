import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { createServerClient } from "@/lib/supabase"
import { Eye, Download, Trash2, FolderPlus } from "lucide-react"
import { EnviarDocumentoDialog } from "@/components/enviar-documento-dialog"
import Link from "next/link"
import { DocumentosSearch } from "@/components/documentos-search"

export default async function DocumentosPage() {
  const supabase = createServerClient()
  const { data: documentos } = await supabase
    .from("documentos")
    .select(`
      *,
      pacientes (
        id,
        nome
      )
    `)
    .order("created_at", { ascending: false })

  // Format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString("pt-BR")
  }

  return (
    <div>
      <div className="flex justify-between items-center p-6 border-b bg-white">
        <h1 className="text-2xl font-bold">Documentos</h1>
        <div className="flex gap-2">
          <EnviarDocumentoDialog />
          <Link href="/documentos/gerenciar">
            <Button variant="outline">
              <FolderPlus className="mr-2 h-4 w-4" /> Gerenciar Arquivos
            </Button>
          </Link>
        </div>
      </div>

      <div className="p-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Buscar Documentos</CardTitle>
          </CardHeader>
          <CardContent>
            <DocumentosSearch />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Documentos</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Paciente</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Data de Envio</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {documentos && documentos.length > 0 ? (
                  documentos.map((documento) => (
                    <TableRow key={documento.id}>
                      <TableCell className="font-medium">{documento.nome}</TableCell>
                      <TableCell>{documento.pacientes?.nome || "Sem paciente"}</TableCell>
                      <TableCell>{documento.tipo}</TableCell>
                      <TableCell>{formatDate(documento.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {documento.url ? (
                            <a href={documento.url} target="_blank" rel="noopener noreferrer">
                              <Button variant="outline" size="icon">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </a>
                          ) : (
                            <Button variant="outline" size="icon">
                              <Eye className="h-4 w-4" />
                            </Button>
                          )}
                          {documento.url ? (
                            <a href={documento.url} target="_blank" rel="noopener noreferrer" download>
                              <Button variant="outline" size="icon">
                                <Download className="h-4 w-4" />
                              </Button>
                            </a>
                          ) : (
                            <Button variant="outline" size="icon">
                              <Download className="h-4 w-4" />
                            </Button>
                          )}
                          <Button variant="outline" size="icon" className="text-red-500">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4">
                      Nenhum documento encontrado.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

