import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { createCheckoutSession, createCustomer } from "@/lib/stripe"
import { getSession } from "@/lib/auth"

export async function POST(req: NextRequest) {
  try {
    // Verificar autenticação
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Obter dados do corpo da requisição
    const { planId, ciclo = "mensal" } = await req.json()
    if (!planId) {
      return NextResponse.json({ error: "ID do plano é obrigatório" }, { status: 400 })
    }

    // Obter dados do usuário e da clínica
    const supabase = createServerClient()
    const { data: userData, error: userError } = await supabase
      .from("perfis_usuario")
      .select("*, clinicas(*)")
      .eq("id", session.user.id)
      .single()

    if (userError || !userData) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    const clinica = userData.clinicas
    if (!clinica) {
      return NextResponse.json({ error: "Clínica não encontrada" }, { status: 404 })
    }

    // Verificar se a clínica já tem um customer_id no Stripe
    let customerId = clinica.stripe_customer_id

    // Se não tiver, criar um novo customer no Stripe
    if (!customerId) {
      const customer = await createCustomer(userData.email, clinica.nome)
      customerId = customer.id

      // Atualizar o customer_id na tabela de clínicas
      await supabase.from("clinicas").update({ stripe_customer_id: customerId }).eq("id", clinica.id)
    }

    // Criar uma sessão de checkout
    const baseUrl = req.headers.get("origin") || "http://localhost:3000"
    const checkoutSession = await createCheckoutSession(
      customerId,
      planId,
      ciclo,
      `${baseUrl}/pagamentos/sucesso?session_id={CHECKOUT_SESSION_ID}`,
      `${baseUrl}/pagamentos/cancelado`,
    )

    return NextResponse.json({ url: checkoutSession.url })
  } catch (error: any) {
    console.error("Erro ao criar sessão de checkout:", error)
    return NextResponse.json({ error: "Erro ao processar pagamento", details: error.message }, { status: 500 })
  }
}

