import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { stripe } from "@/lib/stripe"
import { headers } from "next/headers"

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = headers().get("stripe-signature") || ""

  let event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET || "")
  } catch (error: any) {
    console.error(`Webhook Error: ${error.message}`)
    return NextResponse.json({ error: `Webhook Error: ${error.message}` }, { status: 400 })
  }

  const supabase = createServerClient()

  // Lidar com os eventos do Stripe
  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object

        // Obter metadados da sessão
        const plano = session.metadata?.plano || "trial"
        const ciclo = session.metadata?.ciclo || "mensal"

        // Atualizar a assinatura na tabela de clínicas
        if (session.subscription && session.customer) {
          const { data: clinicas, error } = await supabase
            .from("clinicas")
            .update({
              stripe_subscription_id: session.subscription,
              plano: plano,
              ciclo_cobranca: ciclo,
              status: "ativo",
              data_expiracao: null,
            })
            .eq("stripe_customer_id", session.customer)
            .select()

          if (error) {
            throw error
          }

          // Registrar no histórico de assinaturas
          if (clinicas && clinicas.length > 0) {
            const clinica = clinicas[0]

            // Obter detalhes da assinatura
            const subscription = await stripe.subscriptions.retrieve(session.subscription as string)

            await supabase.from("historico_assinaturas").insert({
              clinica_id: clinica.id,
              plano: plano,
              ciclo_cobranca: ciclo,
              valor_pago: subscription.items.data[0].price.unit_amount / 100,
              data_inicio: new Date(subscription.current_period_start * 1000).toISOString(),
              data_fim: new Date(subscription.current_period_end * 1000).toISOString(),
              status: "ativo",
              metodo_pagamento: "cartão",
              stripe_invoice_id: subscription.latest_invoice as string,
            })
          }

          console.log(`Assinatura atualizada para a clínica: ${clinicas?.[0]?.id}`)
        }
        break
      }

      case "invoice.payment_succeeded": {
        // Atualizar o status de pagamento
        const invoice = event.data.object
        if (invoice.subscription && invoice.customer) {
          // Obter detalhes da assinatura
          const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string)

          // Obter dados da clínica
          const { data: clinicas, error } = await supabase
            .from("clinicas")
            .select("*")
            .eq("stripe_customer_id", invoice.customer as string)
            .limit(1)

          if (error || !clinicas || clinicas.length === 0) {
            throw new Error(`Clínica não encontrada para o customer: ${invoice.customer}`)
          }

          const clinica = clinicas[0]

          // Verificar se há um upgrade agendado
          if (clinica.upgrade_agendado && clinica.plano_agendado) {
            await supabase
              .from("clinicas")
              .update({
                plano: clinica.plano_agendado,
                upgrade_agendado: false,
                plano_agendado: null,
                data_mudanca_plano: null,
              })
              .eq("id", clinica.id)
          }

          // Atualizar a data de expiração e status
          await supabase
            .from("clinicas")
            .update({
              status: "ativo",
              data_expiracao: new Date(subscription.current_period_end * 1000).toISOString(),
              data_proximo_ciclo: new Date(subscription.current_period_end * 1000).toISOString(),
            })
            .eq("id", clinica.id)

          // Registrar no histórico de assinaturas
          await supabase.from("historico_assinaturas").insert({
            clinica_id: clinica.id,
            plano: clinica.plano,
            ciclo_cobranca: clinica.ciclo_cobranca || "mensal",
            valor_pago: invoice.amount_paid / 100,
            data_inicio: new Date(subscription.current_period_start * 1000).toISOString(),
            data_fim: new Date(subscription.current_period_end * 1000).toISOString(),
            status: "ativo",
            metodo_pagamento: "cartão",
            stripe_invoice_id: invoice.id,
          })
        }
        break
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object

        // Obter metadados da assinatura
        const emCarencia = subscription.metadata?.em_carencia === "true"
        const dataFimCarencia = subscription.metadata?.data_fim_carencia

        // Atualizar o status da assinatura
        const updateData: any = {
          status: subscription.status === "active" ? "ativo" : "inativo",
          data_expiracao: new Date(subscription.current_period_end * 1000).toISOString(),
          data_proximo_ciclo: new Date(subscription.current_period_end * 1000).toISOString(),
        }

        // Se estiver em período de carência
        if (emCarencia && dataFimCarencia) {
          updateData.periodo_carencia = true
          updateData.data_fim_carencia = dataFimCarencia
        }

        await supabase.from("clinicas").update(updateData).eq("stripe_subscription_id", subscription.id)

        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object

        // Marcar a assinatura como cancelada
        await supabase
          .from("clinicas")
          .update({
            status: "cancelado",
            plano: "trial",
            data_expiracao: new Date().toISOString(),
            periodo_carencia: false,
            data_fim_carencia: null,
            plano_anterior: null,
          })
          .eq("stripe_subscription_id", subscription.id)

        // Atualizar o histórico de assinaturas
        const { data: clinicas } = await supabase
          .from("clinicas")
          .select("id")
          .eq("stripe_subscription_id", subscription.id)
          .limit(1)

        if (clinicas && clinicas.length > 0) {
          await supabase
            .from("historico_assinaturas")
            .update({
              status: "cancelado",
              data_fim: new Date().toISOString(),
            })
            .eq("clinica_id", clinicas[0].id)
            .is("data_fim", null)
        }

        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Erro ao processar webhook:", error)
    return NextResponse.json({ error: "Erro ao processar webhook" }, { status: 500 })
  }
}

// Configurar para aceitar requisições raw
export const config = {
  api: {
    bodyParser: false,
  },
}

