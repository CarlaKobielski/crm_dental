import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { createBillingPortalSession } from "@/lib/stripe"
import { getSession } from "@/lib/auth"

export async function POST(req: NextRequest) {
  try {
    // Verificar autenticação
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Obter dados do usuário e da clínica
    const supabase = createServerClient()
    const { data: userData, error: userError } = await supabase
      .from("perfis_usuario")
      .select("*, clinicas(*)")
      .eq("id", session.user.id)
      .single()

    if (userError || !userData) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    const clinica = userData.clinicas
    if (!clinica) {
      return NextResponse.json({ error: "Clínica não encontrada" }, { status: 404 })
    }

    // Verificar se a clínica tem um customer_id no Stripe
    const customerId = clinica.stripe_customer_id
    if (!customerId) {
      return NextResponse.json({ error: "Cliente Stripe não encontrado" }, { status: 404 })
    }

    // Criar uma sessão do portal de faturamento
    const baseUrl = req.headers.get("origin") || "http://localhost:3000"
    const portalSession = await createBillingPortalSession(customerId, `${baseUrl}/configuracoes/assinatura`)

    return NextResponse.json({ url: portalSession.url })
  } catch (error: any) {
    console.error("Erro ao criar sessão do portal:", error)
    return NextResponse.json(
      { error: "Erro ao acessar portal de faturamento", details: error.message },
      { status: 500 },
    )
  }
}

