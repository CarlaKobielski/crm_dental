import { type NextRequest, NextResponse } from "next/server"
import { restoreTableData } from "@/lib/backup"

export async function POST(req: NextRequest) {
  try {
    const backupData = await req.json()
    const results: Record<string, any> = {}

    for (const [table, data] of Object.entries(backupData)) {
      results[table] = await restoreTableData(table, data as any[])
    }

    return NextResponse.json({ success: true, results })
  } catch (error) {
    console.error("Erro ao restaurar backup:", error)
    return NextResponse.json({ error: "Falha ao restaurar backup" }, { status: 500 })
  }
}

