import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { sendSMS } from "@/lib/notifications"
import { getSession } from "@/lib/auth"

export async function POST(req: NextRequest) {
  try {
    // Verificar autenticação
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Obter dados do corpo da requisição
    const { to, template, clinicaId } = await req.json()

    if (!to || !template) {
      return NextResponse.json({ error: "Destinatário e template são obrigatórios" }, { status: 400 })
    }

    // Verificar se o usuário pertence à clínica
    const supabase = createServerClient()
    const { data: userData, error: userError } = await supabase
      .from("perfis_usuario")
      .select("clinica_id")
      .eq("id", session.user.id)
      .single()

    if (userError || !userData || userData.clinica_id !== clinicaId) {
      return NextResponse.json({ error: "Não autorizado para esta clínica" }, { status: 403 })
    }

    // Obter dados da clínica
    const { data: clinicaData, error: clinicaError } = await supabase
      .from("clinicas")
      .select("nome")
      .eq("id", clinicaId)
      .single()

    if (clinicaError || !clinicaData) {
      return NextResponse.json({ error: "Clínica não encontrada" }, { status: 404 })
    }

    // Preparar o template com dados de exemplo
    const dataAtual = new Date()
    const dataFormatada = dataAtual.toLocaleDateString("pt-BR")
    const horaFormatada = dataAtual.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })

    const mensagem = template
      .replace(/{paciente}/g, "Paciente Teste")
      .replace(/{data}/g, dataFormatada)
      .replace(/{hora}/g, horaFormatada)
      .replace(/{clinica}/g, clinicaData.nome)

    // Enviar SMS de teste
    const success = await sendSMS(to, mensagem)

    if (!success) {
      return NextResponse.json({ error: "Falha ao enviar SMS de teste" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao enviar SMS de teste:", error)
    return NextResponse.json({ error: error.message || "Erro ao processar requisição" }, { status: 500 })
  }
}

