import { NextResponse } from "next/server"
import { processScheduledNotifications } from "@/lib/notifications"

// Esta rota pode ser chamada por um cron job para processar notificações agendadas
export async function GET() {
  try {
    await processScheduledNotifications()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao processar notificações agendadas:", error)
    return NextResponse.json({ error: "Erro ao processar notificações" }, { status: 500 })
  }
}

