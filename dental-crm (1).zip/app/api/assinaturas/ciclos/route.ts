import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { getSession } from "@/lib/auth"

// GET: Obter descontos por ciclo
export async function GET() {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const supabase = createServerClient()
    const { data, error } = await supabase.from("descontos_ciclos").select("*").order("id")

    if (error) {
      throw error
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Erro ao obter descontos por ciclo:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// POST: Atualizar descontos por ciclo (apenas para administradores)
export async function POST(req: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Verificar se o usuário é administrador
    const supabase = createServerClient()
    const { data: perfil, error: perfilError } = await supabase
      .from("perfis_usuario")
      .select("*")
      .eq("id", session.user.id)
      .single()

    if (perfilError || !perfil || perfil.tipo !== "admin") {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    const { ciclos } = await req.json()

    // Atualizar cada ciclo
    for (const ciclo of ciclos) {
      const { error } = await supabase
        .from("descontos_ciclos")
        .update({ percentual_desconto: ciclo.percentual_desconto })
        .eq("ciclo", ciclo.ciclo)

      if (error) {
        throw error
      }
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao atualizar descontos por ciclo:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

