import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { getSession } from "@/lib/auth"
import { updateSubscription } from "@/lib/stripe"

export async function POST(req: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { planoId, ciclo, agendarMudanca } = await req.json()

    if (!planoId || !ciclo) {
      return NextResponse.json({ error: "Dados incompletos" }, { status: 400 })
    }

    // Obter dados da clínica
    const supabase = createServerClient()
    const { data: perfil, error: perfilError } = await supabase
      .from("perfis_usuario")
      .select("*, clinicas(*)")
      .eq("id", session.user.id)
      .single()

    if (perfilError || !perfil || !perfil.clinicas) {
      return NextResponse.json({ error: "Clínica não encontrada" }, { status: 404 })
    }

    const clinica = perfil.clinicas
    const subscriptionId = clinica.stripe_subscription_id

    if (!subscriptionId) {
      return NextResponse.json({ error: "Assinatura não encontrada" }, { status: 404 })
    }

    // Se a mudança deve ser agendada para o próximo ciclo
    if (agendarMudanca) {
      // Atualizar no banco de dados
      await supabase
        .from("clinicas")
        .update({
          upgrade_agendado: true,
          plano_agendado: planoId,
          data_mudanca_plano: new Date().toISOString(),
        })
        .eq("id", clinica.id)

      // Atualizar no Stripe para o próximo ciclo
      await updateSubscription(subscriptionId, planoId, ciclo, "next_billing_cycle")

      return NextResponse.json({
        success: true,
        message: "Mudança de plano agendada para o próximo ciclo de cobrança",
      })
    } else {
      // Atualizar imediatamente
      await updateSubscription(subscriptionId, planoId, ciclo, "now")

      // Atualizar no banco de dados
      await supabase
        .from("clinicas")
        .update({
          plano: planoId,
          ciclo_cobranca: ciclo,
          upgrade_agendado: false,
          plano_agendado: null,
          data_mudanca_plano: null,
        })
        .eq("id", clinica.id)

      return NextResponse.json({
        success: true,
        message: "Plano atualizado com sucesso",
      })
    }
  } catch (error: any) {
    console.error("Erro ao atualizar plano:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

