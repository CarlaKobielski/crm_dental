import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { getSession } from "@/lib/auth"
import { cancelSubscription } from "@/lib/stripe"

export async function POST(req: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { comCarencia, diasCarencia } = await req.json()

    // Obter dados da clínica
    const supabase = createServerClient()
    const { data: perfil, error: perfilError } = await supabase
      .from("perfis_usuario")
      .select("*, clinicas(*)")
      .eq("id", session.user.id)
      .single()

    if (perfilError || !perfil || !perfil.clinicas) {
      return NextResponse.json({ error: "Clínica não encontrada" }, { status: 404 })
    }

    const clinica = perfil.clinicas
    const subscriptionId = clinica.stripe_subscription_id

    if (!subscriptionId) {
      return NextResponse.json({ error: "Assinatura não encontrada" }, { status: 404 })
    }

    // Cancelar a assinatura
    const gracePeriodDays = comCarencia ? diasCarencia || 7 : 0
    await cancelSubscription(subscriptionId, true, gracePeriodDays)

    // Atualizar no banco de dados
    if (comCarencia && gracePeriodDays > 0) {
      const dataFimCarencia = new Date()
      dataFimCarencia.setDate(dataFimCarencia.getDate() + gracePeriodDays)

      await supabase
        .from("clinicas")
        .update({
          periodo_carencia: true,
          data_fim_carencia: dataFimCarencia.toISOString(),
          plano_anterior: clinica.plano,
        })
        .eq("id", clinica.id)

      return NextResponse.json({
        success: true,
        message: `Assinatura será cancelada após o período de carência de ${gracePeriodDays} dias`,
        dataFimCarencia: dataFimCarencia.toISOString(),
      })
    } else {
      await supabase
        .from("clinicas")
        .update({
          status: "cancelado_pendente",
        })
        .eq("id", clinica.id)

      return NextResponse.json({
        success: true,
        message: "Assinatura será cancelada no final do período atual",
      })
    }
  } catch (error: any) {
    console.error("Erro ao cancelar assinatura:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

