import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { getSession } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const url = new URL(req.url)
    const clinicaId = url.searchParams.get("clinicaId")

    if (!clinicaId) {
      return NextResponse.json({ error: "ID da clínica é obrigatório" }, { status: 400 })
    }

    // Verificar se o usuário tem acesso à clínica
    const supabase = createServerClient()
    const { data: perfil, error: perfilError } = await supabase
      .from("perfis_usuario")
      .select("*, clinicas!inner(*)")
      .eq("id", session.user.id)
      .eq("clinicas.id", clinicaId)
      .single()

    if (perfilError || !perfil) {
      return NextResponse.json({ error: "Acesso negado" }, { status: 403 })
    }

    // Obter histórico de assinaturas
    const { data: historico, error } = await supabase
      .from("historico_assinaturas")
      .select("*")
      .eq("clinica_id", clinicaId)
      .order("created_at", { ascending: false })

    if (error) {
      throw error
    }

    return NextResponse.json(historico || [])
  } catch (error: any) {
    console.error("Erro ao obter histórico de assinaturas:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

