import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"

async function exportTableData(tableName: string) {
  const supabase = createServerClient()

  try {
    const { data, error } = await supabase.from(tableName).select("*")

    if (error) {
      console.warn(`Erro ao exportar tabela ${tableName}: ${error.message}`)
      return "[]" // Retorna array vazio em caso de erro
    }

    return JSON.stringify(data || [], null, 2)
  } catch (error) {
    console.warn(`Erro ao exportar tabela ${tableName}:`, error)
    return "[]" // Retorna array vazio em caso de erro
  }
}

export async function GET(req: NextRequest) {
  try {
    const tables = ["pacientes", "consultas", "tratamentos", "financeiro", "prontuarios", "documentos", "lembretes"]
    const backupData: Record<string, any> = {}

    for (const table of tables) {
      try {
        backupData[table] = JSON.parse(await exportTableData(table))
      } catch (error) {
        console.warn(`Erro ao processar tabela ${table}:`, error)
        backupData[table] = [] // Tabela vazia em caso de erro
      }
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, "-")

    return new NextResponse(JSON.stringify(backupData), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename=dental-crm-backup-${timestamp}.json`,
      },
    })
  } catch (error) {
    console.error("Erro ao gerar backup:", error)
    return NextResponse.json({ error: "Falha ao gerar backup", details: String(error) }, { status: 500 })
  }
}

