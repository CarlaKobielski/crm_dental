import { Button } from "@/components/ui/button"
import Link from "next/link"
import { XCircle } from "lucide-react"

export default function PagamentoCanceladoPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <XCircle className="mx-auto h-16 w-16 text-red-500" />
        <h2 className="mt-6 text-3xl font-bold tracking-tight text-gray-900">Pagamento Cancelado</h2>
        <p className="mt-2 text-gray-600">
          O processo de pagamento foi cancelado. Você pode tentar novamente quando estiver pronto.
        </p>
        <div className="mt-6 space-y-4">
          <Link href="/planos">
            <Button className="w-full">Voltar para Planos</Button>
          </Link>
          <Link href="/dashboard">
            <Button variant="outline" className="w-full">
              Ir para o Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

