import { Button } from "@/components/ui/button"
import Link from "next/link"
import { CheckCircle } from "lucide-react"

export default function PagamentoSucessoPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <CheckCircle className="mx-auto h-16 w-16 text-green-500" />
        <h2 className="mt-6 text-3xl font-bold tracking-tight text-gray-900">Pagamento Confirmado!</h2>
        <p className="mt-2 text-gray-600">
          Sua assinatura foi ativada com sucesso. Agora você tem acesso a todos os recursos do plano contratado.
        </p>
        <div className="mt-6 space-y-4">
          <Link href="/dashboard">
            <Button className="w-full">Ir para o Dashboard</Button>
          </Link>
          <Link href="/configuracoes/assinatura">
            <Button variant="outline" className="w-full">
              Gerenciar Assinatura
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

