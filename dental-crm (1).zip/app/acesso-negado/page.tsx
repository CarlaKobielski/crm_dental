import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AcessoNegadoPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900">Acesso Negado</h2>
        <p className="mt-2 text-gray-600">Você não tem permissão para acessar esta página.</p>
        <div className="mt-6">
          <Link href="/dashboard">
            <Button>Voltar ao Dashboard</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

