import { RegistroForm } from "@/components/auth/registro-form"
import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import Link from "next/link"

export default async function RegistroPage() {
  const session = await getSession()

  // Redirecionar para o dashboard se já estiver autenticado
  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">Criar uma nova conta</h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Ou{" "}
          <a href="/login" className="font-medium text-blue-600 hover:text-blue-500">
            entrar com uma conta existente
          </a>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <RegistroForm />

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-sm text-gray-500 text-center">
              Administrador? Configure o banco de dados{" "}
              <Link href="/admin/setup" className="font-medium text-blue-600 hover:text-blue-500">
                aqui
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

