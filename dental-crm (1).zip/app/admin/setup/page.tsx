import { SetupDatabaseButton } from "@/components/setup-database-button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function SetupPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Configuração Inicial do Sistema</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Configuração do Banco de Dados</CardTitle>
          <CardDescription>Configure as tabelas necessárias para o funcionamento do sistema.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Clique no botão abaixo para criar as tabelas e políticas de segurança necessárias para o funcionamento do
            sistema. Esta etapa é necessária apenas uma vez, na primeira execução do sistema.
          </p>
          <SetupDatabaseButton />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Instruções</CardTitle>
          <CardDescription>Passos para configurar o sistema corretamente</CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal pl-5 space-y-2">
            <li>Configure o banco de dados clicando no botão acima</li>
            <li>Verifique no painel do Supabase se as tabelas foram criadas corretamente</li>
            <li>Configure as variáveis de ambiente necessárias</li>
            <li>Teste o registro de um novo usuário</li>
          </ol>

          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
            <h3 className="font-semibold text-yellow-800">Nota importante</h3>
            <p className="text-yellow-700 mt-1">
              Se você encontrar problemas com a função <code>execute_sql</code>, você precisará criar esta função
              manualmente no painel do Supabase. Vá para SQL Editor e execute o seguinte código:
            </p>
            <pre className="bg-gray-100 p-2 rounded mt-2 overflow-x-auto text-sm">
              {`CREATE OR REPLACE FUNCTION execute_sql(sql_query text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  EXECUTE sql_query;
  RETURN json_build_object('success', true);
EXCEPTION WHEN OTHERS THEN
  RETURN json_build_object('success', false, 'error', SQLERRM);
END;
$$;`}
            </pre>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

