import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ConfiguracoesNotificacoes } from "@/components/notificacoes/configuracoes-notificacoes"
import { HistoricoNotificacoes } from "@/components/notificacoes/historico-notificacoes"
import { getSession, getCurrentUserProfile } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function NotificacoesPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const profile = await getCurrentUserProfile()

  if (!profile || !profile.clinica_id) {
    redirect("/dashboard")
  }

  return (
    <div>
      <div className="flex justify-between items-center p-6 border-b bg-white">
        <h1 className="text-2xl font-bold">Notificações</h1>
      </div>

      <div className="p-6">
        <Tabs defaultValue="configuracoes">
          <TabsList className="mb-4">
            <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
          </TabsList>

          <TabsContent value="configuracoes">
            <ConfiguracoesNotificacoes clinicaId={profile.clinica_id} />
          </TabsContent>

          <TabsContent value="historico">
            <HistoricoNotificacoes clinicaId={profile.clinica_id} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

