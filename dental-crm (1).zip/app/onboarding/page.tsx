import { OnboardingForm } from "@/components/onboarding/onboarding-form"
import { getSession, getCurrentUserProfile } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function OnboardingPage() {
  const session = await getSession()

  // Redirecionar para login se não estiver autenticado
  if (!session) {
    redirect("/login")
  }

  const profile = await getCurrentUserProfile()

  // Se o usuário já completou o onboarding, redirecionar para o dashboard
  if (profile?.onboarding_completo) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Bem-vindo ao Dental CRM</h1>
          <p className="mt-2 text-gray-600">Vamos configurar sua clínica em poucos passos</p>
        </div>

        <div className="bg-white shadow rounded-lg">
          <OnboardingForm userId={session.user.id} />
        </div>
      </div>
    </div>
  )
}

