import { TourGuide } from "@/components/onboarding/tour-guide"
import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function TourPage() {
  const session = await getSession()

  // Redirecionar para login se não estiver autenticado
  if (!session) {
    redirect("/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TourGuide />
    </div>
  )
}

